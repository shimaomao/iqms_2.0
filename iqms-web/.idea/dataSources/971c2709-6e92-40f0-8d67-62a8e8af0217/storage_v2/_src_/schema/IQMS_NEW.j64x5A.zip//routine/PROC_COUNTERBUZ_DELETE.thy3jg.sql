create procedure          proc_counterbuz_delete
(
orgId varchar2,
deviceNo varchar2,
winId varchar2,
ReturnCode out varchar2
)
as
   v_sql varchar2(4000);

begin

   if orgId is null or deviceNo is null then
       delete from BSC_CounterBuz b where b.counterId = winId;
       ReturnCode:='0';
   else
       delete from BSC_CounterBuz b where b.counterId = winId
       and b.org_id = orgId and b.device_no = deviceNo;
       ReturnCode:='0';
   end if;
   proc_deviceupdateflag(deviceNo,'0');

end proc_counterbuz_delete;
/

