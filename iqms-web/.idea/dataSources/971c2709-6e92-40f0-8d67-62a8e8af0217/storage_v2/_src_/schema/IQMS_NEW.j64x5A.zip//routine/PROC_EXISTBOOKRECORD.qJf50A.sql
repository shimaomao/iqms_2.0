create PROCEDURE          PROC_EXISTBOOKRECORD
(
 orgCode IN varchar2,  -- 机构编码
 devNo IN varchar2,    -- 设备号
 certType in varchar2, -- 证件类型
 certContent in varchar2, -- 证件号
 orderTime  in varchar2, -- 预约时间点（废弃不使用）
 orderDt in varchar2, -- 预预约日期  2017-10-21
 beginTime in varchar2, --开始时间段
 endTime in varchar2,-- 结束时间段
 ReturnCode out varchar2  -- 返回结果  0-可以预约   1-预约已经存在

)
AS
  recordExists INTEGER DEFAULT 0;
  orderCount INTEGER DEFAULT 0;
  canOrderCount varchar2(50);
  rangeExists INTEGER DEFAULT 0;  -- 预约时间点所在时间段是否存在
  rangeTotalCount  INTEGER DEFAULT 0; -- 时间段可预约的总数量
BEGIN
  ReturnCode := 0; -- 可以预约
  -- 查询此人是否已经预约过了(当天这个营业厅，这个验证类型，且不是取消的)
  SELECT COUNT(1)  INTO recordExists FROM order_info i  WHERE i.org_code = orgCode
                                                               --and r.dev_no = devNo
                                                               and i.cert_type = certType
                                                               and i.cert_content = certContent
                                                               and i.order_status <> '2'  --
                                                               and order_date = orderDt;



  if recordExists > 0 then
     ReturnCode := 1; -- 该客户今天已经预约过了
     return;
  end if;


  -- 查询预约时间段是否存在
  select count(1) into rangeExists from order_range r where r.device_no = devNo  --预约网点
                                           and  r.begin_time =  beginTime
                                           and  r.end_time =  endTime;

   if rangeExists = 1 then  -- 查询预约时间段的放号数量

      select r.ordercount into rangeTotalCount from order_range r where r.device_no = devNo  --预约网点
                                           and  r.begin_time =  beginTime
                                           and  r.end_time =  endTime;
   else
     ReturnCode := 2; -- 预约的时间段，没有对应的时间段
     return;
   end if;


  -- 查询该网点的此时间段预约情况(一个网点，同一日期，同一时间段，有效的预约数量)
select count(1) into orderCount from order_info i  WHERE i.dev_no = devNo
                                                           and i.range_begin = beginTime
                                                           and i.range_end = endTime
                                                           and i.order_status <> '2'  --
                                                           and i.order_date = orderDt;

  -- 判断是否有多余的预约数量
  if rangeTotalCount <= orderCount then
     ReturnCode := 3; -- 预约时间段，已经被预约完了
     return;
  end if ;
   ReturnCode := 0;

END PROC_EXISTBOOKRECORD;
/

