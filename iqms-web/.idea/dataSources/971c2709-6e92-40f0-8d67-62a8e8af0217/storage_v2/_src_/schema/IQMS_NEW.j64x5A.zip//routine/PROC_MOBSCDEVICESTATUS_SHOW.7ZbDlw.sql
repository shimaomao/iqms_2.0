create procedure          proc_mobscdevicestatus_show (
orgId varchar2, --机构id
deviceNo  varchar2,--是否在线
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_orgId varchar2(50) := orgId;
   v_deviceNo varchar2(50) := deviceNo;

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql := ' select h.ORG_ID,h.DEVICE_NO,h.CPU_RATIO,h.MEM_RATIO,h.DISK_RATIO,
  d.currt_vername,d.last_vername,s.org_name from bsc_device_status h,bc_parameter b,sys_org s,bsc_device d where d.device_no=h.device_no
  and s.org_id = h.org_id and h.org_id =:orgId and h.device_no =:deviceNo';





OPEN p_cursor FOR v_sql using  v_orgId,v_deviceNo;

end proc_mobscdevicestatus_show;
/

