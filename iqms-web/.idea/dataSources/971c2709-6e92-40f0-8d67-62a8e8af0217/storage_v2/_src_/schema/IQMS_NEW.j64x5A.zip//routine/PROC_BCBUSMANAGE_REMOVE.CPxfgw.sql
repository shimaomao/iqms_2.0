create PROCEDURE          proc_bcbusmanage_remove
(
 businessId varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

   delete from  bc_businessmanage t where t.BUSINESS_ID = businessId;
   --级联删除网点业务
   delete from bsc_branch_business b where b.bus_id = businessId
   and b.business_type = '1';
   --级联删除【叫号策略】
   delete from bsc_counterbuz s where s.buztypeid = businessId ;
   --级联删除【业务显示】
   delete from bsc_show_time b where b.business_id =  businessId;
   --级联删除【取号界面】
   delete from bc_modelstyle_element m where m.element_type = 'buzType'
   and m.buztype_id = businessId;
   --级联更新【客户级别】 绑定业务为不绑定
   update bsc_cust_level c set c.business_id = null
   where c.business_id = businessId;
    proc_deviceupdateflag('','1');
   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcbusmanage_remove;
/

