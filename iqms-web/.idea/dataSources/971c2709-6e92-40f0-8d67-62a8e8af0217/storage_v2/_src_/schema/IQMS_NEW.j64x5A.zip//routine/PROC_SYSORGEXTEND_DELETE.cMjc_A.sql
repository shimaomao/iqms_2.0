create procedure          proc_sysorgextend_delete (
orgId varchar2,

ReturnCode OUT varchar2)


is
  cursor v_device is select d.org_id v_orgId,d.device_no v_deviceNo from bsc_device d
  where  d.org_id = orgId;
  v_d v_device%rowtype;
  v_code varchar2(20);
begin

 delete from sys_org t where t.org_id = orgId;

 for v_d in v_device loop
        proc_bscdevice_remove(to_char(v_d.v_orgid),v_d.v_deviceno, v_code);

 end loop;
ReturnCode:='0';


end proc_sysorgextend_delete;
/

