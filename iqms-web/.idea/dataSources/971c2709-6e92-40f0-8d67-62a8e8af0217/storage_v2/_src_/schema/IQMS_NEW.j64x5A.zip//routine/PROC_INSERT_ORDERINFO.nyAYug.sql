create PROCEDURE          proc_insert_orderinfo
(
 orgCode IN varchar2,  -- 机构编码
 devNo IN varchar2,    -- 设备号
 actNo in varchar2, --激活码
 orderBusId in varchar2,--业务id
 orderBusCode in varchar2,--业务code
 certType in varchar2, -- 证件类型
 certContent in varchar2, -- 证件号
 orderDt in varchar2,
 orderTime in varchar2,
 rangeBegin in varchar2,
 rangeEnd in varchar2,
 ReturnCode out varchar2  -- 返回结果  0-成功   1-失败

)
AS
  recordExists INTEGER DEFAULT 0;
BEGIN
  insert into order_info (
         order_id,
         org_code,
         dev_no,
         act_no,
         ORDER_BUSID,
         ORDER_BUSCODE,
         cert_type,
         cert_content,
         ORDER_DATE,
         order_time,
         RANGE_BEGIN,
         RANGE_END,
         order_status,
         OPERTATE_DATE) values
         (
         SEQ_ORDERINFO.NEXTVAL,
         orgCode,
         devNo,
         actNo,
         orderBusId,
         orderBusCode,
         certType,
         certContent,
         orderDt,
         orderTime,
         rangeBegin,
         rangeEnd,
         0,
         to_char(sysdate,'yyyy-mm-dd')
         );
ReturnCode := 0;
END proc_insert_orderinfo;
/

