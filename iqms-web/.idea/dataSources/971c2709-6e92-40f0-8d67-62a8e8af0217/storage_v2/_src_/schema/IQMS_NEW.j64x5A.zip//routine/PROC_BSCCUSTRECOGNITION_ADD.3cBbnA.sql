create PROCEDURE          proc_bsccustrecognition_add
(
 orgId varchar2,
 deviceNo varchar2,
 rowId_ varchar2,
 dateType varchar2,
 startPosition varchar2,
 mateLength varchar2,
 startMateCode varchar2,
 endMateCode varchar2,
 custLevel varchar2,
 --recognitionType varchar2,
 extend1 varchar2,
 extend2 varchar2,
 extend3 varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

 --查询要增加的记录是否存在
 --select count(1) into iRecCount from DEVICE_INFO t where t.org_code = orgCode and t.device_no = deviceNo;
 select count(1) into iRecCount from BSC_CUST_RECOGNITION t where t.org_id=orgId and t.device_no = deviceNo
  and t.row_id = rowId_;


 if iRecCount > 0 then
   update BSC_CUST_RECOGNITION t set
      t.ORG_ID = orgId,
      t.DEVICE_NO =deviceNo,
      --t.recognition_type = recognitionType,
      t.row_id =rowId_,
      t.date_type = dateType,
      t.start_position = startPosition,
      t.mate_length = mateLength,
      t.start_mate_code = startMateCode,
      t.end_mate_code = endMateCode,
      t.cust_level = custLevel,
      t.EXTEND1 =extend1,
      t.EXTEND2 =extend2,
      t.EXTEND3 =extend3
      where t.org_id=orgId
      and t.device_no = deviceNo

      and t.row_id = rowId_
      and t.date_type = dateType;
      --更新设备状态
proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0'; --已经存在
 else
   --插入
   insert into BSC_CUST_RECOGNITION (
      ORG_ID,
      DEVICE_NO,
      recognition_type,
      row_id,
      date_type,
      start_position,
      mate_length,
      start_mate_code,
      end_mate_code,
      cust_level,
      EXTEND1,
      EXTEND2,
      EXTEND3
   ) values (
     orgId,
     deviceNo,
     (select distinct(p.authentication_type) from bc_parameter p),
     rowId_,
     dateType,
     startPosition,
     mateLength,
     startMateCode,
     endMateCode,
     custLevel,
     extend1,
     extend2,
     extend3
   );
   --更新设备状态
--update bsc_device b set b.extend1 = '1' where b.org_id = orgId
--and b.device_no = deviceNo;
proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bsccustrecognition_add;
/

