create PROCEDURE          proc_extheartbeat
(
 orgId varchar2,
 deviceNo varchar2 ,
 cpuRatio varchar2,
 memRatio varchar2 ,
 diskRatio varchar2,
 versionSeq varchar2,
 thermalPrinterStatus varchar2 ,
 needlePrinterStatus number,
 idReaderStatus varchar2 ,
 swReadStatus varchar2,
 icReaderStatus varchar2 ,
 barStatus varchar2,
 compStatus varchar2 ,
 configUpdaeFlag OUT varchar2,
 clientUpdateFlag OUT varchar2,
 clentiVerSeq OUT varchar2,
 clientVerName OUT varchar2,
 clientPatchMd5 OUT varchar2,
 hearBeatInterval OUT varchar2,
 authenticationType OUT varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
devVerNo number; -- 设备当前版本号
devLastNo number; --设备最新版本号
patchId number; -- 返回需要升级的版本号
patchName number; --返回需要升级的版本的名称
patchMd5 varchar2(50); -- 版本的md5码
configFlag varchar2(1);  --配置更新flag
patchFlag varchar2(1); -- 版本更新flag

BEGIN

 --查询状态记录是否存在
 select count(1) into iRecCount from BSC_DEVICE_STATUS t where t.org_id  = orgId and t.DEVICE_NO=deviceNo;

 if iRecCount > 0 then

   update BSC_DEVICE_STATUS ds set ds.cpu_ratio = cpuRatio,ds.mem_ratio=memRatio,ds.disk_ratio=diskRatio,ds.version_seq=versionSeq,
                                   ds.update_date= sysdate,ds.thermalprinter_status = thermalPrinterStatus,
                                   ds.needleprinter_status = needlePrinterStatus, ds.idreader_status = idReaderStatus,
                                   ds.swread_status = swReadStatus, ds.icreader_status = icReaderStatus,
                                   ds.bar_status = barStatus,ds.comp_status = compStatus
   where ds.org_id = orgId and ds.device_no = deviceNo;
 else
   --插入
   insert into BSC_DEVICE_STATUS ds (ORG_ID,
          DEVICE_NO,
          CPU_RATIO,
          MEM_RATIO,
          DISK_RATIO,
          VERSION_SEQ,
          UPDATE_DATE,
          THERMALPRINTER_STATUS,
          NEEDLEPRINTER_STATUS,
          IDREADER_STATUS,
          SWREAD_STATUS,
          ICREADER_STATUS,
          BAR_STATUS,
          COMP_STATUS
   ) values (
       orgId,
       deviceNo,
       cpuRatio,
       memRatio,
       diskRatio,
       versionSeq,
       sysdate,
       thermalPrinterStatus,
       needlePrinterStatus,
       idReaderStatus,
       swReadStatus,
       icReaderStatus,
       barStatus,
       compStatus
   );
 end if;

 -- 更新设备的最后在线时间，及设备当前版本号
 update bsc_device d set d.online_time = sysdate,d.currt_ver=versionSeq where d.org_id= orgId and d.device_no=deviceNo;


 -- 查询设备信息
 begin
   select case when d.extend1 is null then '0' else d.extend1 end cFlag,  -- 配置是否有更新  1-有   0-无
          case when d.currt_ver is null then -1 else d.currt_ver end currVer,  -- 当前版本号
          case when d.last_ver is null then -1 else d.last_ver end lastVer --  最新版本号
    into configFlag,devVerNo,devLastNo  from bsc_device d where d.device_no = deviceNo;
 exception
      when others then
     -- 设备不存在
     configFlag:=0;
     devVerNo:=-1;
     devLastNo:=-1;
 end;

 -- 返回相关信息
 configUpdaeFlag := configFlag; --是否有配置更新
 --configUpdaeFlag := '0'; --是否有配置更新
 clientUpdateFlag := '0'; -- 是否有客户端更新
 clentiVerSeq := '';  --客户端版本号
 clientVerName := ''; -- 客户端版本名称
 clientPatchMd5 := ''; -- 版本的MD5码

 if devLastNo > devVerNo then
     clientUpdateFlag := '1'; -- 是否有客户端更新
     -- 查询和当前版本最接近需要升级的版本
     select tmp.patch_id,tmp.patch_name,tmp.patch_md5 into  clentiVerSeq,clientVerName,clientPatchMd5  from
     (
            select dup.patch_id,p.patch_name,p.patch_md5 from bsc_devupgrade_process dup inner join bc_patchversion p on (p.id = dup.patch_id)
                          where dup.patch_id >  to_number(versionSeq)
                          and dup.status = 0
                          and dup.device_no = deviceNo
                          order by dup.patch_id
      ) tmp where rownum <= 1;
 end if;

 -- 查询心跳间隔
 begin
    select to_char(case when p.hb_interval is null then 5 else p.hb_interval end),

           (case when p.authentication_type is null then '1' else p.authentication_type end)    into hearBeatInterval,authenticationType  from bc_parameter p;
 exception
      when others then
     hearBeatInterval:=5;
     authenticationType:='1';
 end;


 ReturnCode:='0';


 --异常处理
 -- exception
  --    when others then
  --     ReturnCode:='1';
END proc_extheartbeat;
/

