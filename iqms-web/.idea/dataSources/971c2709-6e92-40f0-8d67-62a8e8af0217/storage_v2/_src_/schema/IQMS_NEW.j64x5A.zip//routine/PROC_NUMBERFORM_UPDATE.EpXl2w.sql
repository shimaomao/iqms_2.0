create PROCEDURE          proc_numberform_update
(
 tktFormatId varchar2,
 v_tktFormat varchar2,
 ReturnCode OUT varchar2
)
IS
cursor v_deviceNo is
select t.device_no from bc_ticketform t left join bc_numberform n on
t.tktformat_id = n.tktformat_id;
v_no v_deviceNo%rowtype;
iRecCount INTEGER;
BEGIN
   --查询要修改的记录是否存在
   select count(1) into iRecCount from bc_numberform b where b.tktformat = v_tktFormat and b.tktformat_id <> tktFormatId;

   if iRecCount > 0 then
       ReturnCode:='2';
   else
     update bc_numberform t set
        t.TKTFORMAT = v_tktFormat
     where  t.TKTFORMAT_ID = tktFormatId;

     for v_no in v_deviceNo loop
     proc_deviceupdateflag(v_no.device_no,'0');

     end loop;
     ReturnCode:='0';
   end if ;

 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_numberform_update;
/

