create procedure          proc_deviceupdateflag
(
 deviceNo in  varchar2,
 upFlage in varchar2 -- 1全部设备更新    0-只更新deviceNo的设备
)
is



begin

  if   upFlage = 1 then

       update bsc_device d set d.extend1 = 1;

  else

       update bsc_device d set d.extend1 = 1 where d.device_no = deviceNo;

  end if;




   --异常处理
   -- exception
    --   when others then
     --  ReturnCode:='1'; --数据库异常
end proc_deviceupdateflag;
/

