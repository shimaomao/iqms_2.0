create procedure          proc_bcpatchversion_page (
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(4000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := ' select ID,h.rowId rid,
  PATCH_NAME,
  PATCH_MD5,
  PATCH_PATH,
  PATCH_REMARK,
  PATCH_DATE,
  STATUS,
  PATCH_VERNO,
  INTACT_FLAG,
  DB_FLAG
  from bc_patchversion h where 1=1  ';


  -------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------


 --select result
 v_sql := 'select row_number() over ( order by PATCH_DATE desc,rid ) rnum,tt.ID,
  tt.PATCH_NAME,
  tt.PATCH_MD5,
  tt.PATCH_PATH,
  tt.PATCH_REMARK,
  tt.PATCH_DATE,
  tt.STATUS,
  tt.PATCH_VERNO,
  tt.INTACT_FLAG,
  tt.DB_FLAG
   from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';


------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows;
     OPEN p_cursor FOR v_sql_page using  v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page;
  end if;

end proc_bcpatchversion_page;
/

