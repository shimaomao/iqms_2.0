create procedure          proc_counterbuzs_add
(
v_orgId varchar2,
v_deviceNo varchar2,
v_counterId varchar2,
v_dateTypeId varchar2,
v_busId varchar2,
v_custLevel varchar2,
v_buzPriorityTime varchar2,
v_custPriorityTime varchar2,
v_maxWaitTime varchar2,
ReturnCode out varchar2
)
is
iRecCount INTEGER;
v_count INTEGER;
begin

   if v_orgId is null or v_deviceNo is null then
      --查询要增加的记录是否存在
     select count(1) into iRecCount from BSC_CounterBuz t where t.counterid = v_counterId ;
     if iRecCount >0 then
        select count(1) into v_count from BSC_CounterBuz t where t.counterid = v_counterId and t.datetypeid = v_dateTypeId
        and t.buztypeid = v_busId and t.levelid = v_custLevel;

        if v_count>0 then
          delete from BSC_CounterBuz b where b.counterid = v_counterId and b.datetypeid=v_dateTypeId and b.buztypeid=v_busId
          and b.levelid=v_custLevel;

          insert into BSC_CounterBuz b
          (b.counterId,
           b.dateTypeId,
           b.buzTypeId,
           b.levelId,
           b.buzPriorityTime,
           b.custPriorityTime,
           b.maxWaiting，
           b.org_id,
           b.device_no
          )values
          (v_counterId,
           v_dateTypeId,
           v_busId,
           v_custLevel,
           v_buzPriorityTime,
           v_custPriorityTime,
           v_maxWaitTime,
           v_orgId,
           v_deviceNo
          );
          ReturnCode:='0';
          proc_deviceupdateflag(v_deviceNo,'0');
        else
          insert into BSC_CounterBuz b
          (b.counterId,
           b.dateTypeId,
           b.buzTypeId,
           b.levelId,
           b.buzPriorityTime,
           b.custPriorityTime,
           b.maxWaiting,
           b.org_id,
           b.device_no
          )values
          (v_counterId,
           v_dateTypeId,
           v_busId,
           v_custLevel,
           v_buzPriorityTime,
           v_custPriorityTime,
           v_maxWaitTime,
           v_orgId,
           v_deviceNo
          );
          ReturnCode:='0';
          proc_deviceupdateflag(v_deviceNo,'0');
       end if;
     else
        insert into BSC_CounterBuz b
          (b.counterId,
           b.dateTypeId,
           b.buzTypeId,
           b.levelId,
           b.buzPriorityTime,
           b.custPriorityTime,
           b.maxWaiting,
           b.org_id,
           b.device_no
          )values
          (v_counterId,
           v_dateTypeId,
           v_busId,
           v_custLevel,
           v_buzPriorityTime,
           v_custPriorityTime,
           v_maxWaitTime,
           v_orgId,
           v_deviceNo
          );
        ReturnCode:='0';
        proc_deviceupdateflag(v_deviceNo,'0');
    end if;
   else
      --查询要增加的记录是否存在
     select count(1) into iRecCount from BSC_CounterBuz t where t.counterid = v_counterId
     and t.org_id = v_orgId and t.device_no = v_deviceNo;

     if iRecCount >0 then
        select count(1) into v_count from BSC_CounterBuz t where t.counterid = v_counterId and t.datetypeid = v_dateTypeId
        and t.buztypeid = v_busId and t.levelid = v_custLevel and t.org_id = v_orgId and t.device_no = v_deviceNo;

        if v_count>0 then
          delete from BSC_CounterBuz b where b.counterid = v_counterId and b.datetypeid=v_dateTypeId and b.buztypeid=v_busId
          and b.levelid=v_custLevel  and b.org_id = v_orgId and b.device_no = v_deviceNo;

          insert into BSC_CounterBuz b
          (b.counterId,
           b.dateTypeId,
           b.buzTypeId,
           b.levelId,
           b.buzPriorityTime,
           b.custPriorityTime,
           b.maxWaiting，
           b.org_id,
           b.device_no
          )values
          (v_counterId,
           v_dateTypeId,
           v_busId,
           v_custLevel,
           v_buzPriorityTime,
           v_custPriorityTime,
           v_maxWaitTime,
           v_orgId,
           v_deviceNo
          );
          ReturnCode:='0';
          proc_deviceupdateflag(v_deviceNo,'0');
        else
          insert into BSC_CounterBuz b
          (b.counterId,
           b.dateTypeId,
           b.buzTypeId,
           b.levelId,
           b.buzPriorityTime,
           b.custPriorityTime,
           b.maxWaiting,
           b.org_id,
           b.device_no
          )values
          (v_counterId,
           v_dateTypeId,
           v_busId,
           v_custLevel,
           v_buzPriorityTime,
           v_custPriorityTime,
           v_maxWaitTime,
           v_orgId,
           v_deviceNo
          );
          ReturnCode:='0';
          proc_deviceupdateflag(v_deviceNo,'0');
       end if;
     else
        insert into BSC_CounterBuz b
          (b.counterId,
           b.dateTypeId,
           b.buzTypeId,
           b.levelId,
           b.buzPriorityTime,
           b.custPriorityTime,
           b.maxWaiting,
           b.org_id,
           b.device_no
          )values
          (v_counterId,
           v_dateTypeId,
           v_busId,
           v_custLevel,
           v_buzPriorityTime,
           v_custPriorityTime,
           v_maxWaitTime,
           v_orgId,
           v_deviceNo
          );
        ReturnCode:='0';
        proc_deviceupdateflag(v_deviceNo,'0');
    end if;

   end if;


        --异常处理
        -- exception
         --   when others then
          --  ReturnCode:='1'; --数据库异常

end proc_counterbuzs_add;
/

