create procedure          proc_takemodel_getstyle
(
 v_styleId in  number,
 v_screenResolution in  varchar2,
 v_dateTypeId number,
 orgId number,
 deviceNo varchar2,
 p_cursor out sys_refcursor
)
is
   iRecCount INTEGER;
   i_sql varchar2(4000);
   i_styleId varchar2(50) := v_styleId;
   i_screenResolution varchar2(50) := v_screenResolution;
   i_dateTypeId varchar2(50) := v_dateTypeId;
   i_orgid varchar2(50) := orgId;
   i_deviceNo varchar2(50) := deviceNo;
begin

      i_sql := 'select c.stylevalue from bc_takemodel b
      inner join bc_modelStyle c on(b.styleid=c.styleid)
      where b.styleid =: v_styleId  and c.screenresolution= :v_screenResolution
      and c.datetypeid=: v_dateTypeId and b.org_id=:orgId and b.device_no=: deviceNo';

      OPEN p_cursor FOR i_sql using i_styleId,i_screenResolution,i_dateTypeId,i_orgid,i_deviceNo;

end proc_takemodel_getstyle;
/

