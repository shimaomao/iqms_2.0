create procedure          proc_findBusys (
orgCode varchar2,
deviceNo varchar2,


p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_orgId varchar2(50);

begin

select s.org_id into v_orgId from sys_org s where s.org_code = orgCode;

 v_sql := 'select b.org_id,b.device_no,
 b.bus_id,
 b.business_code,
 bm.business_name,
 bm.order_flag
 from bsc_branch_business b
 inner join BC_BUSINESSMANAGE bm
 on (b.bus_id = bm.business_id)
 where  b.device_no =:deviceNo
 and b.business_type=''1''
 and b.org_id =:v_orgId ';
 OPEN p_cursor FOR v_sql using deviceNo,v_orgId;




end proc_findBusys;
/

