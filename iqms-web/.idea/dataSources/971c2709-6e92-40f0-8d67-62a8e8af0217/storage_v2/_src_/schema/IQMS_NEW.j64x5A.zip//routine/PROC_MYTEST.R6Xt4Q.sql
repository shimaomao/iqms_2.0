create procedure          proc_mytest
as

begin


 --select result

 update sys_user u set u.real_name = '张二狗' where u.username='hongxz';

 commit;

end proc_mytest;
/

