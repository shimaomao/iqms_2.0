create procedure          proc_trxyesterday_query (
orgId varchar2, --机构id
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_orgId varchar2(50) := orgId;


begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
if v_orgId = '0' then
  v_orgId := '1';
  end if;
 v_sql := 'select  count(1) yes_total_count,
sum(case when t.cust_type in
(select b.cust_level from bc_custtype b where b.vip_flag=''1'') then 1 else 0 end) yes_vip_total
 from trx_history t inner join  (select *
                 from sys_org o
                where o.deleted = 0
                start with o.org_id =:orgId
               connect by prior o.org_id = o.parent_id) s on (t.org_id = s.org_id)
               where to_char(t.trx_date,''yyyy-mm-dd'')=to_char(sysdate-1,''yyyy-mm-dd'')';--总取号数,vip取号数


 --if v_orgId !=0 then
    -- v_sql := v_sql || ' and t.org_id =:orgId';



   --else
    -- v_orgId := 0;
     --v_sql := v_sql || ' and (t.org_id is null or t.org_id<>:orgId)';



  --end if;

 OPEN p_cursor FOR v_sql using  v_orgId;

end proc_trxyesterday_query;
/

