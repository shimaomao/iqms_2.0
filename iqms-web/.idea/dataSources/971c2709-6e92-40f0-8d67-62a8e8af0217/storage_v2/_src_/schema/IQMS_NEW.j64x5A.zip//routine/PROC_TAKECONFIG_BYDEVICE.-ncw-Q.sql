create procedure          proc_takeconfig_bydevice
(
 --v_styleId in  number,
 --v_screenResolution in  varchar2,
 --v_dateTypeId number,
 orgId number,
 deviceNo varchar2,
 p_cursor out sys_refcursor
)
is
   iRecCount INTEGER;
   i_sql varchar2(4000);
   --i_styleId varchar2(50) := v_styleId;
   --i_screenResolution varchar2(50) := v_screenResolution;
   --i_dateTypeId varchar2(50) := v_dateTypeId;
   i_orgid varchar2(50) := orgId;
   i_deviceNo varchar2(50) := deviceNo;
begin
--b.styleid =: v_styleId  and c.screenresolution= :v_screenResolution
 --     and c.datetypeid=: v_dateTypeId and
      i_sql := 'select c.stylevalue,c.styleid,c.datetypeid,
      c.screenresolution
      from bc_takemodel b
      inner join bc_modelStyle c on(b.styleid=c.styleid)
      where b.org_id=:orgId and b.device_no=: deviceNo';

      OPEN p_cursor FOR i_sql using i_orgid,i_deviceNo;

end proc_takeconfig_bydevice;
/

