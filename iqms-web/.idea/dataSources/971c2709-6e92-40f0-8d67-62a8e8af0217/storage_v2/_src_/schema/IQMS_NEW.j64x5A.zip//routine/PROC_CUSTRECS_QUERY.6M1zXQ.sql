create procedure          proc_custrecs_query (
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --bsc_cust_level 生成custLevels.json
 v_sql := 'select bsc.date_type, bsc.start_position,
bsc.MATE_LENGTH, bsc.start_mate_code,
bsc.end_mate_code, bsc.cust_level, ''inserted'' saveStatus
from bsc_cust_recognition bsc
where bsc.org_id =:orgId and bsc.device_no =:deviceNo ';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;




end proc_custrecs_query;
/

