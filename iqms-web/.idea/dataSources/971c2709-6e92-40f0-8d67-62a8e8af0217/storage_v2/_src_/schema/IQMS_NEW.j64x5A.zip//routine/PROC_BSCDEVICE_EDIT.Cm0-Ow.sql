create PROCEDURE          proc_bscdevice_edit
(
 orgId varchar2,
 deviceNo varchar2,
 hostName varchar2,
 ipAddr varchar2,
 macAddr varchar2,
 currtVer varchar2,
 v_producer varchar2,
 installDate varchar2,
 adminName varchar2,
 adminPhone varchar2,
 netorgcode varchar2,--本地网
 orderflag varchar2,--是否可预约
 pextend1  varchar2,
 pextend2  varchar2,
 pextend3  varchar2,
 screenResolution varchar2,
 onlineModel varchar2,
 tpscrollFlag varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN


 select count(1) into iRecCount from BSC_DEVICE t where t.ip_addr=ipAddr and t.org_id <> orgId;

 if iRecCount > 0 then
   ReturnCode:='2'; --改设备已经存在
   return;
 end if;

 update BSC_DEVICE t set

      t.HOST_NAME = hostName，
      t.IP_ADDR = ipAddr，
      t.MAC_ADDR = macAddr,
      t.PRODUCER = v_producer,
      t.INSTALL_DATE = to_date(installDate,'yyyy-MM-dd'),
      t.ADMIN_NAME = adminName,
      t.ADMIN_PHONE = adminPhone,
      t.NET_ORGCODE = netorgcode,
      t.ORDER_FLAG = orderflag,
      t.EXTEND1 = pextend1,
      t.EXTEND2 = pextend2,
      t.EXTEND3 = pextend3,
      t.screen_resolution = screenResolution,
      t.online_model = onlineModel,
      t.tpscroll_flag = tpscrollFlag
 where t.org_Id = orgId and t.device_no = deviceNo;
 --更新设备状态
--update bsc_device b set b.extend1 = '1' where b.org_id = orgId
--and b.device_no = deviceNo;
proc_deviceupdateflag(deviceNo,'0');
 ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bscdevice_edit;
/

