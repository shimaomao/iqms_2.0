create procedure          PROC_BSCWINBUS_QUERY (
orgId varchar2,
deviceNo varchar2,
winNo varchar2,
buzTypeId varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin
if buzTypeId = '-1' then

 --select result
 v_sql := 'select h.*,dic.dic_value,bsc.business_code,bc.business_name
   from bsc_win_bus h,sys_dic dic,bc_businessmanage bc,
   bsc_branch_business bsc
    where
      h.level_id = dic.dic_key and dic.dic_type=''levelName''
      and h.buz_type_id = bc.business_id and h.buz_type_id = bsc.bus_id
      and bsc.business_type = ''BUS''
     and h.org_id =:orgId and h.device_no =:deviceNo and h.win_no =:winNo';
 OPEN p_cursor FOR v_sql using orgId,deviceNo,winNo;
else
 v_sql := 'select h.*,dic.dic_value,bsc.business_code,bc.business_name
   from bsc_win_bus h,sys_dic dic,bc_businessmanage bc,
   bsc_branch_business bsc
    where
      h.level_id = dic.dic_key and dic.dic_type=''levelName''
      and h.buz_type_id = bc.business_id and h.buz_type_id = bsc.bus_id
      and bsc.business_type = ''BUS''
     and h.org_id =:orgId and h.device_no =:deviceNo and h.win_no =:winNo
     and h.buz_type_id =:buzTypeId';
OPEN p_cursor FOR v_sql using orgId,deviceNo,winNo,buzTypeId;
end if;
end PROC_BSCWINBUS_QUERY;
/

