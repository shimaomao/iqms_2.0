create procedure          proc_takemodel_saveconfig
(
v_styleId in number,
v_styleName in varchar2,
v_styleType in varchar2,
v_screenResolution in varchar2,
v_dateTypeId in varchar2,
--v_styleValue in varchar2,
v_def in varchar2,
orgId in varchar2,
deviceNo in varchar2,
ReturnCode out varchar2
 )
is
 iRecCount INTEGER;
 def_flag INTEGER;
 iStyleName varchar2(50);
 iStyleValue INTEGER;
begin
   --查询指定id的名称
   select b.stylename into iStyleName from bc_takemodel b where b.styleid = v_styleId and b.org_id= orgId and b.device_no=deviceNo;

   if iStyleName = v_styleName then  --名称没有改变时
       if v_def = 1 then --当为默认模板时，其他将被修改为否
           update bc_takemodel b set b.def = 0 where b.org_id =orgId and b.device_no =deviceNo ;

           update bc_takemodel b set
                 b.stylename = v_styleName,
                 b.def = v_def
           where b.styleid = v_styleId ;

           --查询表中是否已有该样式，若有则做更新操作，如无则做新增操作
           select count(1) into iStyleValue from bc_modelStyle c where c.org_id=orgId and c.device_no= deviceNo
           and c.STYLE_ID = v_styleId and c.datetype_id= v_dateTypeId and c.screen_resolution=v_screenResolution ;

           if iStyleValue >0 then
               update bc_modelStyle c set
                      c.DATETYPE_ID = v_dateTypeId,
                      --c.STYLEVALUE = v_styleValue,
                      c.SCREEN_RESOLUTION = v_screenResolution
               where c.ORG_ID = orgId and c.DEVICE_NO = deviceNo and c.STYLE_ID = v_styleId
               and c.datetype_id= v_dateTypeId and c.screen_resolution=v_screenResolution;
           else
               insert into bc_modelStyle c (
                  c.ORG_ID,
                  c.DEVICE_NO,
                  c.STYLE_ID,
                  c.DATETYPE_ID,
                  --c.STYLEVALUE,
                  c.SCREEN_RESOLUTION
               )values(
                  orgId,
                  deviceNo,
                  v_styleId，
                  v_dateTypeId，
                  --v_styleValue，
                  v_screenResolution
               );
           end if;
           ReturnCode:='0';
     else
           update bc_takemodel b set
                   b.stylename = v_styleName,
                   b.def = v_def
           where b.styleid = v_styleId ;

           select count(1) into iStyleValue from bc_modelStyle c where c.org_id=orgId and c.device_no= deviceNo
           and c.STYLE_ID = v_styleId and c.datetype_id= v_dateTypeId and c.screen_resolution=v_screenResolution ;

           if iStyleValue >0 then
                 update bc_modelStyle c set
                        c.DATETYPE_ID = v_dateTypeId,
                        --c.STYLEVALUE = v_styleValue,
                        c.SCREEN_RESOLUTION = v_screenResolution
                 where c.ORG_ID = orgId and c.DEVICE_NO = deviceNo and c.STYLE_ID = v_styleId
                 and c.datetype_id= v_dateTypeId and c.screen_resolution=v_screenResolution;
           else
                 insert into bc_modelStyle c (
                    c.ORG_ID,
                    c.DEVICE_NO,
                    c.STYLE_ID,
                    c.DATETYPE_ID,
                   -- c.STYLEVALUE,
                    c.SCREEN_RESOLUTION
                 )values(
                    orgId,
                    deviceNo,
                    v_styleId，
                    v_dateTypeId，
                  --  v_styleValue，
                    v_screenResolution
                 );
           end if;
           ReturnCode:='0';
     end if ;
   else      --名称改变时
       select count(1) into iRecCount from bc_takemodel b where b.stylename = v_styleName and b.org_id= orgId and b.device_no=deviceNo;
       if iRecCount > 0 then
           ReturnCode:='2';
       else
           if v_def = 1 then --当为默认模板时，其他将被修改为否
               update bc_takemodel b set b.def = 0 where b.org_id =orgId and b.device_no =deviceNo ;

               update bc_takemodel b set
                     b.stylename = v_styleName,
                     b.def = v_def
               where b.styleid = v_styleId ;

               --查询表中是否已有该样式，若有则做更新操作，如无则做新增操作
               select count(1) into iStyleValue from bc_modelStyle c where c.org_id=orgId and c.device_no= deviceNo
               and c.STYLE_ID = v_styleId and c.datetype_id= v_dateTypeId and c.screen_resolution=v_screenResolution ;

               if iStyleValue >0 then
                   update bc_modelStyle c set
                          c.DATETYPE_ID = v_dateTypeId,
                         -- c.STYLEVALUE = v_styleValue,
                          c.SCREEN_RESOLUTION = v_screenResolution
                   where c.ORG_ID = orgId and c.DEVICE_NO = deviceNo and c.STYLE_ID = v_styleId
                   and c.datetype_id= v_dateTypeId and c.screen_resolution=v_screenResolution;
               else
                   insert into bc_modelStyle c (
                      c.ORG_ID,
                      c.DEVICE_NO,
                      c.STYLE_ID,
                      c.DATETYPE_ID,
                      --c.STYLEVALUE,
                      c.SCREEN_RESOLUTION
                   )values(
                      orgId,
                      deviceNo,
                      v_styleId，
                      v_dateTypeId，
                     -- v_styleValue，
                      v_screenResolution
                   );
               end if;
               ReturnCode:='0';
          else
               update bc_takemodel b set
                       b.stylename = v_styleName,
                       b.def = v_def
               where b.styleid = v_styleId ;

               select count(1) into iStyleValue from bc_modelStyle c where c.org_id=orgId and c.device_no= deviceNo
               and c.STYLE_ID = v_styleId and c.datetype_id= v_dateTypeId and c.screen_resolution=v_screenResolution ;

               if iStyleValue >0 then
                     update bc_modelStyle c set
                            c.DATETYPE_ID = v_dateTypeId,
                            --c.STYLEVALUE = v_styleValue,
                            c.SCREEN_RESOLUTION = v_screenResolution
                     where c.ORG_ID = orgId and c.DEVICE_NO = deviceNo and c.STYLE_ID = v_styleId
                     and c.datetype_id= v_dateTypeId and c.screen_resolution=v_screenResolution;
               else
                     insert into bc_modelStyle c (
                        c.ORG_ID,
                        c.DEVICE_NO,
                        c.STYLE_ID,
                        c.DATETYPE_ID,
                        --c.STYLEVALUE,
                        c.SCREEN_RESOLUTION
                     )values(
                        orgId,
                        deviceNo,
                        v_styleId，
                        v_dateTypeId，
                        --v_styleValue，
                        v_screenResolution
                     );
               end if;
               ReturnCode:='0';
          end if ;
       end if ;
   end if ;

   --异常处理
   -- exception
     --   when others then
       --  ReturnCode:='1'; --数据库异常
end proc_takemodel_saveconfig;
/

