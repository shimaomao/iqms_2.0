create PROCEDURE          proc_orderconfig_edit
(
 orderId varchar2,
 beginTime varchar2,
 endTime varchar2 ,
 orderCount varchar2,
 deviceNo varchar2,
 ReturnCode OUT varchar2
)
AS
v_orderCount varchar2(20);
beginCount INTEGER;
endCount INTEGER;
betweenCount INTEGER;
BEGIN
  v_orderCount:= orderCount;
 --查询要增加的时间段是否存在
 select count(1) into beginCount from order_range t where (t.begin_time = beginTime or
 t.end_time = beginTime)
 and t.id <> orderId and t.device_no = deviceNo;
 select count(1) into endCount from order_range t where (t.end_time = endTime or
 t.begin_time = endTime)
 and t.id <> orderId and t.device_no = deviceNo;

 select count(1) into betweenCount from order_range t where (t.begin_time < beginTime
 and  t.end_time > beginTime) or  (t.begin_time < endTime
 and  t.end_time > endTime)
 and t.id <> orderId and t.device_no = deviceNo;

   if beginCount > 0 then
   ReturnCode:='1'; --开始时间已经存在
   elsif endCount>0 then
   ReturnCode:='2';--结束时间已存在
   elsif betweenCount>0 then
   ReturnCode:='3';--时间段重叠
 else
   update order_range t set
      t.begin_time = beginTime,
      t.end_time =endTime,
      t.ordercount = v_orderCount
   where t.id = orderId;
   commit;
   ReturnCode:='0';
   end if;

 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_orderconfig_edit;
/

