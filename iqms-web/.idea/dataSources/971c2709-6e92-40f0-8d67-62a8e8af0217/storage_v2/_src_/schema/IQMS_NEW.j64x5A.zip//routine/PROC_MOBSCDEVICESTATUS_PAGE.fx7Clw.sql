create procedure          proc_mobscdevicestatus_page (
orgId varchar2, --机构id
onLineFlag  varchar2,--是否在线
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(4000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);
   v_orgId varchar2(50) := orgId;
   v_onLineFlag varchar2(50) := onLineFlag;
   v_inervalOnline number;
   v_onLine varchar2(50);

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
if v_orgId = '0' then
  v_orgId := '1';
  end if;
 select p.hb_interval into v_inervalOnline from bc_parameter p;

-- select (case when
 --(h.online_time is null or
 --(TO_NUMBER(sysdate - h.online_time) * 24 * 60)> '||v_inervalOnline||') then '3' else '1' end)
 --into v_onLine from bsc_device h;

  v_sql_condition := 'select h.rowid rid,og.org_id,og.org_name,h.device_no,
     (case when (h.online_time is null or (TO_NUMBER(sysdate - h.online_time) * 24 * 60)> '||v_inervalOnline||') then ''3'' else ''1'' end) ONLINE_FLAG,
     ds.CPU_RATIO,
     ds.MEM_RATIO,
     ds.DISK_RATIO,
     ds.THERMALPRINTER_STATUS THERMALPRINTER_STATUS,
     ds.NEEDLEPRINTER_STATUS NEEDLEPRINTER_STATUS,
     ds.IDREADER_STATUS IDREADER_STATUS,
     ds.SWREAD_STATUS SWREAD_STATUS,
     ds.ICREADER_STATUS ICREADER_STATUS,
     ds.BAR_STATUS BAR_STATUS,
     ds.COMP_STATUS COMP_STATUS,
     ds.VERSION_SEQ,
     h.currt_vername,
     h.last_vername
    from bsc_device h
   inner join (select *
                 from sys_org o
                where o.deleted = 0
                start with o.org_id = :orgId
               connect by prior o.org_id = o.parent_id) og
      on (h.ORG_ID = og.ORG_ID)
    left join bsc_device_status ds
      on (ds.device_no = h.device_no) ';

  -------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'device_no';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||',rid) rnum,
  tt.ORG_ID,tt.DEVICE_NO,tt.CPU_RATIO,tt.MEM_RATIO,tt.DISK_RATIO,tt.VERSION_SEQ,
  tt.ONLINE_FLAG,
  tt.THERMALPRINTER_STATUS,tt.NEEDLEPRINTER_STATUS,tt.IDREADER_STATUS,tt.SWREAD_STATUS,tt.ICREADER_STATUS,tt.BAR_STATUS,
  tt.COMP_STATUS,
  tt.currt_vername,tt.last_vername,tt.org_name
  from ('||v_sql_condition||') tt where  ';

  -- 查询是否在线
  if (onLineFlag is null or onLineFlag = '2') then
      v_onLineFlag := '2';
      v_sql := v_sql || 'tt.ONLINE_FLAG != :v_onLineFlag ';
  else
      v_sql := v_sql || 'tt.ONLINE_FLAG = :v_onLineFlag ';
  end if;


   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';


------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select ORG_ID,
       DEVICE_NO,
       CPU_RATIO,
       MEM_RATIO,
       DISK_RATIO,
       VERSION_SEQ,
       ONLINE_FLAG,
       THERMALPRINTER_STATUS,
       NEEDLEPRINTER_STATUS,
       IDREADER_STATUS,
       SWREAD_STATUS,
       ICREADER_STATUS,
       BAR_STATUS,
       COMP_STATUS,
       currt_vername,
       last_vername,
       org_name  from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_orgId,v_onLineFlag;
     OPEN p_cursor FOR v_sql_page using  v_orgId,v_onLineFlag,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select ORG_ID,
       DEVICE_NO,
       CPU_RATIO,
       MEM_RATIO,
       DISK_RATIO,
       VERSION_SEQ,
       ONLINE_FLAG,
       THERMALPRINTER_STATUS,
       NEEDLEPRINTER_STATUS,
       IDREADER_STATUS,
       SWREAD_STATUS,
       ICREADER_STATUS,
       BAR_STATUS,
       COMP_STATUS,
       currt_vername,
       last_vername,
       org_name from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_orgId,v_onLineFlag;
  end if;

end proc_mobscdevicestatus_page;
/

