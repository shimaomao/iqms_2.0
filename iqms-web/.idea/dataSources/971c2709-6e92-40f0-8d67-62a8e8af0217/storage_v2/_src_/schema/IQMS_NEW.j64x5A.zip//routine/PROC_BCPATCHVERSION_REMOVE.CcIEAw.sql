create PROCEDURE          proc_bcpatchversion_remove
(
 idno varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN
 --获取记录的版本号
 update  bc_patchversion t set t.status='1' where t.id = idno;
 commit;

 ReturnCode := '0';
END proc_bcpatchversion_remove;
/

