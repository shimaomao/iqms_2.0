create PROCEDURE          proc_existActNo
(
 orgCode IN varchar2,  -- 机构编码
 actNo IN varchar2,    -- 激活码
 orderDt in varchar2, -- 预预约日期  2017-10-21
 ReturnCode out varchar2  -- 返回结果  1-可用   0-不可用

)
AS
  recordExists INTEGER DEFAULT 0;

BEGIN
  ReturnCode := 1; -- 可以预约
  -- 查询激活码是否可用，此机构预约日期激活码不重复
 SELECT COUNT(1)  INTO recordExists FROM order_info i  WHERE i.org_code = orgCode
                                                               --and r.dev_no = devNo
                                                               and i.act_no = actNo
                                                               and order_date = orderDt;

  if recordExists > 0 then
     ReturnCode := 0; -- 不可用
     return;
  end if;

END proc_existActNo;
/

