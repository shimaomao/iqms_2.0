create PROCEDURE          proc_bookCancel
(
 orgCode IN varchar2,  -- 机构编码
 actNo in varchar2, --激活码
 orderDt in varchar2,
 certType in varchar2, -- 证件类型
 certContent in varchar2, -- 证件号
 ReturnCode out varchar2  -- 返回结果  0-成功   1-失败

)
AS
  recordExists INTEGER DEFAULT 0;
BEGIN
 ReturnCode := 0; -- 成功
  -- 查询激活码是否可用，此机构预约日期激活码不重复
  SELECT COUNT(1)  INTO recordExists FROM order_info i  WHERE i.org_code = orgCode
                                                               --and r.dev_no = devNo
                                                               and i.act_no = actNo
                                                               and order_date = orderDt;

  if recordExists = 0 then
     ReturnCode := 1; -- 失败
     return;
  end if;




     update ORDER_INFO oi set oi.order_status = '2' where oi.org_code = orgCode and
      oi.order_date = orderDt and
      (oi.act_no = actNo or (oi.cert_type = certType and oi.cert_content=certContent));

ReturnCode := 0;
END proc_bookCancel;
/

