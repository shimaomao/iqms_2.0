create procedure          proc_custlevels_query (
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --bsc_cust_level 生成custLevels.json
 v_sql := 'select bsc.cust_level, bsc.level_name, bsc.business_id,
bsc.prior_time, bsc.call_head, bsc.max_wait_time, bsc.ticket_template,
bsc.is_start
from bsc_cust_level bsc
where bsc.org_id =:orgId and bsc.device_no =:deviceNo ';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;




end proc_custlevels_query;
/

