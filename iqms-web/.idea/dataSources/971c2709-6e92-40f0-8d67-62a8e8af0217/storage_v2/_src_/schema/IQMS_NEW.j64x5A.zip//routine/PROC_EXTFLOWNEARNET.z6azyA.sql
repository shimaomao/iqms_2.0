create procedure          proc_extflownearnet (
orgCode varchar2, --机构编码
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_condition varchar2(2000);
   v_near1 number;
   v_near2 number;
   v_near3 number;
   v_near4 number;
   v_near5 number;
   v_near6 number;
   v_orgId number;
   v_sql_error varchar2(1000);
   v_hasFlag number;
begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

 -- 没有数据的sql
 v_sql_error := 'select * from sys_org where  1=2';

 -- 1.查询机构是否存在
 select count(1) into v_hasFlag from sys_org o where o.org_code = orgCode;
 if v_hasFlag = 0 then   -- 执行错误的返回
   OPEN p_cursor FOR v_sql_error;
   return;
 end if;

 -- 将机构号查询出来
 select o.org_id into v_orgId from sys_org o where o.org_code = orgCode;

 -- 2.查询机构的临近网点配置
 select count(1) into v_hasFlag from bc_near n where n.org_id = v_orgId;

 if v_hasFlag = 0 then   -- 执行错误的返回
   OPEN p_cursor FOR v_sql_error;
   return;
 end if;


 -- 3.查询出所有的临近网点
 select n.org_id1,n.org_id2,n.org_id3,n.org_id4,n.org_id5,n.org_id6 into v_near1,v_near2,v_near3,v_near4,v_near5,v_near6  from bc_near n where n.org_id = v_orgId;


 --4.查询所有临近网点信息
 open p_cursor for select * from sys_org o where o.org_id in (v_near1,v_near2,v_near3,v_near4,v_near5,v_near6);

end proc_extflownearnet;
/

