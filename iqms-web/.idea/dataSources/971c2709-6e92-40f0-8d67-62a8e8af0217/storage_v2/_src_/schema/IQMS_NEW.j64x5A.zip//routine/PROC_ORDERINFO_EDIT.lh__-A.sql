create PROCEDURE          proc_orderinfo_edit
(
 orderId varchar2,
 ticketNo varchar2,
 ReturnCode OUT varchar2
)
AS
v_count integer;

BEGIN

   select count(1) into v_count from order_info where order_id = orderId;
   if v_count != 1 then
     ReturnCode:='1';--未找到预约记录
   else
   update order_info t set
      t.order_status = '1',
      t.modify_date =to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
      t.ticket_no = ticketNo
   where t.order_id = orderId;

   ReturnCode:='0';
   end if;


 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_orderinfo_edit;
/

