create procedure          proc_bscbranchbus_buz (
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin



 v_sql := 'select b.org_id,b.device_no,b.business_type,
b.bus_id,
tree_pid,
 b.business_code,
b.prior_time,b.max_pick_up,b.call_head,
(select bm.business_name from BC_BUSINESSMANAGE bm where b.bus_id= bm.business_id)
 branchName,
b.business_en_name,
b.is_show_en,b.is_swipe,b.pick_up_advice,b.sort_num

 from bsc_branch_business b
 where  b.org_id =:orgId and b.device_no =:deviceNo
 and b.business_type=''1'' ';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;




end proc_bscbranchbus_buz;
/

