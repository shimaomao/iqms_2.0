create PROCEDURE          proc_bscwinconfig_remove
(
 orgId varchar2,
 deviceNo varchar2,
 winNo varchar2,
 ReturnCode OUT varchar2
)
AS

BEGIN
 delete from  BSC_WIN_CONFIG t  where t.org_id = orgId and t.device_no = deviceNo;
 --级联删除 bsc_counterbuz
 delete from  bsc_counterbuz t where t.device_no = deviceNo and t.counterid = winNo;
  --更新设备状态
  --update bsc_device b set b.extend1 = '1' where b.org_id = orgId and b.device_no = deviceNo;
 proc_deviceupdateflag(deviceNo,'0');
 ReturnCode:='0';
END proc_bscwinconfig_remove;
/

