create procedure          proc_bscbranchbus_level (
orgId varchar2,
deviceNo varchar2,
treePid varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin
--,b.org_id,b.device_no,b.tree_id,b.tree_pid
 v_sql := 'select max(levelnum) as lev
 from bsc_branch_business b
 where  b.org_id =:orgId and b.device_no =:deviceNo
  start with b.tree_pid =:treePid
  connect by prior b.tree_pid = tree_id';
 OPEN p_cursor FOR v_sql using orgId,deviceNo,treePid;



end proc_bscbranchbus_level;
/

