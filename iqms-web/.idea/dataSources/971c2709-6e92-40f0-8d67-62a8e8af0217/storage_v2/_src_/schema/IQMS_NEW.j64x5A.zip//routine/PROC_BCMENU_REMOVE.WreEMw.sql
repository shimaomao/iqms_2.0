create PROCEDURE          proc_bcmenu_remove
(
 menuId varchar2,
 ReturnCode OUT varchar2
)
IS

cursor v_deviceNo is
select bus.device_no from bsc_branch_business bus
where bus.business_type = '0' and bus.bus_id = menuId;
v_no v_deviceNo%rowtype;
iRecCount INTEGER;
BEGIN

   delete from bc_menu t where t.menu_id = menuId;
   --更新设备状态
  --update bsc_device b set b.extend1 = '1' where b.device_no in (select bus.device_no from bsc_branch_business bus
  --where bus.business_type = '0' and bus.bus_id = menuId);
  for v_no in v_deviceNo loop
    proc_deviceupdateflag(v_no.device_no,'0');

  end loop;


  --级联删除【业务显示】中有此菜单下挂的业务
  delete from bsc_show_time s where s.device_no in (
  select b.device_no from bsc_branch_business b where b.business_type = '1' and
         b.tree_pid in (select t.tree_id
                          from bsc_branch_business t
                         where t.business_type = '0'
                           and t.bus_id = menuId))
  and s.business_id in (
               select b.bus_id from bsc_branch_business b where b.business_type = '1' and
         b.tree_pid in (select t.tree_id
                          from bsc_branch_business t
                         where t.business_type = '0'
                           and t.bus_id = menuId));
  --级联删除【叫号策略】中配置的菜单下挂的业务
  delete from bsc_counterbuz s where s.device_no in (
  select b.device_no from bsc_branch_business b where b.business_type = '1' and
         b.tree_pid in (select t.tree_id
                          from bsc_branch_business t
                         where t.business_type = '0'
                           and t.bus_id = menuId))
  and s.buztypeid in (
               select b.bus_id from bsc_branch_business b where b.business_type = '1' and
         b.tree_pid in (select t.tree_id
                          from bsc_branch_business t
                         where t.business_type = '0'
                           and t.bus_id = menuId));

  --级联更新【客户级别】中绑定业务为不绑定业务
  update bsc_cust_level c set c.business_id= null where c.device_no in(
  select b.device_no from bsc_branch_business b where b.business_type = '1' and
         b.tree_pid in (select t.tree_id
                          from bsc_branch_business t
                         where t.business_type = '0'
                           and t.bus_id = menuId))
  and c.business_id in (
               select b.bus_id from bsc_branch_business b where b.business_type = '1' and
         b.tree_pid in (select t.tree_id
                          from bsc_branch_business t
                         where t.business_type = '0'
                           and t.bus_id = menuId));
  --级联删除【网点业务】功能中此菜单及此菜单下挂的业务
  delete from bsc_branch_business b where b.business_type = '1' and
         b.tree_pid in (select t.tree_id
                          from bsc_branch_business t
                         where t.business_type = '0'
                           and t.bus_id = menuId);
  delete from bsc_branch_business b where b.business_type = '0' and b.bus_id = menuId;



   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcmenu_remove;
/

