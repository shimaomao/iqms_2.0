create procedure          proc_bscbranchbusiness_query (
orgId varchar2,
deviceNo varchar2,
treeId varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   iRecCount INTEGER;

begin
if treeId ='-1' then

 --select result
 v_sql := 'select b.*,s.org_code,s.org_name,
 decode(b.business_type,''1'',(select bm.business_name from BC_BUSINESSMANAGE bm where b.bus_id= bm.business_id),
 ''0'',(select m.menu_name from bc_menu m where b.bus_id=m.menu_id) ) branchName,
 decode(b.business_type,''1'',(select bm.business_ename from BC_BUSINESSMANAGE bm where b.bus_id= bm.business_id),
 ''0'',(select m.menu_enname from bc_menu m where b.bus_id=m.menu_id) ) businessEnName
 from bsc_branch_business b, SYS_ORG s
 where  b.org_id =:orgId and b.device_no =:deviceNo and  b.org_id = s.org_id';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;
else
 select count(1) into iRecCount from bsc_branch_business b where b.tree_id
 =treeId;
 if iRecCount > 0 then
 v_sql := 'select b.*,s.org_code,s.org_name,
 (select bm.business_name from BC_BUSINESSMANAGE bm where b.bus_id= bm.business_id) branchName,
 (select bm.business_ename from BC_BUSINESSMANAGE bm where b.bus_id= bm.business_id) businessEnName
 from bsc_branch_business b, SYS_ORG s
 where  b.org_id =:orgId and b.device_no =:deviceNo and  b.org_id = s.org_id and b.tree_id=:treeId ';

  OPEN p_cursor FOR v_sql using orgId,deviceNo,treeId;
  else
    v_sql := 'select b.business_name branchName,
    b.business_ename businessEnName
from bc_businessmanage b
 where  b.business_id=:treeId ';

  OPEN p_cursor FOR v_sql using treeId;
    end if;
end if;



end proc_bscbranchbusiness_query;
/

