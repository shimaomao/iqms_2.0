create procedure          proc_orderactive_info (
deviceNo varchar2,
certType varchar2,
certContent varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 if certType = '4' then --激活码
 v_sql :='select oi.order_id,oi.cert_type,oi.cert_content, oi.ORDER_BUSID,oi.ORDER_DATE,oi.RANGE_END from order_info oi
 where oi.act_no =:certContent and oi.dev_no =:deviceNo';
 OPEN p_cursor FOR v_sql using certContent,deviceNo;
 else
  v_sql :='select oi.order_id,oi.cert_type,oi.cert_content, oi.ORDER_BUSID,oi.ORDER_DATE,oi.RANGE_END from order_info oi
 where oi.cert_type =:certType and oi.cert_content =:certContent and oi.dev_no =:deviceNo';
 OPEN p_cursor FOR v_sql using certType,certContent,deviceNo;
 end if;






end proc_orderactive_info;
/

