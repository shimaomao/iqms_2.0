create PROCEDURE          proc_bscdevice_add
(
 orgId varchar2,
 deviceNo varchar2,
 hostName varchar2,
 ipAddr varchar2,
 macAddr varchar2,
 currtVer varchar2,
 v_producer varchar2,
 installDate varchar2,
 adminName varchar2,
 adminPhone varchar2,
 netorgcode varchar2,--本地网
 orderflag varchar2,--是否可预约
 pextend1  varchar2,
 pextend2  varchar2,
 pextend3  varchar2,
 screenResolution varchar2,
 onlineModel varchar2,
 tpscrollFlag varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
custLevel number;
BEGIN

 --查询要增加的记录是否存在
 --select count(1) into iRecCount from DEVICE_INFO t where t.org_code = orgCode and t.device_no = deviceNo;
 select count(1) into iRecCount from BSC_DEVICE t where t.ip_addr=ipAddr or t.device_no = deviceNo;


 if iRecCount > 0 then
   ReturnCode:='3'; --该设备已经存在
 else
   --插入
   insert into BSC_DEVICE (
      ORG_ID,
      DEVICE_NO,
      HOST_NAME，
      IP_ADDR，
      MAC_ADDR,
      CURRT_VER,
      PRODUCER,
      INSTALL_DATE,
      ADMIN_NAME,
      ADMIN_PHONE,
      ONLINE_TIME,
      NET_ORGCODE,
      ORDER_FLAG,

      EXTEND1,
      EXTEND2,
      EXTEND3,
      SCREEN_RESOLUTION,
      Online_Model,
      Tpscroll_Flag
   ) values (
     orgId,
     deviceNo,
     hostName,
     ipAddr,
     macAddr,
     currtVer,
     v_producer,
     to_date(installDate,'yyyy-MM-dd'),
     adminName,
     adminPhone,
     null,
     netorgcode,
     orderflag,

     '1',
     pextend2,
     pextend3,
     screenResolution,
     onlineModel,
     tpscrollFlag
   );

   --在bsc_branch_business里插入菜单'业务类型'
   insert into bsc_branch_business(
   org_id,
   device_no,
   tree_pid,
   tree_id,
   business_type,
   bus_id,
   levelnum,
   max_pick_up)
   values(
   orgId,
   deviceNo,
   '0',
   '1',
   '0',
   1,
   0,
   999
   );
   --插入对应的buztimes
   insert into BSC_SHOW_TIME (
      ORG_ID,
      DEVICE_NO,
      business_id，
      row_id，
      date_type,
      begin_time,
      end_time,
      max_num
   ) values (
     orgId,
     deviceNo,
     1,
     1,
     'H',
     '08:00',
     '23:00',
     999
   );
   insert into BSC_SHOW_TIME (
      ORG_ID,
      DEVICE_NO,
      business_id，
      row_id，
      date_type,
      begin_time,
      end_time,
      max_num
   ) values (
     orgId,
     deviceNo,
     1,
     1,
     'N',
     '08:00',
     '23:00',
     999
   );
   --将设备信息插入bsc_cust_level 表 级别0-9
   custLevel := 0;
   <<repeat_loop>>
   if custLevel < 9 then
     insert into bsc_cust_level (org_id,device_no,cust_level,
     level_name,business_id,prior_time,call_head,
     max_wait_time,ticket_template,is_start)
     values (orgId,
     deviceNo,custLevel,'级别'||custLevel,0,'0',
     '0','0','','1');
   custLevel := custLevel +1;

     GOTO repeat_loop;
   end if;
   ReturnCode:='0';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bscdevice_add;
/

