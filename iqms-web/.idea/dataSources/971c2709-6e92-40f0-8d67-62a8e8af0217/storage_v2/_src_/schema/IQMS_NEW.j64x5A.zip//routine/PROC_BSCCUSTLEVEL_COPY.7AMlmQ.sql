create PROCEDURE          proc_bsccustlevel_copy--应用到下级机构
(
 orgId varchar2,
 deviceNo varchar2,
 targetId varchar2,--目标orgId
 targetNo varchar2, --目标deviceNo
 ReturnCode OUT varchar2
)
AS


    -- 定义游标查询源客户等级信息
    cursor custleveldata_cur is select
      org_id,
      device_no,
      CUST_LEVEL，
      LEVEL_NAME，
      BUSINESS_ID,
      PRIOR_TIME,
      CALL_HEAD,
      MAX_WAIT_TIME,
      TICKET_TEMPLATE,
      IS_START,
      EXTEND1,
      EXTEND2,
      EXTEND3
    from Bsc_Cust_Level w where w.org_id = orgId and w.device_no=deviceNo;


    v_tkttmpId varchar2(30); -- 号票模板id
    v_sorceTkName varchar2(30); -- 源设备的号票模板名称
    v_targetTkId varchar2(30); -- 目标设备的对应的设备Id


BEGIN
if orgId != targetId or targetNo != deviceNo then

 --删除目标数据再插入
 delete from Bsc_Cust_Level b where b.org_id = targetId and b.device_no = targetNo;


 -- 遍历客户等级源的值
  for c_custlevel  in custleveldata_cur loop


      -- 查询出源机构等级绑定的号票模板名称
      if c_custlevel.TICKET_TEMPLATE is not null then

         begin
           select tf.tkttmp_name into v_sorceTkName from bc_ticketform tf where to_char(tf.tkttmp_id) =  c_custlevel.TICKET_TEMPLATE and tf.device_no = deviceNo;
         exception
            when others then
            --异常就设置原模板名称为
            v_sorceTkName:='';
         end;


         -- 通过模板名称查询目标机构此模板的id
         begin
           select tf.tkttmp_id into v_targetTkId from bc_ticketform tf where tf.tkttmp_name = v_sorceTkName and tf.device_no = targetNo;
         exception
            when others then
            --异常就设置原模板名称为
            v_targetTkId:='';
         end;

      else
        v_targetTkId:='';
      end if;
       -- 将数据插入到临时表中
       insert into BSC_CUST_LEVEL_TMP values (targetId,targetNo,
                           c_custlevel.cust_level,
                           c_custlevel.business_id,
                           c_custlevel.prior_time,
                           c_custlevel.call_head,
                           c_custlevel.max_wait_time,
                           v_targetTkId,
                           c_custlevel.is_start,
                           c_custlevel.extend1,
                           c_custlevel.extend2,
                           c_custlevel.extend3,
                           c_custlevel.level_name);
  end loop;


  -- 将临时表数据插入到Bsc_Cust_Level中
   insert into Bsc_Cust_Level (
      ORG_ID,
      DEVICE_NO,
      CUST_LEVEL，
      LEVEL_NAME，
      BUSINESS_ID,
      PRIOR_TIME,
      CALL_HEAD,
      MAX_WAIT_TIME,
      TICKET_TEMPLATE,
      IS_START,
      EXTEND1,
      EXTEND2,
      EXTEND3
   ) select
     tmp.org_id,
     tmp.device_no,
      CUST_LEVEL，
      LEVEL_NAME，
      BUSINESS_ID,
      PRIOR_TIME,
      CALL_HEAD,
      MAX_WAIT_TIME,
      TICKET_TEMPLATE,
      IS_START,
      EXTEND1,
      EXTEND2,
      EXTEND3
    from BSC_CUST_LEVEL_TMP tmp where tmp.org_id = targetId and tmp.device_no=targetNo;

   -- 清理临时表
   delete  from BSC_CUST_LEVEL_TMP tmp where tmp.org_id = targetId and tmp.device_no=targetNo;

   ReturnCode:='0';
end if;
proc_deviceupdateflag(deviceNo,'0');
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bsccustlevel_copy;
/

