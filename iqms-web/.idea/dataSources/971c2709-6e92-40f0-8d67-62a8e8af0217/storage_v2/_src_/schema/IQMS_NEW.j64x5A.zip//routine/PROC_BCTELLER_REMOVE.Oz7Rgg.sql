create PROCEDURE          proc_bcteller_remove
(
 workId varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN
   update bsc_device b set b.extend1 = '1'
   where b.org_id =
   (select t.org_id from bc_teller t where t.work_id = workId);
   delete from  bc_teller t where t.work_id = workId;


   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcteller_remove;
/

