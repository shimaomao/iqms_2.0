create procedure          proc_tree_fastcopy (
orgId in varchar2,  -- 机构id
deviceNo in varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_orgId varchar2(20) :=orgId;
   v_deviceno varchar2(20) :=deviceNo;
   v_screen varchar2(20);
begin

select d.screen_resolution into v_screen from bsc_device d where d.device_no = deviceNo;
  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql := 'select * from view_devtree t where t.deviceno is null or (t.screen = '''||v_screen||'''
  and t.DEVICENO is not null and t.deviceno <> '''||v_deviceno||''')
  start with t.id='''||v_orgId||'''
  connect by prior t.id = t.pid
   ';


    OPEN p_cursor FOR v_sql;

end proc_tree_fastcopy;
/

