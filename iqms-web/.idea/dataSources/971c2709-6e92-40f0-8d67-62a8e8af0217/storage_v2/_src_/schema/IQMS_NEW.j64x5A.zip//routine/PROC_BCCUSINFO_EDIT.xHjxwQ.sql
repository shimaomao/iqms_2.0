create PROCEDURE          proc_bccusinfo_edit
(
 orgId varchar2,
 custId varchar2,
 custName varchar2 ,
 custLevel varchar2 ,
 custPdut varchar2 ,
 custAd varchar2 ,
 isBankEftve varchar2 ,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

   update bc_cusinfo t set
      t.ORG_ID = orgId,
      t.CUST_ID = custId,
      t.CUST_NAME = custName,
      t.CUST_LEVEL = custLevel,
      t.CUST_PDUT = custPdut,
      t.CUST_AD = custAd,
      t.ISBANK_EFTVE = isBankEftve
   where t.CUST_ID = custId;

   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bccusinfo_edit;
/

