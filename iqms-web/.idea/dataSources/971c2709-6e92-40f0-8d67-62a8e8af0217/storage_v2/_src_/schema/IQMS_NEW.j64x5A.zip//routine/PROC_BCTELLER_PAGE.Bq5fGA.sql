create procedure          proc_bcteller_page (
orgId varchar2,--机构id
name_ varchar2, --柜员名称

orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(4000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);
   v_name varchar2(50) := name_;
   v_org_id number := orgId;
begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
if v_org_id = '0' then
  v_org_id := '1';
  end if;
  v_sql_condition := ' select h.org_id,h.rowId rid,h.work_id,h.caller_pwd,h.name_,h.sex,
                     h.status,s.org_code,s.org_name from bc_teller h inner join (select *
                 from sys_org o
                where o.deleted = 0
                start with o.org_id = :orgId
               connect by prior o.org_id = o.parent_id) s
      on (h.ORG_ID = s.ORG_ID)';

  --if v_org_id !=0 then
    -- v_sql_condition := v_sql_condition || ' and s.org_id =:orgId';
  -- else
    -- v_org_id := 0;
    -- v_sql_condition := v_sql_condition || ' and ( s.org_id  is null or s.org_id <>:orgId)';

  --end if;
  if v_name is not null then
     v_sql_condition := v_sql_condition || ' and h.name_ like ''%''||:name_||''%''';
   else
     v_name := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.name_  is null or h.name_ <>:name_)';

  end if;


  -------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'org_code';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||',rid) rnum,tt.org_id,
  tt.work_id,
  tt.caller_pwd,
  tt.name_,
  tt.sex,
  tt.status,
  tt.org_code,
  tt.org_name
   from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';


------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_org_id, v_name;
     OPEN p_cursor FOR v_sql_page using v_org_id, v_name,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using v_org_id, v_name;
  end if;

end proc_bcteller_page;
/

