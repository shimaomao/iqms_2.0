create PROCEDURE          proc_bcmenu_edit
(
 menuId varchar2,
 menuName varchar2,
 menuEnName varchar2 ,
 expend1 varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount1 INTEGER;
iRecCount2 INTEGER;
BEGIN
--查询要增加的记录是否存在
 select count(1) into iRecCount1 from bc_menu t where t.menu_name = menuName
  and t.menu_id != menuId;

  select count(1) into iRecCount2 from bc_menu t where t.menu_enname = menuEnName
  and t.menu_id != menuId;
   if iRecCount1 > 0 then
   ReturnCode:='2'; --该客户名称已经存在

   elsif iRecCount2 > 0 then
   ReturnCode:='3'; --该客户英文名已经存在
 else
   update bc_menu t set
      t.MENU_ID = menuId,
      t.MENU_NAME =menuName,
      t.MENU_ENNAME = menuEnName,
      t.EXTEND1 = expend1
   where t.MENU_ID = menuId;
    --update bsc_device b set b.extend1 = '1';
    proc_deviceupdateflag('','1');
   ReturnCode:='0';
   end if;

 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcmenu_edit;
/

