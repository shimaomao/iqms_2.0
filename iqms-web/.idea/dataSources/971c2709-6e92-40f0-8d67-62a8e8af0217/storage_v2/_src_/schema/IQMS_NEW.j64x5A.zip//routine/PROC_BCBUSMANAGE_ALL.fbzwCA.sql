create procedure          proc_bcbusmanage_all (
businessId varchar2,
p_cursor out sys_refcursor
)
as
   v_sql_condition varchar2(4000);

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := ' select BUSINESS_ID,BUSINESS_NAME,AVERAGE_TIME,ORDER_FLAG from bc_businessmanage h where 1=1  ';

  OPEN p_cursor FOR v_sql_condition;


end proc_bcbusmanage_all;
/

