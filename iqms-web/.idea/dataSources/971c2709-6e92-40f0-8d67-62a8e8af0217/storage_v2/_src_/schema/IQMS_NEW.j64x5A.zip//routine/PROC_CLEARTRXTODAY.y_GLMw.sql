create procedure          proc_cleartrxtoday
 as
    --(删除掉当天除了弃号和完成的数据,或者删除掉当天办理完成但是开始办理时间和结束办理时间相同的记录)
    cursor delerrdata_cur is select * from trx_today t where (t.trx_status <> '2'  and  t.trx_status <> '3')
    or (t.trx_status = '2' and t.begin_time = t.end_time);
 begin
      --遍历游标删除异常数据
      for cur_type in delerrdata_cur
        loop
          delete from trx_history h where h.org_id=cur_type.org_id and h.device_no=cur_type.device_no
          and h.trx_date=cur_type.trx_date and h.flow_no = cur_type.flow_no;
          commit;
        end loop;
      DBMS_Utility.Exec_DDL_Statement('truncate table trx_today');
 end proc_cleartrxtoday;
/

