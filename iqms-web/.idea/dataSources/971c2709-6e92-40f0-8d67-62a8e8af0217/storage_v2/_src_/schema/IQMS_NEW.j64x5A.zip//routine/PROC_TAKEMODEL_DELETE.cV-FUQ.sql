create procedure          proc_takemodel_delete
(
 v_styleId in  varchar2,
 ReturnCode  out varchar2
)
is
v_deviceNo  varchar2(50);
begin

  delete from bc_takemodel b where b.styleid = v_styleId ;
  delete from bc_modelStyle b where b.style_id = v_styleId ;

  select b.device_no into v_deviceNo from bc_takemodel b;
  proc_deviceupdateflag(v_deviceNo,'0');
  ReturnCode:='0';

   --异常处理
   -- exception
    --   when others then
     --  ReturnCode:='1'; --数据库异常
end proc_takemodel_delete;
/

