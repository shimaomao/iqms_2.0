create PROCEDURE          proc_bscdevice_remove
(
 orgId varchar2,
 deviceNo varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN
 --删除所有设备相关的网点配置
 delete from bsc_branch_business t where t.device_no = deviceNo;
 delete from bsc_show_time t where t.device_no = deviceNo;
 delete from bc_ticketform t where t.device_no = deviceNo;
 delete from bsc_win_config t where t.device_no = deviceNo;

 delete from bsc_cust_level t where t.device_no = deviceNo;
 delete from bsc_counterbuz t where t.device_no = deviceNo;
 delete from bsc_cust_recognition t where t.device_no = deviceNo;
 delete from bc_modelstyle t where t.device_no =  deviceNo;
 delete from bc_modelstyle_element t where t.device_no = deviceNo;
 delete from bc_takemodel t where t.device_no = deviceNo;

 delete from  BSC_DEVICE t  where t.org_id = orgId and t.device_no = deviceNo;
 ReturnCode:='0';
END proc_bscdevice_remove;
/

