create procedure          proc_ads_save
(
orgId in  number,
--deviceNo in  varchar2,
advType in  varchar2,
advContent in  varchar2,
ReturnCode out varchar2

)
is
cursor v_device is select t.org_id,d.device_no from (select s.org_id
  from sys_org s
connect by prior s.org_id = s.parent_id
 start with s.org_id = orgId)t left join bsc_device d on (t.org_id = d.org_id);
   v_d v_device%rowtype;
begin
           for v_d in v_device loop
      insert into bsc_adtype b (
              b.ORG_ID,
              b.DEVICE_NO,
              b.adv_type,
              b.adv_content,
              b.CREATE_TIME
           )values(
              v_d.org_id,
              v_d.device_no,
              advType,
              advContent,
              sysdate
           );
       end loop;
 ReturnCode:='0';
end proc_ads_save;
/

