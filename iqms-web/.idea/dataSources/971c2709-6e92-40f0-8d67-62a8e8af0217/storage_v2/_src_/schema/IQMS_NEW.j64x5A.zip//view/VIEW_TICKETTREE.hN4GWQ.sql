create view VIEW_TICKETTREE as
select "ID","DEVICENO","PID","DEVNAME","ISDEV","CURRTVER","LASTVER","CURRTNAME","LASTNAME","TKTTMPID" from (
select to_char(o.org_id) id,'' deviceNo,to_char(o.parent_id) pid,o.org_name devName, '' isDev, -1 currtVer, -1 lastVer, ''currtName, '' lastName,-1 tktTmpId from sys_org o
  union all
  select 'D'||d.device_no id,
         d.device_no deviceNo,
         to_char(d.org_id) pid,
         case when d.producer is not null then '【'||d.producer || '】' || d.host_name else '【null】'||d.host_name end devName,
         '1' isDev,
         d.currt_ver currtVer,
         d.last_ver lastVer,
         d.currt_vername currtName,
         d.last_vername lastName,
         t.tkttmp_id tktTmpId
    from bsc_device d , bc_ticketform t
                 where d.device_no = t.device_no
                   and t.def = '1') tmp
/

