create procedure          proc_buztype_select
(
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor
)
as
   v_sql varchar2(4000);
   v_orgid varchar2(50) := orgId;
   v_deviceNo varchar2(50) := deviceNo;
begin

   if orgId is null or deviceNo is null then
       v_sql := 'select b.business_name,a.bus_id from BSC_BRANCH_BUSINESS a
           inner join bc_businessmanage b on(a.bus_id=b.business_id) where a.business_type=''1''';
       OPEN p_cursor FOR v_sql;
   else
       v_sql := 'select b.business_name,a.bus_id from BSC_BRANCH_BUSINESS a
           inner join bc_businessmanage b on(a.bus_id=b.business_id) where a.business_type=''1''
             and a.org_id =:orgId and a.device_no =:deviceNo ';
       OPEN p_cursor FOR v_sql using v_orgid,v_deviceNo;
   end if;

end proc_buztype_select;
/

