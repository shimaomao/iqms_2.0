create procedure          proc_report_cometime (
orgId in varchar2,
startDate in varchar2,--不能对输入参数重新赋值
endDate in varchar2,
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(20000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);

   v_orgid varchar2(50) := orgId;
   v_startDate varchar2(50) := startDate;
   v_endDate varchar2(50) := endDate;

begin

  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := 'select tempss.org_id,tempss.org_code,tempss.org_name,
               sum(case when tempss.seven_eight=1 then 1 else 0 end) seven_count,
               sum(case when tempss.eight_nine=1 then 1 else 0 end) eight_count,
               sum(case when tempss.nine_ten=1 then 1 else 0 end) nine_count,
               sum(case when tempss.ten_eleven=1 then 1 else 0 end) ten_count,
               sum(case when tempss.eleven_twelve=1 then 1 else 0 end) eleven_count,
               sum(case when tempss.twelve_thirteen=1 then 1 else 0 end) twelve_count,
               sum(case when tempss.thirteen_fourteen=1 then 1 else 0 end) thirteen_count,
               sum(case when tempss.fourteen_fifteen=1 then 1 else 0 end) fourteen_count,
               sum(case when tempss.fifteen_sixteen=1 then 1 else 0 end) fifteen_count,
               sum(case when tempss.sixteen_seveteen=1 then 1 else 0 end) sixteen_count,
               sum(case when tempss.seveteen_eightee=1 then 1 else 0 end) seveteen_count,
               sum(case when tempss.eightee_nineteen=1 then 1 else 0 end) eightee_count
        from
         (select temps.org_id,temps.org_code,temps.org_name,
               (case when temps.time_scale=07 then ''1'' else ''0'' end) seven_eight,
               (case when temps.time_scale=08 then ''1'' else ''0'' end) eight_nine ,
               (case when temps.time_scale=09 then ''1'' else ''0'' end) nine_ten,
               (case when temps.time_scale=10 then ''1'' else ''0'' end) ten_eleven ,
               (case when temps.time_scale=11 then ''1'' else ''0'' end) eleven_twelve,
               (case when temps.time_scale=12 then ''1'' else ''0'' end) twelve_thirteen,
               (case when temps.time_scale=13 then ''1'' else ''0'' end) thirteen_fourteen,
               (case when temps.time_scale=14 then ''1'' else ''0'' end) fourteen_fifteen,
               (case when temps.time_scale=15 then ''1'' else ''0'' end) fifteen_sixteen,
               (case when temps.time_scale=16 then ''1'' else ''0'' end) sixteen_seveteen,
               (case when temps.time_scale=17 then ''1'' else ''0'' end) seveteen_eightee,
               (case when temps.time_scale=18 then ''1'' else ''0'' end) eightee_nineteen
        from
          (select temp.org_id,temp.org_code,temp.org_name,to_number(to_char(temp.print_time,''hh24'')) time_scale
         from
            (select c.org_id,og.org_code,og.org_name,c.trx_date,c.print_time from trx_history c
            inner join (select * from sys_org o where o.deleted=0  start with o.org_id = :v_orgid
            connect by prior o.org_id = o.parent_id) og on (c.org_id=og.org_id)
            where 1=1 ';

  --其他查询条件
  if startDate is not null then
     v_sql_condition := v_sql_condition || 'and to_date(to_char(c.trx_date,''yyyy-MM-dd''),''yyyy-MM-dd'') >= to_date(:startDate,''yyyy-MM-dd'') ';
   else
     v_startDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( c.trx_date  is null or to_char(c.trx_date,''yyyy-MM-dd'') <> :startDate )';

  end if;

  if endDate is not null then
     v_sql_condition := v_sql_condition || 'and to_date(to_char(c.trx_date,''yyyy-MM-dd''),''yyyy-MM-dd'') <= to_date(:endDate,''yyyy-MM-dd'') ';
   else
     v_endDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( c.trx_date  is null or to_char(c.trx_date,''yyyy-MM-dd'') <>:endDate)';

  end if;

  v_sql_condition := v_sql_condition ||' ) temp) temps) tempss group by tempss.org_id,tempss.org_code,tempss.org_name';


-------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'ORG_ID ';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||') rnum,
    tt.ORG_ID,
    tt.ORG_CODE,
    tt.ORG_NAME,
    tt.seven_count,
    tt.eight_count,
    tt.nine_count,
    tt.ten_count,
    tt.eleven_count,
    tt.twelve_count,
    tt.thirteen_count,
    tt.fourteen_count,
    tt.fifteen_count,
    tt.sixteen_count,
    tt.seveteen_count,
    tt.eightee_count
   from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';

------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_orgid,v_startDate,v_endDate;
     OPEN p_cursor FOR v_sql_page using  v_orgid,v_startDate,v_endDate,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_orgid,v_startDate,v_endDate;
  end if;

end proc_report_cometime;
/

