create procedure          proc_ticketform_add
(
 tktTmpId varchar2,
 tktTmpName  varchar2,
 v_def  number,
 tktFormatId  varchar2,
 v_tktFormat  varchar2,
 v_orgId varchar2,
 v_deviceNo varchar2,
 ReturnCode OUT varchar2
)
is
 iRecCount INTEGER;
 defFlag INTEGER;

begin
   --查询要增加的记录是否存在
   select count(1) into iRecCount from bc_ticketform b where b.tkttmp_name = tktTmpName
   and b.device_no = v_deviceNo;

   if iRecCount > 0 then
     ReturnCode:='2'; --该号码模板已经存在
     return;
   end if;

   -- 新增的模板是默认模板，更新此网点，此设备的其他模板为不是默认模板
   if v_def = 1 then
       update bc_ticketform b set b.def = 0 where b.org_id = v_orgId and b.device_no = v_deviceNo;
    end if;

   -- 增加数据
     insert into bc_ticketform t (
         TKTTMP_ID,
         TKTTMP_NAME,
         DEF,
         TKTFORMAT_ID,
         TKTFORMAT,
         TKTTMP_STYLE,
         org_id,
         device_no
     ) values (
         SEQ_BCTICKETFORM.NEXTVAL,
         tktTmpName,
         v_def,
         tktFormatId,
         v_tktFormat,
         null,
         v_orgId,
         v_deviceNo
     );
     --如是默认 模板 择 客户等级 未绑定模板的绑定
    if v_def = 1 then
       update bsc_cust_level c set
       c.ticket_template = (select t.tkttmp_id from bc_ticketform t
       where t.org_id = v_orgId
       and t.device_no = v_deviceNo)
       where c.org_id = v_orgId and c.device_no = v_deviceNo
       and (c.ticket_template is null or c.ticket_template ='0');
    end if;
     ReturnCode:='0';


   --异常处理
   -- exception
     --   when others then
       --  ReturnCode:='1'; --数据库异常

end proc_ticketform_add;
/

