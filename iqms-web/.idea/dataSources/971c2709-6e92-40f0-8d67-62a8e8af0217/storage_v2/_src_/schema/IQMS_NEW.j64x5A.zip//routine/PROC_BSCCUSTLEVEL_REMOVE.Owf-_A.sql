create PROCEDURE          proc_bsccustlevel_remove
(
 orgId varchar2,
 deviceNo varchar2,
 custLevel varchar2,
 ReturnCode OUT varchar2
)
AS

BEGIN
 delete from  BSC_CUST_LEVEL t  where t.org_id = orgId and t.device_no = deviceNo and t.cust_level = custLevel;
 proc_deviceupdateflag(deviceNo,'0');
 ReturnCode:='0';
END proc_bsccustlevel_remove;
/

