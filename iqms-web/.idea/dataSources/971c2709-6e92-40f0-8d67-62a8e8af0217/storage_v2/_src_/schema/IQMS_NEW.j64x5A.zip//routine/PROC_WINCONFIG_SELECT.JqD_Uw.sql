create procedure          proc_winconfig_select
(
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor
)
as
   v_sql varchar2(4000);
   v_orgid varchar2(50) := orgId;
   v_deviceNo varchar2(50) := deviceNo;
begin

   if orgId is null or deviceNo is null then
       v_sql := 'select b.win_id,b.win_no from BSC_WIN_CONFIG b where b.is_start=1
                 order by to_number(b.win_no)';
       OPEN p_cursor FOR v_sql;
   else
       v_sql := 'select b.win_id,b.win_no from BSC_WIN_CONFIG b where b.is_start=1
                 and b.org_id =:orgId and b.device_no =:deviceNo order by to_number(b.win_no)';
       OPEN p_cursor FOR v_sql using v_orgid,v_deviceNo;
   end if;



end proc_winconfig_select;
/

