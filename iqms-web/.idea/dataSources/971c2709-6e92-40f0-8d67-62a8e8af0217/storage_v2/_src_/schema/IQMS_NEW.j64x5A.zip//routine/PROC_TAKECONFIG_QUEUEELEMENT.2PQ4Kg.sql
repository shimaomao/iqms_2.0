create procedure          proc_takeconfig_queueelement
(
v_modelStyleId in number,  -- 样式id
v_orgId in number,  -- 机构id
v_deviceNo in varchar2,  -- 设备编号
v_buzTypeId in varchar2,  -- 业务id
v_type in varchar2,    -- 元素雷星星
v_orgType in varchar2,   -- 控制元素z-index
v_x in number,      --x位置
v_y in number,      -- y位置
v_width in number,   -- 元素长度
v_height in number,  -- 元素高度
v_family in varchar2,  -- 字体
v_style in varchar2,  -- 字形
v_backgroundColor in varchar2,  --元素背景色
v_fontColor in varchar2,  -- 字体颜色
v_size in varchar2,  -- 字体大小
v_icon in varchar2,  -- 元素小图标
v_iconPosition in varchar2,  -- 元素小图标位置
v_borderRadius in varchar2,  -- 是否圆角
v_topLeft1 in number,  -- 圆角参数
v_topRight1 in number,  -- 圆角参数
v_bottomRight1 in number,  -- 圆角参数
v_bottomLeft1 in number,  -- 圆角参数
v_bottomLeft2 in number,  -- 圆角参数
v_bottomRight2 in number,  -- 圆角参数
v_topRight2 in number,  -- 圆角参数
v_topLeft2 in number,  -- 圆角参数
v_shape in varchar2,  -- 形状
v_shadow in varchar2,  -- 阴影
v_shadowH in number,  -- 水平阴影
v_shadowV in number,  -- 垂直阴影
v_shadowBlur in varchar2,  -- 阴影距离
v_skew in varchar2,  -- 倾斜
v_skewH in number,  -- 水平倾斜
v_skewV in number,  -- 垂直倾斜
v_rotate in varchar2,  -- 旋转
v_angleOfRotationX in number,  -- x轴旋转
v_angleOfRotationY in number,  -- y轴旋转
v_angleOfRotationZ in number,  -- z轴旋转
v_effect in varchar2,  -- 效果
v_scrollAmount in number,  -- 跑马灯速度
v_direction in varchar2,  -- 跑马灯方向
v_childrenPageImg in varchar2,  -- 子界面背景图
v_childrenPageColor in varchar2,  -- 子界面背景色
v_backgroundImage in varchar2,  -- 元素背景图片
v_text in varchar2,--文本内容
ReturnCode out varchar2
 )
is
 iRecCount INTEGER;
 iStyleModeId number default 0; --临时记录样式表的id，用于返回
begin



  insert into BC_MODELSTYLE_ELEMENT values (

          v_modelStyleId,
          v_orgId,
          v_deviceNo,
          v_buzTypeId,
          v_type,
          v_orgType,
          v_x,
          v_y,
          v_width,
          v_height,
          v_family,
          v_style,
          v_backgroundColor,
          v_fontColor,
          v_size,
          v_icon,
          v_iconPosition,
          v_borderRadius,
          v_topLeft1,
          v_topRight1,
          v_bottomRight1,
          v_bottomLeft1,
          v_bottomLeft2,
          v_bottomRight2,
          v_topRight2,
          v_topLeft2,
          v_shape,
          v_shadow,
          v_shadowH,
          v_shadowV,
          v_shadowBlur,
          v_skew,
          v_skewH,
          v_skewV,
          v_rotate,
          v_angleOfRotationX,
          v_angleOfRotationY,
          v_angleOfRotationZ,
          v_effect  ,
          v_scrollAmount,
          v_direction,
          v_childrenPageImg ,
          v_childrenPageColor,
          v_backgroundImage,
          v_text
  );



  ReturnCode:='0';

   --异常处理
   -- exception
     --   when others then
       --  ReturnCode:='1'; --数据库异常
end proc_takeconfig_queueelement;
/

