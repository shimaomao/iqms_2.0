create procedure          proc_ticketform_navsave
(
 tktTmpId varchar2,
 tktTmpName  varchar2,
 v_def  number,
 tktFormatId  varchar2,
 v_tktFormat  varchar2,
 v_tktTmpStyle  varchar2,
 v_orgId varchar2,
 v_deviceNo varchar2,
 v_tktTmpIdRet OUT varchar2,
 ReturnCode OUT varchar2
)
is
 iRecCount INTEGER;
 v_tktTmpId INTEGER;
begin
  --1、查询要增加的记录是否存在
  if tktTmpId is null then
   select count(1) into iRecCount from bc_ticketform b where b.tkttmp_name = tktTmpName
   and b.device_no = v_deviceNo;
  else
     select count(1) into iRecCount from bc_ticketform b where b.tkttmp_name = tktTmpName and b.tkttmp_id <> tktTmpId
   and b.device_no = v_deviceNo;

  end if;

   if iRecCount > 0 then
     ReturnCode:='2'; --该号码模板已经存在
     return;
   end if;


   -- 设置所有模板为非默认模板
   update bc_ticketform b set b.def = 0 where b.org_id = v_orgId and b.device_no = v_deviceNo;


  -- 2、增加模板
  if tktTmpId is null then   --  增加模板
     v_tktTmpId := SEQ_BCTICKETFORM.NEXTVAL;  -- 模板不存在就生成一个模板id
     insert into bc_ticketform t (
         TKTTMP_ID,
         TKTTMP_NAME,
         DEF,
         TKTFORMAT_ID,
         TKTFORMAT,
         TKTTMP_STYLE,
         org_id,
         device_no
     ) values (
         v_tktTmpId,
         tktTmpName,
         1,
         tktFormatId,
         v_tktFormat,
         v_tktTmpStyle,
         v_orgId,
         v_deviceNo
     );
  else  -- 更新模板
     v_tktTmpId := tktTmpId;
     update bc_ticketform b set
                   b.tkttmp_name = tktTmpName,
                   b.def = 1,
                   b.tktformat_id = tktFormatId,
                   b.tktformat = v_tktFormat,
                   b.tkttmp_style = v_tktTmpStyle
             where b.tkttmp_id = tktTmpId ;
  end if;

  v_tktTmpIdRet := v_tktTmpId;

    -- 客户等级 未绑定模板的绑定
   update bsc_cust_level c set
     c.ticket_template = v_tktTmpId
     where c.org_id = v_orgId and c.device_no = v_deviceNo
     and c.ticket_template is null;

   ReturnCode:='0';

   proc_deviceupdateflag(v_deviceNo,'0');


   --异常处理
   -- exception
     --   when others then
       --  ReturnCode:='1'; --数据库异常
end proc_ticketform_navsave;
/

