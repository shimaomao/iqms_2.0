create PROCEDURE          proc_bscshowtime_exist
(
 orgId varchar2,
 deviceNo varchar2,

 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

 --查询要增加的记录是否存在
 --select count(1) into iRecCount from DEVICE_INFO t where t.org_code = orgCode and t.device_no = deviceNo;
 select count(1) into iRecCount from BSC_SHOW_TIME t where t.org_id=orgId and t.device_no = deviceNo;



 if iRecCount > 0 then

  ReturnCode:='0'; --已经存在
 else

   ReturnCode:='1';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bscshowtime_exist;
/

