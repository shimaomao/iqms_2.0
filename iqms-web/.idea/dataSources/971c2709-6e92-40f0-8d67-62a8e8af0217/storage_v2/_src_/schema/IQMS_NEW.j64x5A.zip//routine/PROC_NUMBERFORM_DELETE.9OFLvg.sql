create procedure          proc_numberform_delete(
tktFormatId in varchar2,
ReturnCode out varchar2
)
IS
cursor v_deviceNo is
select t.device_no from bc_ticketform t left join bc_numberform n on
t.tktformat_id = n.tktformat_id;
v_no v_deviceNo%rowtype;
begin
  delete from bc_numberform b where b.tktformat_id = tktFormatId ;
  for v_no in v_deviceNo loop
     proc_deviceupdateflag(v_no.device_no,'0');

     end loop;
  ReturnCode:='0';

  --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常

end proc_numberform_delete;
/

