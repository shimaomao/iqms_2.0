create procedure          proc_takeconfig_add
(
 v_styleId in number,
 v_StyleName in varchar2 ,
 v_def in number,
 v_styleType in varchar2,
 orgId in number,
 deviceNo in varchar2,
 ReturnCode out varchar2
)
is
 iRecCount INTEGER;
 defFlag INTEGER;
begin
  --查询是否有同名模板
  select count(1) into iRecCount from bc_takemodel b where b.stylename = v_StyleName and b.org_id= orgId and b.device_no=deviceNo;

  if iRecCount > 0 then
    ReturnCode :='2';
  else
     if v_def = 1 then  --当为默认模板时，其他将被修改为否
         update bc_takemodel b set b.def = 0 where b.org_id =orgId and b.device_no =deviceNo ;

         insert into bc_takemodel t (
                 STYLEID,
                 STYLENAME,
                 DEF,
                 STYLETYPE，
                 ORG_ID，
                 DEVICE_NO
             ) values (
                 SEQ_BCTAKEMODEL.NEXTVAL,
                 v_StyleName,
                 v_def,
                 v_styleType ，
                 orgId，
                 deviceNo
             );
             proc_deviceupdateflag(deviceNo,'0');
         ReturnCode:='0';
     else
         insert into bc_takemodel t (
                 STYLEID,
                 STYLENAME,
                 DEF,
                 STYLETYPE，
                 ORG_ID，
                 DEVICE_NO
             ) values (
                 SEQ_BCTAKEMODEL.NEXTVAL,
                 v_StyleName,
                 v_def,
                 v_styleType，
                 orgId，
                 deviceNo
             );
             proc_deviceupdateflag(deviceNo,'0');
         ReturnCode:='0';
     end if;
  end if;
   --异常处理
   -- exception
     --   when others then
       --  ReturnCode:='1'; --数据库异常

end proc_takeconfig_add;
/

