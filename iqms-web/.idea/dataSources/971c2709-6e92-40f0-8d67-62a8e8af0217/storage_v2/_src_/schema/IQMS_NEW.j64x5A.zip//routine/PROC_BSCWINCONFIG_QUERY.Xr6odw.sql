create procedure          proc_bscwinconfig_query (
orgId varchar2, --机构id
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql:= ' select h.*,s.org_name from bsc_win_config h,sys_org s
   where h.org_id =:org_id and h.device_no =:deviceNo and h.org_id = s.org_id order by h.win_no asc';

OPEN p_cursor FOR v_sql using orgId,deviceNo;


end proc_bscwinconfig_query;
/

