create PROCEDURE          proc_takeconfig_copy --应用到下级机构
(orgId      varchar2,
 deviceNo   varchar2,
 targetId   varchar2, --目标orgId
 targetNo   varchar2, --目标deviceNo
 ReturnCode OUT varchar2) AS
BEGIN
  if orgId != targetId or deviceNo != targetNo then
    --删除目标数据再插入
    delete from bc_takemodel b
     where b.org_id = targetId
       and b.device_no = targetNo;
    delete from bc_modelstyle b
     where b.org_id = targetId
       and b.device_no = targetNo;
    delete from bc_modelstyle_element b
     where b.org_id = targetId
       and b.device_no = targetNo;
    --插入
    insert into bc_takemodel
      (STYLEID, STYLENAME, DEF, STYLETYPE, ORG_ID, DEVICE_NO)
      select SEQ_BCTAKEMODEL.NEXTVAL,
             STYLENAME,
             DEF,
             STYLETYPE,
             targetId,
             targetNo

        from bc_takemodel w
       where w.org_id = orgId
         and w.device_no = deviceNo;

    insert into bc_modelStyle b
      (id,
       ORG_ID,
       DEVICE_NO,
       STYLE_ID,
       DATETYPE_ID,
       copy_status,
       SCREEN_RESOLUTION,
       dpi,
       dpi_x,
       dpi_y)

      select SEQ_MODELSTYLEID.NEXTVAL,
             targetId,
             targetNo,
             (select n.styleid
                from bc_takemodel n
                left join bc_takemodel n1
                  on (n.stylename = n1.stylename and n.def = n1.def and
                     n.styletype = n1.styletype)
               where n.device_no = targetNo
                 and n1.device_no = deviceNo
                 and n1.styleid = w.style_id),
             DATETYPE_ID,
             copy_status,
             SCREEN_RESOLUTION,
             dpi,
             dpi_x,
             dpi_y
        from bc_modelstyle w
       where w.org_id = orgId
         and w.device_no = deviceNo;

    insert into bc_modelstyle_element
      (model_style_id,
       org_id,
       device_no,
       buztype_id,
       element_type,
       org_type,
       element_x,
       element_y,
       element_width,
       element_height,
       element_family,
       element_style,
       element_backgroundcolor,
       element_fontcolor,
       element_size,
       element_icon,
       icon_position,
       element_borderradius,
       borderradiust_topleft1,
       borderradius_topright1,
       borderradius_bottomright1,
       borderradius_bottomleft1,
       borderradius_bottomleft2,
       borderradius_bottomright2,
       borderradius_topright2,
       borderradius_topleft2,
       element_shape,
       element_shadow,
       shadow_h,
       shadow_v,
       shadow_blur,
       element_skew,
       skew_h,
       skew_v,
       element_rotate,
       rotate_x,
       rotate_y,
       rotate_z,
       element_effect,
       effect_scrollamount,
       effect_direction,
       childrenpageimg,
       childrenpagecolor,
       backgroundimage,
       ELEMENT_TEXT)
      select (select n.id
                from bc_modelStyle n
                left join bc_modelStyle n1
                  on (n.datetype_id = n1.datetype_id and
                     n.copy_status = n1.copy_status and
                     n.screen_resolution = n1.screen_resolution and
                     n.dpi = n1.dpi and n.dpi_x = n1.dpi_x and
                     n.dpi_y = n1.dpi_y)
               where n.device_no = targetNo
                 and n1.device_no = deviceNo
                 and n1.id = w.model_style_id),
             targetId,
             targetNo,
             buztype_id,
             element_type,
             org_type,
             element_x,
             element_y,
             element_width,
             element_height,
             element_family,
             element_style,
             element_backgroundcolor,
             element_fontcolor,
             element_size,
             element_icon,
             icon_position,
             element_borderradius,
             borderradiust_topleft1,
             borderradius_topright1,
             borderradius_bottomright1,
             borderradius_bottomleft1,
             borderradius_bottomleft2,
             borderradius_bottomright2,
             borderradius_topright2,
             borderradius_topleft2,
             element_shape,
             element_shadow,
             shadow_h,
             shadow_v,
             shadow_blur,
             element_skew,
             skew_h,
             skew_v,
             element_rotate,
             rotate_x,
             rotate_y,
             rotate_z,
             element_effect,
             effect_scrollamount,
             effect_direction,
             childrenpageimg,
             childrenpagecolor,
             backgroundimage,
             ELEMENT_TEXT
        from bc_modelstyle_element w
       where w.org_id = orgId
         and w.device_no = deviceNo;
         commit;
         proc_deviceupdateflag(deviceNo,'0');
    ReturnCode := '0';
  end if;
  --异常处理
  -- exception
  --   when others then
  --  ReturnCode:='1'; --数据库异常
END proc_takeconfig_copy;
/

