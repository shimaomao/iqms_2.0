create PROCEDURE          proc_bcbusmanage_add
(
 businessName varchar2,
 businessEName varchar2,

 averageTime varchar2 ,
 orderFlag varchar2 ,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
eCount INTEGER;
BEGIN

 --查询要增加的记录是否存在
 select count(1) into iRecCount from bc_businessmanage t where t.business_name = businessName;
 select count(1) into eCount from bc_businessmanage t where t.business_ename = businessEName;
 if iRecCount > 0 then
   ReturnCode:='2'; --该中文名已经存在
 elsif eCount>0 then
  ReturnCode:='3'; --该英文名已经存在
 else
   --插入
   insert into bc_businessmanage t (
      BUSINESS_ID,
      BUSINESS_NAME,
      BUSINESS_ENAME,
      AVERAGE_TIME,
      ORDER_FLAG
   ) values (
     SEQ_BCMENU.NEXTVAL,
     businessName,
     businessEName,
     averageTime,
     orderFlag
   );
   ReturnCode:='0';
   proc_deviceupdateflag('','1');
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcbusmanage_add;
/

