create PROCEDURE          proc_bcnear_edit
(
 orgId  varchar2,
 orgId1 varchar2,
 orgId2 varchar2,
 orgId3 varchar2,
 orgId4 varchar2,
 orgId5 varchar2,
 orgId6 varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN
--查询表中是否存在数据
select count(1) into iRecCount from bc_near t where t.org_id = orgId;
if iRecCount > 0 then
   update bc_near t set
      t.org_id = orgId,
      t.org_id1 =orgId1,
      t.org_id2 =orgId2,
      t.org_id3 =orgId3,
      t.org_id4 =orgId4,
      t.org_id5 =orgId5,
      t.org_id6 =orgId6
      where t.org_id = orgId;

   ReturnCode:='0';
else
  INSERT INTO bc_near t (
      ORG_ID,
      ORG_ID1,
      ORG_ID2,
      ORG_ID3,
      ORG_ID4,
      ORG_ID5,
      ORG_ID6
  ) VALUES (
      orgId,
      orgId1,
      orgId2,
      orgId3,
      orgId4,
      orgId5,
      orgId6
  );
  ReturnCode:='0';
  end if;
 --异常处理
 --exception
    -- when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcnear_edit;
/

