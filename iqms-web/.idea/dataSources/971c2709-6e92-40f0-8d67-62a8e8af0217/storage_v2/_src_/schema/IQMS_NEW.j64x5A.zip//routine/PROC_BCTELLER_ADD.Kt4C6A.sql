create PROCEDURE          proc_bcteller_add
(
 workId varchar2,
 orgId number,
 callerPwd varchar2,
 name_ varchar2,
 sex varchar2,
 status varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

 --查询要增加的记录是否存在
 select count(1) into iRecCount from bc_teller t where t.work_id = workId;

 if iRecCount > 0 then
   ReturnCode:='2'; --该柜员工号已经存在
 else

   --插入
   insert into bc_teller t (
      WORK_ID,
      ORG_ID,
      caller_pwd,
      name_,
      sex,
      status
   ) values (
     workId,
     orgId,
     callerPwd,
     name_,
     sex,
     status
   );
   --更新设备状态
  update bsc_device b set b.extend1 = '1' where b.org_id = orgId;
   ReturnCode:='0';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcteller_add;
/

