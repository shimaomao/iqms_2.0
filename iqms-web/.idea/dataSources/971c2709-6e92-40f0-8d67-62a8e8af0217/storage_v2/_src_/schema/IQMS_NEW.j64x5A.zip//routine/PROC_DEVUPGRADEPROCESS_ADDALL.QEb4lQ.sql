create PROCEDURE proc_DEVUPGRADEPROCESS_addall
(
 patchId varchar2,
 ReturnCode OUT varchar2
)
AS

patchName varchar2(100);
dbFlag varchar2(2);
cursor v_deviceNo is
select d.device_no from bsc_device d;
v_no v_deviceNo%rowtype;
BEGIN




 -- 查询版本的名称和是否包含数据(dbFlag  1-有数据库   0-没有数据)
 select v.patch_name,v.db_flag into patchName,dbFlag from bc_patchversion v where v.id = patchId;
 for v_no in v_deviceNo loop
    --插入
   insert into BSC_DEVUPGRADE_PROCESS (
      id,
      device_no,
      patch_id,
      optDate,
      status
   ) values (
     SEQ_UPGRADEPROCESS.NEXTVAL,
     v_no.device_no,
     patchId,
     sysdate,
      '0' --是否已经下发成功
   );
  end loop;


   -- 将信息更新到设备表中
   update bsc_device d set d.last_ver=patchId,d.last_vername=patchName,d.extend1 = dbFlag ;

   ReturnCode:='0';

 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_DEVUPGRADEPROCESS_addall;
/

