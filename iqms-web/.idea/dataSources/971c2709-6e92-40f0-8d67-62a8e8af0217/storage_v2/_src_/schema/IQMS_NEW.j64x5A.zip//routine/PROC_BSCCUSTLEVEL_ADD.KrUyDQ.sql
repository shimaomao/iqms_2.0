create PROCEDURE          proc_bsccustlevel_add
(
 orgId varchar2,
 deviceNo varchar2,
 custLevel varchar2,
 levelName varchar2,
 businessId varchar2,
 priorTime varchar2,
 callHead varchar2,
 maxWaitTime varchar2,
 ticketTemplate varchar2,
 isStart varchar2,
 extend1 varchar2,
 extend2 varchar2,
 extend3 varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
v_count INTEGER;
BEGIN

 --查询要增加的记录是否存在
 --select count(1) into iRecCount from DEVICE_INFO t where t.org_code = orgCode and t.device_no = deviceNo;
 select count(1) into iRecCount from BSC_CUST_LEVEL t where t.cust_level=custLevel and t.device_no = deviceNo and t.org_id = orgId;
 select count(1) into v_count from bsc_counterbuz c where c.levelid = custLevel and c.device_no = deviceNo and c.org_id = orgId;
 if iRecCount > 0 then
   update BSC_CUST_LEVEL t set
      t.ORG_ID = orgId,
      t.DEVICE_NO =deviceNo,
      t.CUST_LEVEL =custLevel,
      t.LEVEL_NAME =levelName,
      t.BUSINESS_ID =businessId,
      t.PRIOR_TIME =priorTime,
      t.CALL_HEAD =callHead,
      t.MAX_WAIT_TIME =maxWaitTime,
      t.TICKET_TEMPLATE =ticketTemplate,
      t.IS_START =isStart,
      t.EXTEND1 =extend1,
      t.EXTEND2 =extend2,
      t.EXTEND3 =extend3
      where t.org_id = orgId
      and t.device_no = deviceNo
      and t.CUST_LEVEL = custLevel;
      --更新设备状态
proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0'; --已经存在
 else
   --插入
   insert into BSC_CUST_LEVEL (
      ORG_ID,
      DEVICE_NO,
      CUST_LEVEL，
      LEVEL_NAME，
      BUSINESS_ID,
      PRIOR_TIME,
      CALL_HEAD,
      MAX_WAIT_TIME,
      TICKET_TEMPLATE,
      IS_START,
      EXTEND1,
      EXTEND2,
      EXTEND3
   ) values (
     orgId,
     deviceNo,
     custLevel,
     levelName,
     businessId,
     priorTime,
     callHead,
     maxWaitTime,
     ticketTemplate,
     isStart,
     extend1,
     extend2,
     extend3
   );
   --更新设备状态
--update bsc_device b set b.extend1 = '1' where b.org_id = orgId
--and b.device_no = deviceNo;
proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0';
 end if;
 if v_count > 0 then
   update bsc_counterbuz c set
   c.custprioritytime = priorTime,
   c.maxwaiting = maxWaitTime
   where c.device_no = deviceNo
   and c.org_id = orgId
   and c.levelid = custLevel;
   end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bsccustlevel_add;
/

