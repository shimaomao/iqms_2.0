create PROCEDURE          proc_orderconfig_remove
(
 orderId varchar2,
 ReturnCode OUT varchar2
)
AS
BEGIN

   delete from order_range t where t.id = orderId;




   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_orderconfig_remove;
/

