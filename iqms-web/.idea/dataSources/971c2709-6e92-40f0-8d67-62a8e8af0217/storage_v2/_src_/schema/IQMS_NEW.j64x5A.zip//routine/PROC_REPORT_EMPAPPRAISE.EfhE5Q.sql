create procedure          proc_report_empappraise (
orgId in varchar2,
workName in varchar2,
startDate in varchar2,--不能对输入参数重新赋值
endDate in varchar2,
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(20000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);

   v_orgid varchar2(50) := orgId;
   v_workName varchar2(50) := workName;
   v_startDate varchar2(50) := startDate;
   v_endDate varchar2(50) := endDate;

begin

  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := 'select  tmp.org_id,tmp.org_code,tmp.org_name,tmp.work_id,tmp.work_name ,
                            (tmp.app_content+tmp.app_soso+tmp.app_discontent+tmp.app_nonapp) total_count,
                             tmp.app_content,
                             tmp.app_soso,
                             tmp.app_discontent,
                             tmp.app_nonapp,
                             to_char(trunc(tmp.app_content/(tmp.app_content+tmp.app_soso+tmp.app_discontent+tmp.app_nonapp),3)*100,''FM999'') rate_content,
                             to_char(trunc(tmp.app_soso/(tmp.app_content+tmp.app_soso+tmp.app_discontent+tmp.app_nonapp),3)*100,''FM999'') rate_soso,
                             to_char(trunc(tmp.app_discontent/(tmp.app_content+tmp.app_soso+tmp.app_discontent+tmp.app_nonapp),3)*100,''FM999'') rate_discontent,
                             to_char(trunc(tmp.app_nonapp/(tmp.app_content+tmp.app_soso+tmp.app_discontent+tmp.app_nonapp),3)*100,''FM999'') rate_nonapp
                      from
                       (select h.org_id,og.org_code,og.org_name,t.work_id,t.name_ work_name,
                            sum(case when h.app_value=3 then 1 else 0 end) app_content,
                            sum(case when h.app_value=2 then 1 else 0 end) app_soso,
                            sum(case when h.app_value=1 then 1 else 0 end) app_discontent,
                            sum(case when h.app_value=0 then 1 else 0 end) app_nonapp
                       from TRX_HISTORY h
                       inner join (select * from sys_org o where o.deleted=0  start with o.org_id = :v_orgid
                       connect by prior o.org_id = o.parent_id) og on (h.org_id=og.org_id)
                       inner join bc_teller t on (t.org_id = h.org_id and t.work_id = h.teller_no)
                       where h.trx_status=''3'' ';

  --其他查询条件
  if workName is not null then
     v_sql_condition := v_sql_condition || ' and t.name_ = :v_workName';
   else
     v_workName := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( t.name_  is null or t.name_ <> :v_workName)';

  end if;

  if startDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') >= to_date(:startDate,''yyyy-MM-dd'') ';
   else
     v_startDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <> :startDate )';

  end if;

  if endDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') <= to_date(:endDate,''yyyy-MM-dd'') ';
   else
     v_endDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <>:endDate)';

  end if;

  v_sql_condition := v_sql_condition ||'  group by h.org_id,og.org_code,og.org_name,t.work_id,t.name_ ) tmp';


-------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'ORG_ID ';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||') rnum,
    tt.ORG_ID,
    tt.ORG_CODE,
    tt.ORG_NAME,
    tt.work_id,
    tt.work_name,
    tt.total_count,
    tt.app_content,
    tt.app_soso,
    tt.app_discontent,
    tt.app_nonapp,
    tt.rate_content ,
    tt.rate_soso ,
    tt.rate_discontent ,
    tt.rate_nonapp
   from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';

------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_orgid,v_workName,v_startDate,v_endDate;
     OPEN p_cursor FOR v_sql_page using  v_orgid,v_workName,v_startDate,v_endDate,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_orgid,v_workName,v_startDate,v_endDate;
  end if;

end proc_report_empappraise;
/

