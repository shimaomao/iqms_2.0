create procedure          proc_nears_query (--查询临近网点信息到客户端
orgId varchar2, --机构id

p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_orgId varchar2(50) := orgId;


begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
v_sql := 'select count(1) totalGetNums,
sum(case when t.trx_status = ''1'' then 1 else 0 end) totalWait,
sum(case when t.trx_status = ''3'' then 1 else 0 end) totalFinished,
sum(case when t.trx_status = ''2'' then 1 else 0 end) totalDeal,
s.org_name
from  trx_today t inner join sys_org s on t.org_id = s.org_id

where
to_char(t.trx_date, ''yyyy/mm/dd'') =
to_char(sysdate,''yyyy/mm/dd'')
and t.org_id = :orgId
group by s.org_name';--总取号数，总等候数，已办理数

 OPEN p_cursor FOR v_sql using v_orgId;

end proc_nears_query;
/

