create PROCEDURE          proc_orderconfig_copy--应用到下级机构
(
 deviceNo varchar2,
 targetId varchar2,--目标orgId
 targetNo varchar2, --目标deviceNo
 ReturnCode OUT varchar2
)
AS
BEGIN
 if  deviceNo != targetNo then
 --删除目标数据再插入
 delete from order_range b where b.device_no = targetNo;

   --插入
   insert into order_range (
      id,
      ORG_CODE,
      device_no,
      begin_time,
      end_time,
      ordercount
   ) select
     SEQ_ORDERRANGE.NEXTVAL,
     s.org_code,
     targetNo,
     begin_time,
     end_time,
     ordercount

    from order_range w,sys_org s where  w.device_no=deviceNo
     and s.org_id = targetId;


   ReturnCode:='0';
end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_orderconfig_copy;
/

