create PROCEDURE          proc_bcbusmanage_edit
(
 businessId varchar2,
 businessName varchar2,
 businessEName varchar2,
 averageTime varchar2 ,
 orderFlag varchar2 ,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
eCount INTEGER;
BEGIN
   select count(1) into iRecCount from bc_businessmanage t where t.business_name = businessName and t.business_id <> businessId;

 if iRecCount > 0 then
   ReturnCode:='2'; --该中文名已经存在
 else
   update bc_businessmanage t set
      t.BUSINESS_ID = businessId,
      t.BUSINESS_NAME =businessName,
      t.business_ename = businessEName,
      t.AVERAGE_TIME = averageTime,
      t.ORDER_FLAG = orderFlag
   where t.BUSINESS_ID = businessId;
proc_deviceupdateflag('','1');
   ReturnCode:='0';
   end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcbusmanage_edit;
/

