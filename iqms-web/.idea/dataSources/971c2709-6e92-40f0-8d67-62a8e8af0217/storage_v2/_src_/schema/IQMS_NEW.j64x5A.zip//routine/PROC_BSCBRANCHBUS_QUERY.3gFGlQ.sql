create procedure          proc_bscbranchbus_query (--查询所有的业务不包括菜单
orgId varchar2,
deviceNo varchar2,

p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --select result
 v_sql := 'select b.*,
 bm.business_name branchName
 from bsc_branch_business b, BC_BUSINESSMANAGE bm
 where  b.org_id =:orgId and b.device_no =:deviceNo
  and b.bus_id = bm.business_id and b.business_type=''BUS''';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;




end proc_bscbranchbus_query;
/

