create procedure          proc_trxtoday_page (
orgId varchar2, --机构id

orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(4000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);
   v_orgId varchar2(50) := orgId;

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
--if v_orgId = '0' then
  --v_orgId := '1';
  --end if;
  v_sql_condition := 'select h.org_id,
       h.rowId rid,
       h.device_no,
       h.trx_date,
       h.flow_no,
       h.bus_id,
       h.bus_type,
       h.cust_type,
       h.pdj_level,
       h.ticket_type,
       h.ticket_no,
       h.cust_id,
       h.card_type,
       h.card_no,
       h.manager_no,
       h.trx_type,
       h.trx_status,
       h.print_time,
       h.call_time,
       h.begin_time,
       h.end_time,
       h.app_value,
       h.win_no,
       h.teller_no,
       h.recall_count,
       h.pause_begintime,
       h.pause_endtime,
       h.call_type,
       h.transfer_count,
       h.buz_flag,
       h.extend1,
       h.extend2,
       h.extend3,
       s.org_code,
      s.org_name,
       b.business_name,
      c.cust_name
  from trx_today h inner join  (select *
                 from sys_org o
                where o.deleted = 0
                start with o.org_id =:orgId
               connect by prior o.org_id = o.parent_id) s on (h.org_id = s.org_id)
               left join  BC_BUSINESSMANAGE b on (h.bus_id = b.business_id)
               left join bc_custtype c on (h.cust_type = c.cust_level)
               where to_char(h.trx_date, ''yyyy/mm/dd'') = to_char(sysdate, ''yyyy/mm/dd'')';


  --if v_orgId !=0 then
    -- v_sql_condition := v_sql_condition || ' and h.org_id =:orgId';
  -- else
    -- v_orgId := 0;
    -- v_sql_condition := v_sql_condition || ' and ( h.org_id  is null or h.org_id <>:orgId)';

  --end if;


  -------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'org_code';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||',rid) rnum,tt.org_id,tt.device_no,tt.trx_date,tt.flow_no,tt.bus_id,tt.bus_type,tt.cust_type,
tt.pdj_level,tt.ticket_type,tt.ticket_no,tt.cust_id,tt.card_type,tt.card_no,
tt.manager_no,tt.trx_type,tt.trx_status,tt.print_time,tt.call_time,tt.begin_time,
tt.end_time,tt.app_value,tt.win_no,tt.teller_no,tt.recall_count,tt.pause_begintime,
tt.pause_endtime,tt.call_type,tt.transfer_count,tt.buz_flag,tt.extend1,
tt.extend2,tt.extend3,tt.org_code,tt.org_name,tt.business_name,tt.cust_name
  from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';


------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_orgId;
     OPEN p_cursor FOR v_sql_page using  v_orgId,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_orgId;
  end if;

end proc_trxtoday_page;
/

