create procedure          proc_extflowdatapad (
orgCode varchar2, --机构编码
showCount in varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_condition varchar2(2000);
begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := 'select
    h.org_id,
    h.device_no,
    to_char(h.trx_date,''yyyy-MM-dd'') trx_date,
    h.flow_no,
    h.bus_id,
    h.bus_type,
    h.cust_type,
    h.pdj_level,
    h.ticket_type,
    h.ticket_no,
    h.cust_id,
    h.card_type,
    h.card_no,
    h.manager_no,
    h.trx_type,
    h.trx_status,
    (select count(1) from trx_today t where t.bus_id=h.bus_id and t.org_id=s.org_id and t.pdj_level = h.pdj_level and t.trx_date = h.trx_date and t.trx_status=1 and t.print_time < h.print_time) wait_num,
    to_char(h.print_time,''yyyy-MM-dd hh24:mi:ss'') print_time,
    to_char(h.call_time,''yyyy-MM-dd hh24:mi:ss'') call_time,
    to_char(h.begin_time,''yyyy-MM-dd hh24:mi:ss'') begin_time,
    to_char(h.end_time,''yyyy-MM-dd hh24:mi:ss'') end_time,
    h.app_value,
    h.win_no,
    h.teller_no,
    h.recall_count,
    h.pause_begintime,
    h.pause_endtime,
    h.call_type,
    h.transfer_count,
    h.buz_flag,
    h.extend1,
    h.extend2,
    h.extend3,
    s.org_code,
    s.org_name,
    b.business_name,
    c.cust_name from trx_today h left join sys_org s on (h.org_id=s.org_id)
                                 left join BC_BUSINESSMANAGE b on (h.bus_id=b.BUSINESS_ID)
                                 left join bc_custtype c  on  (h.CUST_TYPE = c.CUST_LEVEL)
 where s.org_code=:org_code and h.TRX_STATUS = 1 and to_char(h.trx_date,''yyyy-MM-dd'')=to_char(sysdate,''yyyy-MM-dd'') order  by h.print_time desc';
 -- 获取行号
 v_sql := 'select rownum rnum, temp.* from ('||v_sql_condition||') temp ';

  v_sql := 'select * from ('||v_sql||') f where f.rnum <= :showCount ';

 OPEN p_cursor FOR v_sql using orgCode,showCount;

end proc_extflowdatapad;
/

