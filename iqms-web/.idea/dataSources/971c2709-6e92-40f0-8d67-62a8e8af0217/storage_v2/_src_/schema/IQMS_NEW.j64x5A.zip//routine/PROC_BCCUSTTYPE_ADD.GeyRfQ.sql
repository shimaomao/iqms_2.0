create PROCEDURE          proc_bccusttype_add
(
 custLevel varchar2,
 custName varchar2,
 vipFlag varchar2 ,
 smsFlag varchar2 ,
 waitTimeout varchar2,
 presentFlag varchar2,
 isUse varchar2,
 v_expend1 varchar2,
 v_expend2 varchar2,
 v_expend3 varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
v_count INTEGER;
BEGIN

 --查询要增加的记录是否存在
 select count(1) into iRecCount from bc_custtype t where t.cust_level = custLevel;
 select count(1) into v_count from bc_custtype t where t.cust_name= custName;

 if iRecCount > 0 then
   ReturnCode:='2'; --该客户类型已经存在
 elsif  v_count > 0 then --客户名称已存在
     ReturnCode:='3';
 else
   --插入
   insert into bc_custtype t (
      CUST_LEVEL,
      CUST_NAME,
      VIP_FLAG,
      SMS_FLAG,
      WAIT_TIMEOUT,
      PRESENT_FLAG,
      IS_USE,
      EXTEND1,
      EXTEND2,
      EXTEND3
   ) values (
     custLevel,
     custName,
     vipFlag,
     smsFlag,
      waitTimeout,
      presentFlag,
      isUse,
      v_expend1,
      v_expend2,
      v_expend3
   );
   ReturnCode:='0';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bccusttype_add;
/

