create procedure          proc_counterbuz_select
(
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor
)
as
   v_sql varchar2(4000);
   v_orgid varchar2(50) := orgId;
   v_deviceNo varchar2(50) := deviceNo;
   v_orgid2 varchar2(50) := orgId;
   v_deviceNo2 varchar2(50) := deviceNo;
begin

   if orgId is null or deviceNo is null then
       v_sql := 'select m.bus_id,m.business_code,m.business_name,m.prior_time buzPriorityTime,n.cust_level,n.level_name,n.prior_time custPriorityTime,n.max_wait_time from
          (select a.business_code,b.business_name,a.prior_time,a.bus_id from BSC_BRANCH_BUSINESS a inner join bc_businessmanage b on(a.bus_id=b.business_id) where a.business_type=''1''
          ) m,
          (select a.cust_level,a.prior_time,a.max_wait_time,a.level_name from BSC_CUST_LEVEL a
          where a.is_start=1) n
          order by m.business_name,n.cust_level';
       OPEN p_cursor FOR v_sql;
   else
       v_sql := 'select m.bus_id,m.business_code,m.business_name,m.prior_time buzPriorityTime,n.cust_level,n.level_name,n.prior_time custPriorityTime,n.max_wait_time from
          (select a.business_code,b.business_name,a.prior_time,a.bus_id from BSC_BRANCH_BUSINESS a inner join bc_businessmanage b on(a.bus_id=b.business_id) where a.business_type=''1''
          and  a.org_id =:v_orgid and a.device_no =:v_deviceNo) m,
          (select a.cust_level,a.prior_time,a.max_wait_time,a.level_name from BSC_CUST_LEVEL a
          where a.is_start=1 and a.org_id =:v_orgid2 and a.device_no =:v_deviceNo2) n
          order by m.business_name,n.cust_level';
       OPEN p_cursor FOR v_sql using v_orgid,v_deviceNo,v_orgid2,v_deviceNo2;
   end if;

end proc_counterbuz_select;
/

