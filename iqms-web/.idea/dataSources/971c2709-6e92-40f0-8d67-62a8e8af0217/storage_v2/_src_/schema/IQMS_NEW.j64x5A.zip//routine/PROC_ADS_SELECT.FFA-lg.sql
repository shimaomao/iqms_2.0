create procedure          proc_ads_select
(
orgId in  number,
deviceNo in  varchar2,
p_cursor out sys_refcursor
)
is
  v_sql varchar2(4000);
  v_orgid varchar2(50) := orgId;
  v_deviceNo varchar2(50) := deviceNo;
begin
   v_sql := 'select t.*,d.ip_addr
  from (select row_number() over(partition by b.adv_type order by b.create_time desc) rnum,
       b.*
  from bsc_adtype b
 where b.org_id =:v_orgid
   and b.device_no =:v_deviceNo) t
               inner join
               bsc_device d on (d.device_no = t.device_no)
 where t.rnum = 1';

   OPEN p_cursor FOR v_sql using v_orgid,v_deviceNo;

end proc_ads_select;
/

