create PROCEDURE          proc_bsccustlevel_edit
(
 orgId varchar2,
 deviceNo varchar2,
 custLevel varchar2,
 --levelName varchar2,
 businessId varchar2,
 priorTime varchar2,
 callHead varchar2,
 maxWaitTime varchar2,
 ticketTemplate varchar2,
 isStart varchar2,
 extend1 varchar2,
 extend2 varchar2,
 extend3 varchar2,
 ReturnCode OUT varchar2
)
AS

BEGIN

   update BSC_CUST_LEVEL t set
      t.ORG_ID = orgId,
      t.DEVICE_NO =deviceNo,
      t.CUST_LEVEL =custLevel,
     -- t.LEVEL_NAME =levelName,
      t.BUSINESS_ID =businessId,
      t.PRIOR_TIME =priorTime,
      t.CALL_HEAD =callHead,
      t.MAX_WAIT_TIME =maxWaitTime,
      t.TICKET_TEMPLATE =ticketTemplate,
      t.IS_START =isStart,
      t.EXTEND1 =extend1,
      t.EXTEND2 =extend2,
      t.EXTEND3 =extend3
      where t.org_id = orgId
      and t.device_no = deviceNo
      and t.CUST_LEVEL = custLevel;
      proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bsccustlevel_edit;
/

