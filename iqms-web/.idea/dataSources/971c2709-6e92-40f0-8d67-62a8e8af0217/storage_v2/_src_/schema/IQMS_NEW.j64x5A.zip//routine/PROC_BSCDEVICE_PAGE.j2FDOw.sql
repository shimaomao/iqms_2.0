create procedure          proc_bscdevice_page (orgId in varchar2,
islsflag in varchar2,
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(2000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_orgid varchar2(20);
   v_islsflag varchar2(20);
   v_sort varchar2(50);

begin

  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := 'select
                      h.rowId rid,
                      h.ORG_ID,
                      og.ORG_CODE,
                      og.ORG_NAME,
                      h.DEVICE_NO,
                      h.HOST_NAME,
                      h.IP_ADDR,
                      h.MAC_ADDR,
                      h.CURRT_VER,
                      h.CURRT_VERNAME,
                      h.LAST_VERNAME,
                      h.LAST_VER,
                      (case when (h.LAST_VER is null or h.CURRT_VER = h.LAST_VER) then ''1'' else ''0'' end) is_lstversion,
                      h.PRODUCER,
                      to_char(h.INSTALL_DATE,''yyyy-MM-dd'') INSTALL_DATE,
                      h.ADMIN_NAME,
                      h.ADMIN_PHONE,
                      h.NET_ORGCODE,
                      h.ORDER_FLAG,
                      h.EXTEND1,
                      h.EXTEND2,
                      h.EXTEND3,
                      h.screen_resolution,
                      h.online_model,
                      h.tpscroll_flag,
                      to_char(h.ONLINE_TIME,''yyyy-MM-dd hh24:mi:ss'') ONLINE_TIME from BSC_DEVICE h
  inner join (select * from sys_org o where o.deleted=0  start with o.org_id =:v_orgid
  connect by prior o.org_id = o.parent_id) og on (h.ORG_ID=og.ORG_ID) ';

-------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'ORG_ID ';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||',rid) rnum,
     tt.ORG_ID,
    tt.ORG_CODE,
    tt.ORG_NAME,
    tt.DEVICE_NO,
    tt.HOST_NAME,
    tt.IP_ADDR,
    tt.MAC_ADDR,
    tt.CURRT_VER,
    tt.CURRT_VERNAME,
    tt.LAST_VERNAME,
    tt.LAST_VER,
    tt.is_lstversion,
    tt.PRODUCER,
    tt.INSTALL_DATE,
    tt.ADMIN_NAME,
    tt.ADMIN_PHONE,
    tt.NET_ORGCODE,
    tt.ORDER_FLAG,
    tt.EXTEND1,
    tt.EXTEND2,
    tt.EXTEND3,
    tt.screen_resolution,
    tt.online_model,
    tt.tpscroll_flag,
    tt.ONLINE_TIME
   from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';

------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using orgId;
     OPEN p_cursor FOR v_sql_page using  orgId,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  orgId;
  end if;




end proc_bscdevice_page;
/

