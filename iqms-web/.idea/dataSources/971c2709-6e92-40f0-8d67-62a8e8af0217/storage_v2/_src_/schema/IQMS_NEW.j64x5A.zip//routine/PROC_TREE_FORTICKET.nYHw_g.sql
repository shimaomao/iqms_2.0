create procedure          proc_tree_forticket (
orgId in varchar2,  -- 机构id

p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_orgId varchar2(20) :=orgId;

begin


  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql := 'select * from view_tickettree t
  start with t.id='''||v_orgId||'''
  connect by prior t.id = t.pid';


    OPEN p_cursor FOR v_sql;

end proc_tree_forticket;
/

