create procedure          proc_bcnear_query (
orgId varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --select result
 v_sql := 'select * from BC_NEAR b where  b.org_id =:orgId ';
 OPEN p_cursor FOR v_sql using orgId;


end proc_bcnear_query;
/

