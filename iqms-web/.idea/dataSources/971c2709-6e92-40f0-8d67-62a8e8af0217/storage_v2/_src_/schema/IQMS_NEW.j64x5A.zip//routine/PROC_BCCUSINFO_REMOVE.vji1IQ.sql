create PROCEDURE          proc_bccusinfo_remove
(
 custId varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

   delete from  bc_cusinfo t where t.CUST_ID = custId;

   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bccusinfo_remove;
/

