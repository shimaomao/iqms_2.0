create procedure          proc_takeconfig_saveconfig
(
v_styleId in number,  -- 模板id
v_styleName in varchar2,  -- 模板名称
v_styleType in varchar2,  -- 模板类型
v_screenResolution in varchar2,  -- 样式分辨率
v_dateTypeId in varchar2,    -- 样式日期类型
v_copyStatus in varchar2,   -- 是否平日假日相同  1-相同   0- 不同
v_def in varchar2,      --是否默认模板
orgId in varchar2,      -- 机构编号
deviceNo in varchar2,   -- 设备编号
modeStyelId out varchar2,  -- 返回的bc_modelStyle的id
ReturnCode out varchar2
 )
is
 iRecCount INTEGER;
 iStyleModeId number default 0; --临时记录样式表的id，用于返回
begin

  -- 1、更新模板信息  这里面相当于编辑
  select count(1) into iRecCount from bc_takemodel b where b.stylename = v_StyleName and b.org_id= orgId and b.device_no=deviceNo and b.styleid <> v_styleId;

  if iRecCount > 0 then  -- 模板id存在名字相同
    ReturnCode :='2';
    return;
  else
     if v_def = 1 then  --当为默认模板时，其他将被修改为否
         update bc_takemodel b set b.def = 0 where b.org_id =orgId and b.device_no =deviceNo ;
     end if;
     update bc_takemodel b set b.def = v_def,b.stylename=v_styleName where b.org_id =orgId and b.device_no =deviceNo and b.styleid = v_styleId;
  end if;


  -- 保证bc_modelStyle一个分辨率只有，平日，假日两条记录 或者只有平日假日相同，这样的一条记录
  -- 如果保存的数据记录已经存在，就更新记录的是否相同状态，然后根据是否相同状态，如果是平日假日相同状态，就删除另一个日期的配置，
  -- 如果不是平日假日相同状态，就将另外一个平日假日相同状态改为另外一个日期类型

  select count(1) into iRecCount from bc_modelStyle c where c.org_id=orgId and c.device_no= deviceNo
           and c.STYLE_ID = v_styleId and c.DATETYPE_ID= v_dateTypeId and c.SCREEN_RESOLUTION=v_screenResolution;

  if iRecCount > 0 then    --日期类型存在

     select c.id into iStyleModeId  from bc_modelStyle c where c.org_id=orgId and c.device_no= deviceNo
           and c.STYLE_ID = v_styleId and c.DATETYPE_ID= v_dateTypeId and c.SCREEN_RESOLUTION=v_screenResolution;

      -- 更新
      update bc_modelStyle c set c.copy_status=v_copyStatus where c.id = iStyleModeId;

  else

      iStyleModeId:=SEQ_MODELSTYLEID.NEXTVAL;  --计算样式主键
      -- 新增样式记录
       insert into bc_modelStyle c (
            c.ID,
            c.ORG_ID,
            c.DEVICE_NO,
            c.STYLE_ID,
            c.DATETYPE_ID,
            c.COPY_STATUS,
            c.SCREEN_RESOLUTION,
            c.DPI,
            c.DPI_X,
            c.DPI_Y
         )values(
            iStyleModeId,
            orgId,
            deviceNo,
            v_styleId，
            v_dateTypeId，
            v_copyStatus，
            v_screenResolution,
            '100',
            0,
            0
         );
  end if;

  -- 返回样式的主键
  modeStyelId:=to_char(iStyleModeId);

  --删除当前日期类型的配置，代码中会进行重新保存
  delete from BC_MODELSTYLE_ELEMENT me where me.model_style_id = iStyleModeId;

  -- 判断是否是节日，假日相同(如果相同，则删除另一个日期的配置)
  if v_copyStatus = 1 then

       -- 查看另一个日期的配置是否存在
       select count(1) into iRecCount from bc_modelStyle c where c.org_id=orgId and c.device_no= deviceNo
           and c.STYLE_ID = v_styleId and c.DATETYPE_ID <> v_dateTypeId and c.SCREEN_RESOLUTION=v_screenResolution;


       if iRecCount > 0 then

          select c.id into iStyleModeId  from bc_modelStyle c where c.org_id=orgId and c.device_no= deviceNo
             and c.STYLE_ID = v_styleId and c.DATETYPE_ID <> v_dateTypeId and c.SCREEN_RESOLUTION=v_screenResolution;

          -- 删除另一个界面配置元素数据
          delete from BC_MODELSTYLE_ELEMENT me where me.model_style_id = iStyleModeId;

          --删除另一日期样式记录
          delete from bc_modelStyle c where c.id = iStyleModeId;
       end if;
  else

      -- 如果平日，假日不相同，那么找到 那个平日假日相同的记录，修改为平日假日不同，同时设置日期类型和当前保存类型相反
      update bc_modelStyle c set c.copy_status = 0 , c.datetype_id = (case when v_dateTypeId = 1 then 2 else 1  end)
      where c.org_id=orgId and c.device_no= deviceNo
             and c.STYLE_ID = v_styleId and c.copy_status = 1  and c.SCREEN_RESOLUTION=v_screenResolution;
  end if;

  ReturnCode:='0';
  proc_deviceupdateflag(deviceNo,'0');

   --异常处理
   -- exception
     --   when others then
       --  ReturnCode:='1'; --数据库异常
end proc_takeconfig_saveconfig;
/

