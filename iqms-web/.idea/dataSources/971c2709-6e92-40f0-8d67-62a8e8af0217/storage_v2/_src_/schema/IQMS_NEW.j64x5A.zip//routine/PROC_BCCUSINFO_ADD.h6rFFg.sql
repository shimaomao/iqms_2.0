create PROCEDURE          proc_bccusinfo_add
(
 orgId varchar2,
 custId varchar2,
 custName varchar2 ,
 custLevel varchar2 ,
 custPdut varchar2 ,
 custAd varchar2 ,
 isBankEftve varchar2 ,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

 --查询要增加的记录是否存在
 select count(1) into iRecCount from bc_cusinfo t where t.CUST_ID = custId;

 if iRecCount > 0 then
   ReturnCode:='2'; --该客户类型已经存在
 else
   --插入
   insert into bc_cusinfo t (
      ORG_ID,
      CUST_ID,
      CUST_NAME,
      CUST_LEVEL,
      CUST_PDUT,
      CUST_AD,
      ISBANK_EFTVE
   ) values (
     orgId,
     custId,
     custName,
     custLevel,
     custPdut,
     custAd,
     isBankEftve
   );
   ReturnCode:='0';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bccusinfo_add;
/

