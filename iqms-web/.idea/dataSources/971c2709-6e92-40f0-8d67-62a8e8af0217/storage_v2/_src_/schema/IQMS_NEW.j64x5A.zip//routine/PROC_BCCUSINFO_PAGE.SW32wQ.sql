create procedure          proc_bccusinfo_page (
orgId in varchar2,
custId in varchar2,
custName in varchar2,
custLevel in varchar2,
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(2000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);

   v_orgid varchar2(50) := orgId;
   v_custid varchar2(50) := custId;
   v_custname varchar2(50) := custName;
   v_custlevel varchar2(50) := custLevel;

begin

  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := 'select
                      h.ORG_ID,
                      og.ORG_CODE,
                      og.ORG_NAME,
                      h.CUST_ID,
                      h.CUST_NAME,
                      h.CUST_LEVEL,
                      b.CUST_NAME CUS_NAME,
                      h.CUST_PDUT,
                      h.CUST_AD,
                      h.ISBANK_EFTVE,
                      h.rowId rid
                      from BC_CUSINFO h
  inner join (select * from sys_org o where o.deleted=0  start with o.org_id =:v_orgid
  connect by prior o.org_id = o.parent_id) og on (h.ORG_ID=og.ORG_ID)
  inner join BC_CUSTTYPE b on (h.CUST_LEVEL = b.CUST_LEVEL) where 1=1';

  --其他查询条件
  if v_custid is not null then
     v_sql_condition := v_sql_condition || ' and h.CUST_ID like ''%''||:custId ||''%''';
   else
     v_custid := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.CUST_ID  is null or h.CUST_ID <>:custId)';

  end if;

   if v_custname is not null then
     v_sql_condition := v_sql_condition || ' and h.CUST_NAME like ''%''||:custName ||''%''';
   else
     v_custname := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.CUST_NAME  is null or h.CUST_NAME <>:custName)';

  end if;

   if v_custlevel is not null then
     v_sql_condition := v_sql_condition || ' and h.CUST_LEVEL = :custLevel ';
   else
     v_custlevel := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.CUST_LEVEL  is null or h.CUST_LEVEL <>:custLevel)';

  end if;


-------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'ORG_ID ';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||',rid) rnum,
     tt.ORG_ID,
    tt.ORG_CODE,
    tt.ORG_NAME,
    tt.CUST_ID,
    tt.CUST_NAME,
    tt.CUST_LEVEL,
    tt.CUS_NAME,
    tt.CUST_PDUT,
    tt.CUST_AD,
    tt.ISBANK_EFTVE
   from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';

------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_orgid,v_custid,v_custname,v_custlevel;
     OPEN p_cursor FOR v_sql_page using  v_orgid,v_custid,v_custname,v_custlevel,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_orgid,v_custid,v_custname,v_custlevel;
  end if;

end proc_bccusinfo_page;
/

