create procedure          proc_trxtoday_bus(orgId    varchar2, --机构id
                                              p_cursor out sys_refcursor) as
  v_sql   varchar2(4000);
  v_orgId varchar2(50) := orgId;
begin

  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
if v_orgId = '0' then
  v_orgId := '1';
  end if;
  v_sql := 'select

       t.bus_id,
       b.business_name,
       count(1) busCount
  from trx_today t inner join  (select *
                 from sys_org o
                where o.deleted = 0
                start with o.org_id =:orgId
               connect by prior o.org_id = o.parent_id) s on (t.org_id = s.org_id)
  left join bc_businessmanage b
    on (t.bus_id = b.business_id)
    where to_char(t.trx_date, ''yyyy/mm/dd'') = to_char(sysdate,''yyyy/mm/dd'')
    group by t.bus_id,b.business_name order by busCount desc';

  --if v_orgId != 0 then
    --v_sql := v_sql ||
            -- '  where t.bus_id is not null and t.org_id =:orgId
            -- and to_char(t.trx_date, ''yyyy/mm/dd'') = to_char(sysdate,''yyyy/mm/dd'')
            -- group by t.bus_id,b.business_name order by busCount desc';

  --else
    --v_orgId := 0;
    --v_sql   := v_sql ||
               --' where t.bus_id is not null and t.org_id is null or t.org_id<>:orgId
               --and to_char(t.trx_date, ''yyyy/mm/dd'') = to_char(sysdate,''yyyy/mm/dd'')
              -- group by t.bus_id,b.business_name order by busCount desc';

 -- end if;
  -- dbms_output.put_line(v_sql);
  OPEN p_cursor FOR v_sql
    using v_orgId;

end proc_trxtoday_bus;
/

