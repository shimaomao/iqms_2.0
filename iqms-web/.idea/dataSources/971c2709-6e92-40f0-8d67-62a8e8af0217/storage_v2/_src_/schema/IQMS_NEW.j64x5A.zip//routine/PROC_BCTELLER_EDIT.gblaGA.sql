create PROCEDURE          proc_bcteller_edit
(
 workId varchar2,
 orgId number,
 callerPwd varchar2 ,
 v_name_ varchar2 ,
 v_sex varchar2 ,
 v_status varchar2 ,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

   update bc_teller t set
      t.org_id =orgId,
      t.caller_pwd = callerPwd,
      t.name_ = v_name_,
      t.sex = v_sex,
      t.status = v_status
   where t.work_id = workId;
update bsc_device b set b.extend1 = '1' where b.org_id = orgId;

   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcteller_edit;
/

