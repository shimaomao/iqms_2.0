create procedure          proc_takeconfig_getstyle
(
 v_styleId in  number,  -- 模板id
 v_screenResolution in  varchar2,  -- 分辨率
 v_dateTypeId number,  -- 日期类型
 orgId number,  -- 机构id
 deviceNo varchar2,  -- 设备编号
 p_cursor out sys_refcursor,  -- 界面元素列表
 modelstyleInfo_cursor out sys_refcursor  -- 取号界面基本信息
)
is
   iRecCount INTEGER;
   i_modelStyleid number;
begin

      -- 1、查询出bc_modelStyle表中记录id，通过记录id，找到界面配置的元素信息

      select count(1) into iRecCount from bc_modelStyle m
          where m.org_id = orgId
                and m.device_no = deviceNo
                and (m.datetype_id = v_dateTypeId or m.copy_status = 1)
                and m.style_id =  v_styleId
                and m.screen_resolution = v_screenResolution;

      -- 2.如果配置存在，获取取号界面的样式di
      if iRecCount > 0 then
         select m.id into i_modelStyleid  from bc_modelStyle m
         where m.org_id = orgId
         and m.device_no = deviceNo
         and (m.datetype_id = v_dateTypeId or m.copy_status = 1)
         and m.style_id =  v_styleId
         and m.screen_resolution = v_screenResolution;
         -- 3.通过id，查询界面元素配置
          OPEN p_cursor FOR select * from BC_MODELSTYLE_ELEMENT me where me.model_style_id =  i_modelStyleid;


      else
         -- 4.如果没有配置，那么久返回空
         OPEN p_cursor FOR select * from BC_MODELSTYLE_ELEMENT me where 1=2;
      end if;

      open modelstyleInfo_cursor for select t.styleid,t.stylename,t.styletype,ms.screen_resolution,ms.datetype_id,ms.copy_status, '1' stylePath from  bc_takemodel  t left join   bc_modelStyle ms on
                 (t.styleid = ms.style_id and ms.org_id = orgId and ms.device_no = deviceNo and (ms.datetype_id =v_dateTypeId or ms.copy_status = 1))
                 where t.styleid = v_styleId and ms.screen_resolution = v_screenResolution;

end proc_takeconfig_getstyle;
/

