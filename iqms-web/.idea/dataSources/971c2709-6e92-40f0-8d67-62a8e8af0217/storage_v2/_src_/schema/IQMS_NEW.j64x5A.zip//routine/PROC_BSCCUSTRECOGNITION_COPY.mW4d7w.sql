create PROCEDURE          proc_bsccustrecognition_copy--应用到下级机构
(
 orgId varchar2,
 deviceNo varchar2,
 targetId varchar2,--目标orgId
 targetNo varchar2, --目标deviceNo
 ReturnCode OUT varchar2
)
AS
BEGIN
if orgId != targetId or deviceNo != targetNo then

 --删除目标数据再插入
 delete from BSC_CUST_RECOGNITION b where b.org_id = targetId and b.device_no = targetNo;

   --插入
   insert into BSC_CUST_RECOGNITION (
      ORG_ID,
      DEVICE_NO,
      recognition_type,
      row_id,
      date_type,
      start_position,
      mate_length,
      start_mate_code,
      end_mate_code,
      cust_level,
      EXTEND1,
      EXTEND2,
      EXTEND3
   ) select
     targetId,
     targetNo,
      recognition_type,
      row_id,
      date_type,
      start_position,
      mate_length,
      start_mate_code,
      end_mate_code,
      cust_level,
      EXTEND1,
      EXTEND2,
      EXTEND3
    from BSC_CUST_RECOGNITION w where w.org_id = orgId and w.device_no=deviceNo;
    proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0';
end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bsccustrecognition_copy;
/

