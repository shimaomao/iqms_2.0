create PROCEDURE          proc_bscbranchbus_edit
(
 orgId varchar2,
 deviceNo varchar2,
 treeId varchar2,
 treePid varchar2,
 businessEnName varchar2,
 businessType varchar2,
 businessCode varchar2,
 callHead varchar2,
 priorTime varchar2,
 isSwipe varchar2,
 isShowEN varchar2,
 pickUpAdvice varchar2,
 maxPickUp varchar2,
 sortNum varchar2,
 extend1 varchar2,
 extend2 varchar2,
 extend3 varchar2,
 ReturnCode OUT varchar2
)
AS
prefixCount INTEGER;
BEGIN
   select count(1) into prefixCount from BSC_BRANCH_BUSINESS t
 where t.org_id=orgId and t.device_no = deviceNo and t.call_head = callHead
 and t.tree_id != treeId;
 if prefixCount>0 then
   ReturnCode:='2';--呼叫字头不能重复
   else
   update BSC_BRANCH_BUSINESS t set
      t.ORG_ID = orgId,
      t.DEVICE_NO =deviceNo,
      t.TREE_ID =treeId,
      t.business_type = businessType,
      t.TREE_PID =treePid,
      t.BUSINESS_EN_NAME = businessEnName,
      t.BUSINESS_CODE = businessCode,
      t.PRIOR_TIME =priorTime,
      t.CALL_HEAD =callHead,
      t.IS_SWIPE =isSwipe,
      t.IS_SHOW_EN =isShowEn,
      t.PICK_UP_ADVICE =pickUpAdvice,
      t.MAX_PICK_UP = maxPickUp,
      t.SORT_NUM = sortNum,
      t.EXTEND1 =extend1,
      t.EXTEND2 =extend2,
      t.EXTEND3 =extend3
      where t.org_id = orgId
      and t.device_no = deviceNo
      and t.tree_id = treeId;
--更新设备状态
--update bsc_device b set b.extend1 = '1' where b.org_id = orgId
--and b.device_no = deviceNo;
proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0';
   end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bscbranchbus_edit;
/

