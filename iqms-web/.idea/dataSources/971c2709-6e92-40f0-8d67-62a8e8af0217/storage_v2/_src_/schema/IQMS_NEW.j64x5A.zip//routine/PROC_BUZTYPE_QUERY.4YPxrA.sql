create procedure          proc_buztype_query (
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --查询bsc_branch_business 生成buzType.json
 v_sql := 'select b.org_id,b.device_no,b.business_type,
b.bus_id,
tree_pid,
 b.business_code,
b.prior_time,b.max_pick_up,b.call_head,
decode(b.business_type,''1'',(select bm.business_name from BC_BUSINESSMANAGE bm where b.bus_id= bm.business_id),
 ''0'',(select m.menu_name from bc_menu m where b.bus_id=m.menu_id) ) branchName,
decode(b.business_type,''1'',(select bm.business_ename from BC_BUSINESSMANAGE bm where b.bus_id= bm.business_id),
 ''0'',(select m.menu_enname from bc_menu m where b.bus_id=m.menu_id) ) en_name,
 decode(b.business_type,''1'',''1'',
 ''0'',(select m.extend1 from bc_menu m where b.bus_id=m.menu_id) ) isShowed,
b.is_show_en,b.is_swipe,b.pick_up_advice,b.sort_num,b.levelnum

 from bsc_branch_business b
 where  b.org_id =:orgId and b.device_no =:deviceNo';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;




end proc_buztype_query;
/

