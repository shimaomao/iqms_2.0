create procedure          proc_takemodelnav_add
(
 v_StyleName in varchar2 ,
 v_def in number,
 orgId in number,
 deviceNo in varchar2,
 v_styleId out number,
 ReturnCode out varchar2
)
is
 iRecCount INTEGER;
 defFlag INTEGER;
 seqStyleId number;
begin
  --查询是否有同名模板
  select count(1) into iRecCount from bc_takemodel b where b.stylename = v_StyleName and b.org_id= orgId and b.device_no=deviceNo;

  if iRecCount > 0 then
    ReturnCode :='2';
  else
     if v_def = 1 then  --当为默认模板时，其他将被修改为否
         update bc_takemodel b set b.def = 0 where b.org_id =orgId and b.device_no =deviceNo ;
         proc_deviceupdateflag(deviceNo,'0');
     end if;


     seqStyleId := SEQ_BCTAKEMODEL.NEXTVAL;
     insert into bc_takemodel t (
             STYLEID,
             STYLENAME,
             DEF,
             STYLETYPE，
             ORG_ID，
             DEVICE_NO
         ) values (
             seqStyleId,
             v_StyleName,
             v_def,
             '3'，
             orgId，
             deviceNo
         );
     proc_deviceupdateflag(deviceNo,'0');
     v_styleId := seqStyleId;
     ReturnCode:='0';
  end if;
   --异常处理
   -- exception
     --   when others then
       --  ReturnCode:='1'; --数据库异常

end proc_takemodelnav_add;
/

