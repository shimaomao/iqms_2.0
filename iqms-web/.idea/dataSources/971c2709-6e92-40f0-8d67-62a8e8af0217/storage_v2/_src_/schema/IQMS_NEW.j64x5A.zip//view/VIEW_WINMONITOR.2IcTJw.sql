create view VIEW_WINMONITOR as
select t.rowid rid,
       row_number() over(PARTITION BY t.win_no order by t.call_time desc) rnum,
       t.flow_no flowNoDone,--上一个已完成的
       t.app_value app,
       tmp."ORG_ID",
       tmp."DEVICE_NO",
       tmp."TRX_DATE",
       tmp."FLOW_NO" flowNo,--正在办理的
       tmp."BUS_ID",
       tmp."BUS_TYPE",
       tmp."CUST_TYPE",
       tmp."PDJ_LEVEL",
       tmp."TICKET_TYPE",
       tmp."TICKET_NO",
       tmp."CUST_ID",
       tmp."CARD_TYPE",
       tmp."CARD_NO",
       tmp."MANAGER_NO",
       tmp."TRX_TYPE",
       tmp."TRX_STATUS",
       tmp."PRINT_TIME",
       tmp."CALL_TIME",
       tmp."BEGIN_TIME",
       tmp."END_TIME",
       tmp."APP_VALUE",
       tmp."WIN_NO",
       tmp."TELLER_NO",
       tmp."RECALL_COUNT",
       tmp."PAUSE_BEGINTIME",
       tmp."PAUSE_ENDTIME",
       tmp."CALL_TYPE",
       tmp."TRANSFER_COUNT",
       tmp."BUZ_FLAG",
       tmp."EXTEND1",
       tmp."EXTEND2",
       tmp."EXTEND3",
       tmp.WIN_STATUS
  from trx_today t
 inner join (select h.*,
                    case
                      when w.is_start = '0' then
                       '关闭'
                      else
                       '开启'
                    end WIN_STATUS
               from trx_today h
               left join bsc_win_config w
                 on (h.device_no = w.device_no and h.win_no = w.win_no)
              where h.trx_status = '2'
                and trunc(h.trx_date) = trunc(sysdate) and h.call_time in (
                select max(tt.call_time) from trx_today tt where tt.trx_status = '2'
                group by tt.device_no,tt.win_no
                )
                ) tmp
    on (t.win_no = tmp.win_no and t.device_no = tmp.device_no and
       t.trx_date = tmp.trx_date and t.call_time < tmp.call_time)
 where t.trx_status = '3'
/

