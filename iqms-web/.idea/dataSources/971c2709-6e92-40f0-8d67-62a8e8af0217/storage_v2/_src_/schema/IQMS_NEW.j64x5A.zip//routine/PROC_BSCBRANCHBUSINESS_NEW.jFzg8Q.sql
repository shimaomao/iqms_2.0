create procedure          proc_bscbranchbusiness_new (
orgId varchar2,
menuId varchar2,
businessId varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin
if menuId =0 then

 --select result
 v_sql := 'select s.org_name orgName,'''' menuName, bm.business_name businessName
 from  SYS_ORG s, BC_BUSINESSMANAGE bm
 where  s.org_id =:orgId
   and bm.business_id =:business_id';
 OPEN p_cursor FOR v_sql using orgId,businessId;
else
v_sql := 'select s.org_name orgName, m.menu_name menuName, bm.business_name businessName
 from  SYS_ORG s,bc_menu m, BC_BUSINESSMANAGE bm
 where  s.org_id =:orgId and m.menu_id =:menuId
   and bm.business_id =:business_id';
 OPEN p_cursor FOR v_sql using orgId,menuId,businessId;
end if;



end proc_bscbranchbusiness_new;
/

