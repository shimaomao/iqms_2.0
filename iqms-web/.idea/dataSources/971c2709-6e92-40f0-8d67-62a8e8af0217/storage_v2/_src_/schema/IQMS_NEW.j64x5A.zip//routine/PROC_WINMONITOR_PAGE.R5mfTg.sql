create procedure          proc_winmonitor_page (
orgId varchar2, --机构id

orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(4000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);
   v_orgId varchar2(50) := orgId;

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
if v_orgId = '0' then
  v_orgId := '1';
  end if;
  v_sql_condition := 'select t.rid,
       t.rnum,
       t.flowNoDone,
       t.app_value app,
       t.ORG_ID,
       t.DEVICE_NO,
       t.TRX_DATE,
       t.flowNo,
       t.BUS_ID,
       t.BUS_TYPE,
       t.CUST_TYPE,
       t.PDJ_LEVEL,
       t.TICKET_TYPE,
       t.TICKET_NO,
       t.CUST_ID,
       t.CARD_TYPE,
       t.CARD_NO,
       t.MANAGER_NO,
       t.TRX_TYPE,
       t.TRX_STATUS,
       t.PRINT_TIME,
       t.CALL_TIME,
       t.BEGIN_TIME,
       t.END_TIME",
       t.APP_VALUE,
       t.WIN_NO,
       t.TELLER_NO,
       t.RECALL_COUNT,
       t.PAUSE_BEGINTIME,
       t.PAUSE_ENDTIME,
       t.CALL_TYPE,
       t.TRANSFER_COUNT,
       t.BUZ_FLAG,
       t.EXTEND1,
       t.EXTEND2,
       t.EXTEND3,
       t.WIN_STATUS, s.org_code, s.org_name, b.business_name, c.cust_name
  from view_winmonitor t
  inner join (select o.org_code,o.org_name,o.org_id
                 from sys_org o
                where o.deleted = 0
                start with o.org_id = :orgId
               connect by prior o.org_id = o.parent_id) s
      on (t.ORG_ID = s.org_id)
      left join BC_BUSINESSMANAGE b
      on (t.bus_id = b.business_id)
      left join bc_custtype c
      on(t.cust_type = c.cust_level)';





  -------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'org_code';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||',rid) rnum1,tt.rnum,
       tt.flowNoDone,
       tt.APP_VALUE app,
       tt.ORG_ID,tt.DEVICE_NO,tt.TRX_DATE,tt.flowNo,tt.BUS_ID,tt.BUS_TYPE,tt.CUST_TYPE,tt.PDJ_LEVEL,tt.TICKET_TYPE,tt.TICKET_NO,tt.CUST_ID,tt.CARD_TYPE,tt.CARD_NO,tt.MANAGER_NO,tt.TRX_TYPE,tt.TRX_STATUS,tt.PRINT_TIME,tt.CALL_TIME,tt.BEGIN_TIME,tt.END_TIME,tt.APP_VALUE,tt.WIN_NO,tt.TELLER_NO,tt.RECALL_COUNT,tt.PAUSE_BEGINTIME,tt.PAUSE_ENDTIME,tt.CALL_TYPE,tt.TRANSFER_COUNT,tt.BUZ_FLAG,tt.EXTEND1,tt.EXTEND2,tt.EXTEND3,
  tt.WIN_STATUS,tt.org_code, tt.org_name, tt.business_name, tt.cust_name
  from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';


------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select temp.flowNoDone,
    temp.app,
       temp.ORG_ID,temp.DEVICE_NO,temp.TRX_DATE,temp.flowNo,temp.BUS_ID,temp.BUS_TYPE,temp.CUST_TYPE,temp.PDJ_LEVEL,temp.TICKET_TYPE,temp.TICKET_NO,temp.CUST_ID,temp.CARD_TYPE,temp.CARD_NO,temp.MANAGER_NO,temp.TRX_TYPE,temp.TRX_STATUS,temp.PRINT_TIME,temp.CALL_TIME,temp.BEGIN_TIME,temp.END_TIME,temp.APP_VALUE,temp.WIN_NO,temp.TELLER_NO,temp.RECALL_COUNT,temp.PAUSE_BEGINTIME,temp.PAUSE_ENDTIME,temp.CALL_TYPE,temp.TRANSFER_COUNT,temp.BUZ_FLAG,temp.EXTEND1,temp.EXTEND2,temp.EXTEND3,
  temp.WIN_STATUS,temp.org_code, temp.org_name, temp.business_name, temp.cust_name

    from ('||v_sql||') temp where temp.rnum1 >= :v_begin and temp.rnum1 <= :v_end';
    execute immediate v_sql_count into totalrows using v_orgId;
     OPEN p_cursor FOR v_sql_page using  v_orgId,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select temp.* from ('||v_sql||') temp ';
     OPEN p_cursor FOR v_sql_page using  v_orgId;
  end if;

end proc_winmonitor_page;
/

