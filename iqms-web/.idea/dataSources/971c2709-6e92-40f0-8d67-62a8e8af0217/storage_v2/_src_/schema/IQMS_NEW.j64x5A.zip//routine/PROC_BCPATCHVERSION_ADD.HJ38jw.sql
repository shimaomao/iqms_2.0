create procedure          proc_bcpatchversion_add (
 patchName varchar2,
 patchVerno varchar2,
 md5code varchar2,
 patchPath varchar2,
 patchRemark varchar2,
 p_status varchar2,
 intactFlag varchar2,
 dbFlag varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN
  select count(1) into iRecCount from bc_patchversion p where p.patch_verno = patchVerno;
   if iRecCount > 0 then
     ReturnCode:='1';
     else
   --插入
   insert into bc_patchversion (
      id,
      patch_Name,
      patch_Md5,
      patch_PATH,
      patch_remark,
      patch_date,
      status,
      PATCH_VERNO,
      INTACT_FLAG,
      DB_FLAG
   ) values (
     SEQ_BCPATCHVERSION.NEXTVAL,
     patchName,
     md5code,
     patchPath,
     patchRemark,
     sysdate,
     '1',
     patchVerno,
     intactFlag,
     dbFlag
   );
   ReturnCode:='0';
   end if;
 --异常处理
  --exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcpatchversion_add;
/

