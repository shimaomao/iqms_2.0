create procedure          proc_ticketform_delete
(
 tktTmpId in varchar2,
 v_orgId varchar2,
 v_deviceNo varchar2,
 ReturnCode out varchar2
)
is
v_def number;
iRecCount INTEGER;
begin
  --查询是否为默认模板
  select b.def into v_def from bc_ticketform b where b.tkttmp_id = tktTmpId;
  if v_def=1 then
    ReturnCode:='1';--默认不可删
   return;
   end if;

   delete from bc_ticketform b where b.tkttmp_id = tktTmpId ;
   --给绑定删除模板的客户等级绑定默认模板，无默认则不绑定
   update bsc_cust_level c set c.ticket_template = (select b.tkttmp_id from bc_ticketform b
   where b.device_no = v_deviceNo and b.def = 1) where c.ticket_template = tktTmpId;




   ReturnCode:='0';

   --异常处理
   -- exception
    --   when others then
     --  ReturnCode:='1'; --数据库异常
end proc_ticketform_delete;
/

