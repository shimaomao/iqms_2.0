create procedure          proc_bcmenu_query (
menuId varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --select result
 v_sql := 'select b.menu_name from BC_MENU b,BSC_BRANCH_BUSINESS bsc where  b.menu_id =:menuId
 and b.menu_id = bsc.bus_id and bsc.business_type = ''MENU''';
 OPEN p_cursor FOR v_sql using menuId;


end proc_bcmenu_query;
/

