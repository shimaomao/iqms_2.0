create procedure          proc_device_select
(
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor
)
is
 v_sql varchar2(4000);
 v_orgid varchar2(50) := orgId;
 v_deviceNo varchar2(50) := deviceNo;

begin

            v_sql := ' select b.buzprioritytime,b.custprioritytime,b.maxwaiting,b.levelid,bus.business_name cnName,
                     cus.level_name levelName,bsc.business_code buzCode,b.buztypeid,''true'' saveDjStatus,b.counterid,b.datetypeid
                     from BSC_CounterBuz b
                     inner join bc_businessmanage bus on(b.buztypeid=bus.business_id)
                     inner join bsc_cust_level cus on(b.levelid=cus.cust_level and cus.device_no =:v_deviceNo)
                     inner join BSC_BRANCH_BUSINESS bsc on(b.buztypeid=bsc.bus_id and bsc.device_no =:v_deviceNo)
                     where b.org_id =:v_orgid and b.device_no =:v_deviceNo';

          open p_cursor FOR v_sql using v_deviceNo,v_deviceNo,v_orgid,v_deviceNo;

end proc_device_select;
/

