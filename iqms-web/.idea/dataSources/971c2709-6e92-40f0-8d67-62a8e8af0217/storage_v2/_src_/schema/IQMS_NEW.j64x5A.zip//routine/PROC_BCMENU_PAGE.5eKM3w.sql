create procedure          proc_bcmenu_page (
menuName varchar2, --类型名称

orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(4000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);
   v_menuName varchar2(50) := menuName;

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := ' select MENU_ID,h.rowId rid,MENU_NAME,MENU_ENNAME,EXTEND1 from bc_menu h where 1=1  ';


  if v_menuName is not null then
     v_sql_condition := v_sql_condition || ' and h.menu_name like ''%''||:menuName||''%''';
   else
     v_menuName := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.menu_name  is null or h.menu_name <>:menuName)';

  end if;


  -------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'menu_name ';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||',rid) rnum,tt.MENU_ID,
  tt.MENU_NAME,
  tt.MENU_ENNAME,
  tt.EXTEND1
  from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';


------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_menuName;
     OPEN p_cursor FOR v_sql_page using  v_menuName,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_menuName;
  end if;

end proc_bcmenu_page;
/

