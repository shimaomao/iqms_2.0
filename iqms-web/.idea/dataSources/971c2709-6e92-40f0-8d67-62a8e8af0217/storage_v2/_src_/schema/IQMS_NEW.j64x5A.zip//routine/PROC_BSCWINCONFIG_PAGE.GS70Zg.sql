create procedure          proc_bscwinconfig_page(orgId      varchar2, --机构id
                                                   deviceNo   varchar2,
                                                   orderfield in varchar2,
                                                   ordertype  in varchar2,
                                                   pagesize   in number,
                                                   pageno     in number,
                                                   totalrows  out number,
                                                   p_cursor   out sys_refcursor) as
  v_sql           varchar2(4000);
  v_sql_page      varchar2(4000);
  v_sql_condition varchar2(4000);
  v_sql_count     varchar2(4000);
  v_begin         number := (pageno - 1) * pagesize + 1;
  v_end           number := pageno * pagesize;
  v_sort          varchar2(50);
  v_orgId         varchar2(50) := orgId;
  v_deviceNo      varchar2(50) := deviceNo;

begin
  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := ' select h.ORG_ID,h.rowId rid,h.DEVICE_NO,h.WIN_NO,h.IS_CALL,h.IS_JUDGE,h.WIN_SCREEN,
  h.MULTIPLE_SCREEN,h.IS_START,h.EXTEND1,h.EXTEND2,h.EXTEND3,s.org_code,s.org_name from bsc_win_config h,sys_org s
   where h.org_id=s.org_id ';

  if v_orgId != 0 then
    v_sql_condition := v_sql_condition ||
                       ' and h.org_id =:orgId and h.device_no =:deviceNo';
  else
    v_orgId         := 0;
    v_sql_condition := v_sql_condition ||
                       ' and ( h.org_id  is null or h.org_id <>:orgId)';

  end if;

  -------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
    v_sort := 'org_id ';
  else
    v_sort := orderfield || ' ' || ordertype;
  end if;

  --select result
  v_sql := 'select row_number() over ( order by ' || v_sort || ',rid) rnum,tt.ORG_ID,tt.DEVICE_NO,tt.WIN_NO,tt.IS_CALL,tt.IS_JUDGE,tt.WIN_SCREEN,
  tt.MULTIPLE_SCREEN,tt.IS_START,tt.EXTEND1,tt.EXTEND2,tt.EXTEND3,tt.org_code,tt.org_name
  from (' || v_sql_condition || ') tt ';

  --select count
  v_sql_count := 'select count(1) from (' || v_sql || ')';

  ------------------------------------------------------------3.判断是分页还是查询列表

  if pageno > 0 then
    v_sql_page := 'select * from (' || v_sql ||
                  ') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
    execute immediate v_sql_count
      into totalrows
      using v_orgId, v_deviceNo;
    OPEN p_cursor FOR v_sql_page
      using v_orgId, v_deviceNo, v_begin, v_end;
  else
    totalrows  := 0; --set default value
    v_sql_page := 'select * from (' || v_sql || ') temp ';
    OPEN p_cursor FOR v_sql_page
      using v_orgId, v_deviceNo;
  end if;

end proc_bscwinconfig_page;
/

