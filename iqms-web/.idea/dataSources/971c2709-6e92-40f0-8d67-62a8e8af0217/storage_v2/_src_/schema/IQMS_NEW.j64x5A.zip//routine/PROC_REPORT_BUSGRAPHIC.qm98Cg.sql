create procedure          proc_report_busGraphic (
orgId in varchar2,
busType in varchar2,
startDate in varchar2,--不能对输入参数重新赋值
endDate in varchar2,
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(20000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);

   v_orgid varchar2(50) := orgId;
   v_busType varchar2(50) := busType;
   v_startDate varchar2(50) := startDate;
   v_endDate varchar2(50) := endDate;

begin

  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := ' select temps.bus_id,temps.business_name,
                             count(1) deal_count,
                             sum(case when temps.is_WaitOut=1 then 1 else 0 end) wait_count,
                             sum(case when temps.is_WaitOut=0 then 1 else 0 end) notwait_count,
                             sum(case when temps.deal_TimeOut=1 then 1 else 0 end) dealwait_count,
                             sum(case when temps.deal_TimeOut=0 then 1 else 0 end) notdealwait_count
                       from
                          (select temp.bus_id,temp.business_name,
                             (case when temp.cus_wait >temp.c_wait then ''1'' else ''0'' end) is_WaitOut,
                             (case when temp.bus_wait >temp.b_wait then ''1'' else ''0'' end) deal_TimeOut
                          from
                               (select h.bus_id,b.business_name,
                                  b.average_time b_wait,
                                  c.wait_timeout c_wait,
                                  trunc(((case when h.call_time is null then sysdate else h.call_time end)-h.print_time)*24*60,0) cus_wait,
                                  trunc(((case when h.end_time is null then sysdate else h.end_time end)-h.begin_time)*24*60,0) bus_wait
                               from trx_history h
                               inner join (select * from sys_org o where o.deleted=0  start with o.org_id =:v_orgid
                               connect by prior o.org_id = o.parent_id) og on (h.org_id=og.org_id)
                               left join bc_businessmanage b on (h.bus_id=b.business_id)
                               left join bc_custtype c on (h.cust_type = c.cust_level)
                               where h.trx_status=''3'' ';

  --其他查询条件
  if busType is not null then
     v_sql_condition := v_sql_condition || ' and h.bus_id = :v_busType';
   else
     v_busType := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.bus_id  is null or h.bus_id <> :v_busType)';

  end if;

  if startDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') >= to_date(:startDate,''yyyy-MM-dd'') ';
   else
     v_startDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <> :startDate )';

  end if;

  if endDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') <= to_date(:endDate,''yyyy-MM-dd'') ';
   else
     v_endDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <>:endDate)';

  end if;

  v_sql_condition := v_sql_condition ||' ) temp ) temps group by temps.bus_id,temps.business_name order by temps.bus_id';


    OPEN p_cursor FOR v_sql_condition using  v_orgid,v_busType,v_startDate,v_endDate;

end proc_report_busGraphic;
/

