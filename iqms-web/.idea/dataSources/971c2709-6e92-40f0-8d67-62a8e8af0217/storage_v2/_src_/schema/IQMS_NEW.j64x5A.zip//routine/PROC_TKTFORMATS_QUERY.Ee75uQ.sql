create procedure          proc_tktFormats_query (--号票配置 业务下载
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --查询bsc_win_config 生成counters.json
 v_sql := 'select t.tkttmp_id    tktTmpId,
       t.tkttmp_name  tktTmpName,
       t.def,
       t.tktformat_id tktFormatId,
       n.tktformat    tktFormat,
       t.tkttmp_style print
  from bc_ticketform t
  left join bc_numberform n
    on (t.tktformat_id = n.tktformat_id)
 where t.org_id =:orgId and t.device_no =:deviceNo ';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;




end proc_tktFormats_query;
/

