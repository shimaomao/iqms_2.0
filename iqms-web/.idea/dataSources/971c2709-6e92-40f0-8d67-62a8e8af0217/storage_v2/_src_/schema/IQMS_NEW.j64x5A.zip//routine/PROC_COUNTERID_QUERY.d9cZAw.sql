create procedure          proc_counterId_query (
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --查询bsc_win_config 生成counters.json
 v_sql := 'select distinct(b.counterid) from bsc_counterbuz b
 where  b.org_id =:orgId and b.device_no =:deviceNo';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;




end proc_counterId_query;
/

