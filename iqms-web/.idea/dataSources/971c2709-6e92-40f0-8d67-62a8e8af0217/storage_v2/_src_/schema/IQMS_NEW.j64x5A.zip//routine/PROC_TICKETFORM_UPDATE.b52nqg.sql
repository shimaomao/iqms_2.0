create PROCEDURE          proc_ticketform_update
(
 tktTmpId varchar2,
 tktTmpName  varchar2,
 v_def  number,
 tktFormatId  varchar2,
 v_tktFormat  varchar2,
 v_orgId varchar2,
 v_deviceNo varchar2,
 ReturnCode OUT varchar2
)
AS
 iRecCount INTEGER;
 def_flag INTEGER;
 v_tktTmpName varchar2(50);
BEGIN

  -- 查模板名称重复
  select count(1) into iRecCount  from bc_ticketform b where b.org_id = v_orgId and b.device_no = v_deviceNo and  b.tkttmp_name =  tktTmpName and  b.tkttmp_id <> tktTmpId ;
  if iRecCount > 0 then
     ReturnCode:='2';
     return ;
  end if;

  -- 如果此记录时默认模板，更新设备下的所有模板为非默认模板
  if v_def = 1 then

     update bc_ticketform b set b.def = 0 where b.org_id = v_orgId and b.device_no = v_deviceNo;

     update bsc_cust_level c set
       c.ticket_template = tktTmpId
       where c.org_id = v_orgId and c.device_no = v_deviceNo
       and (c.ticket_template is null or c.ticket_template ='');

  end if;

  -- 更新号票模板记录
  update bc_ticketform b set
                   b.tkttmp_name = tktTmpName,
                   b.def = v_def,
                   b.tktformat_id = tktFormatId,
                   b.tktformat = v_tktFormat
                   -- b.tkttmp_style = null
             where b.tkttmp_id = tktTmpId ;

   proc_deviceupdateflag(v_deviceNo,'0');
   ReturnCode:='0';

   --异常处理
   -- exception
     --   when others then
       --  ReturnCode:='1'; --数据库异常
END proc_ticketform_update;
/

