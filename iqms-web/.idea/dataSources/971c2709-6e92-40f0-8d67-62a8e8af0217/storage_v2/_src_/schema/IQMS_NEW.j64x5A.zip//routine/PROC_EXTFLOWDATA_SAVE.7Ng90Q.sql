create PROCEDURE          proc_extflowdata_save
(
 orgId varchar2,     -- 1001
 deviceNo varchar2 ,  --A0:1D:48:B1:C0:8F
 trxDate varchar2,    -- yyyy-MM-dd需要转换
 flowNo varchar2 ,
 busId varchar2,
  busType varchar2,
 custType varchar2 ,
  pdjLevel number,
 ticketType varchar2 ,
  ticketNo varchar2,
 custId varchar2 ,
  cardType varchar2,
 cardNo varchar2 ,
 managerNo varchar2 ,
 trxType varchar2,
 trxStatus varchar2,
 printTime varchar2 , --要转时间
  callTime varchar2, --要转时间
 beginTime varchar2 ,--要转时间
  endTime varchar2, --要转时间
 appValue varchar2 ,
  winNo varchar2,
 tellerNo varchar2 ,
 recallCount varchar2,
 pauseBeginTime varchar2,
 pauseEndTime varchar2,
 callType varchar2,
 transferCount varchar2,
 buzFlag varchar2,
 extend_1 varchar2 ,
 extend_2 varchar2 ,
 extend_3 varchar2 ,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

 --查询要更新的记录是否存储
 select count(1) into iRecCount from TRX_TODAY t where t.org_id=orgId and t.DEVICE_NO=deviceNo and to_char(t.TRX_DATE,'yyyyMMdd')=trxDate and t.FLOW_NO=flowNo;
--修改该窗口下其他为 正在办理状态的 流水 为已完成
if trxStatus ='2' then
  update TRX_TODAY t set t.trx_status = '3' where t.win_no = winNo and
  t.device_no = deviceNo and t.org_id=orgId and t.FLOW_NO != flowNo;
  commit;
end if;
 if iRecCount > 0 then
   --更新
   update TRX_TODAY t set t.bus_type=busType,t.bus_id = busId,t.cust_type=custType,t.pdj_level=pdjLevel,t.ticket_type=ticketType,
                          t.ticket_no=ticketNo,t.cust_id=custId,t.card_type=cardType,t.card_no=cardNo,t.manager_no=managerNo,t.trx_type = trxType,
                          t.trx_status=trxStatus,
                          t.print_time=case when printTime='' then null else to_date(printTime,'yyyy-MM-dd HH24:mi:ss') end,
                          t.call_time=case when callTime='' then null else to_date(callTime,'yyyy-MM-dd HH24:mi:ss') end,
                          t.begin_time=case when beginTime='' then null else to_date(beginTime,'yyyy-MM-dd HH24:mi:ss') end,
                          t.end_time=case when endTime='' then null else to_date(endTime,'yyyy-MM-dd HH24:mi:ss') end,
                          t.app_value=appValue,t.win_no=winNo,t.teller_no=tellerNo,t.recall_count=recallCount,t.pause_begintime=pauseBeginTime,t.pause_endtime=pauseEndTime,
                          t.call_type=callType,t.transfer_count=transferCount,t.buz_flag=buzFlag,t.extend1=extend_1,t.extend2=extend_2,t.extend3=extend_3
   where t.ORG_ID=orgId and t.DEVICE_NO=deviceNo and to_char(t.TRX_DATE,'yyyyMMdd')=trxDate and t.FLOW_NO=flowNo;
   commit;
   ReturnCode:='0';
 else
   --插入
   insert into TRX_TODAY t (ORG_ID,DEVICE_NO,TRX_DATE,FLOW_NO,bus_id,BUS_TYPE,
      cust_type,PDJ_LEVEL,TICKET_TYPE,TICKET_NO,CUST_ID,CARD_TYPE,
      CARD_NO,MANAGER_NO,trx_type,TRX_STATUS,PRINT_TIME, CALL_TIME, BEGIN_TIME,END_TIME,APP_VALUE, WIN_NO, TELLER_NO,recall_count,pause_begintime,
      pause_endtime,call_type,transfer_count,buz_flag,EXTEND1,EXTEND2,EXTEND3
   ) values (
     orgId,deviceNo,to_date(trxDate,'yyyyMMdd'), flowNo,busId,busType,
     custType,pdjLevel,ticketType,ticketNo,custId,cardType,
     cardNo,managerNo,trxType,trxStatus,
    case when printTime='' then null else to_date(printTime,'yyyy-MM-dd HH24:mi:ss') end,
    case when callTime='' then null else to_date(callTime,'yyyy-MM-dd HH24:mi:ss') end,
    case when beginTime='' then null else to_date(beginTime,'yyyy-MM-dd HH24:mi:ss') end,
    case when endTime='' then null else to_date(endTime,'yyyy-MM-dd HH24:mi:ss') end,
     appValue,winNo,tellerNo,recallCount,pauseBeginTime,pauseEndTime,callType,transferCount,buzFlag,
     extend_1,extend_2,extend_3
   );
   commit;
   ReturnCode:='0';
 end if;
 --异常处理
 -- exception
  --    when others then
  --     ReturnCode:='1';
END proc_extflowdata_save;
/

