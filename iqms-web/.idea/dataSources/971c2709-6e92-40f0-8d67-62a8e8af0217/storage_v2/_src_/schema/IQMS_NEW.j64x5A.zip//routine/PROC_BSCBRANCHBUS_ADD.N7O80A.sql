create PROCEDURE          proc_bscbranchbus_add
(
 orgId varchar2,
 deviceNo varchar2,
 treeId varchar2,
 treePid varchar2,
 businessEnName varchar2,
 businessType varchar2,
 businessCode varchar2,
 callHead varchar2,
 priorTime varchar2,
 isSwipe varchar2,
 isShowEn varchar2,
 pickUpAdvice varchar2,
 maxPickUp varchar2,
 sortNum varchar2,
 extend1 varchar2,
 extend2 varchar2,
 extend3 varchar2,
 busId   varchar2,
 levelNum varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
codeCount1 INTEGER;

timesCount integer;
BEGIN

 --查询要增加的记录是否存在
 --select count(1) into iRecCount from DEVICE_INFO t where t.org_code = orgCode and t.device_no = deviceNo;
 select count(1) into iRecCount from BSC_BRANCH_BUSINESS t where t.org_id=orgId and t.device_no = deviceNo and t.tree_id = treeId;
 select count(1) into timesCount from bsc_show_time t
 where t.device_no = deviceNo and t.business_id = busId;

 select count(1) into codeCount1 from BSC_BRANCH_BUSINESS t where t.device_no = deviceNo
 and t.tree_id <> treeId and t.business_type = businessType
 and t.business_code = businessCode;
 if codeCount1>0 then
   ReturnCode:='2';--业务代码重复
   return;
  end if;
 if iRecCount > 0 then
   update BSC_BRANCH_BUSINESS t set
      t.ORG_ID = orgId,
      t.DEVICE_NO =deviceNo,
      t.tree_id =treeId,
      t.tree_pid =treePid,
      t.BUSINESS_EN_NAME = businessEnName,
      t.business_type = businessType,
      t.BUSINESS_CODE = businessCode,
      t.PRIOR_TIME =priorTime,
      t.CALL_HEAD =callHead,
      t.IS_SWIPE =isSwipe,
      t.IS_SHOW_EN =isShowEn,
      t.PICK_UP_ADVICE =pickUpAdvice,
      t.MAX_PICK_UP = maxPickUp,
      t.SORT_NUM = sortNum,
      t.EXTEND1 =extend1,
      t.EXTEND2 =extend2,
      t.EXTEND3 =extend3,
      t.levelnum = levelNum,
      t.bus_id = busId
      where t.org_id = orgId
      and t.device_no = deviceNo
      and t.tree_id = treeId;
 else
   --插入
   insert into BSC_BRANCH_BUSINESS (
      ORG_ID,
      DEVICE_NO,
      tree_id,
      tree_pid,
      BUSINESS_EN_NAME,
      BUSINESS_TYPE,
      BUSINESS_CODE,
      PRIOR_TIME,
      CALL_HEAD,
      IS_SWIPE,
      IS_SHOW_EN,
      PICK_UP_ADVICE,
      MAX_PICK_UP,
      SORT_NUM,
      EXTEND1,
      EXTEND2,
      EXTEND3,
      bus_id,
      levelnum
   ) values (
     orgId,
     deviceNo,
     treeId,
     treePid,
     businessEnName,
     businessType,
     businessCode,
     priorTime,
     callHead,
     isSwipe,
     isShowEn,
     pickUpAdvice,
     maxPickUp,
     sortNum,
     extend1,
     extend2,
     extend3,
     busId,
     levelNum
   );

   --更新设备状态
--update bsc_device b set b.extend1 = '1' where b.org_id = orgId
--and b.device_no = deviceNo;
 end if;
 if timesCount = 0  then
   insert into BSC_SHOW_TIME (
      ORG_ID,
      DEVICE_NO,
      business_id,
      row_id,
      date_type,
      begin_time,
      end_time,
      max_num
   ) values (
     orgId,
     deviceNo,
     treeId,
     1,
     'N',
     '08:00',
     '23:00',
     999
   );
   insert into BSC_SHOW_TIME (
      ORG_ID,
      DEVICE_NO,
      business_id,
      row_id,
      date_type,
      begin_time,
      end_time,
      max_num
   ) values (
     orgId,
     deviceNo,
     treeId,
     1,
     'H',
     '08:00',
     '23:00',
     999
   );
   end if;

   proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0';

 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bscbranchbus_add;
/

