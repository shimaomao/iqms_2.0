create procedure          proc_counters_query (
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --查询bsc_win_config 生成counters.json
 v_sql := 'select b.win_no counterId,
''inserted''  saveStatus,
b.win_no counterNo,
b.is_start enabled,
b.win_screen caller,
b.win_screen evaluator,
b.win_screen barscn,
b.multiple_screen cmpscn
from bsc_win_config b
 where  b.org_id =:orgId and b.device_no =:deviceNo';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;




end proc_counters_query;
/

