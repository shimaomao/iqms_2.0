create procedure          proc_counterbuzbywinid_select
(
orgId varchar2,
deviceNo varchar2,
winId varchar2,
p_cursor out sys_refcursor
)
as
   v_sql varchar2(4000);
   v_orgid varchar2(50) := orgId;
   v_deviceNo varchar2(50) := deviceNo;
   v_winId varchar2(50) := winId;
begin

   if orgId is null or deviceNo is null then
       v_sql := 'select * from BSC_CounterBuz b where b.counterid =:v_winId ';
       OPEN p_cursor FOR v_sql using v_winId;
   else
       v_sql := 'select * from BSC_CounterBuz b where b.counterid =:v_winId
       and b.org_id =:v_orgid and b.device_no =:v_deviceNo';
       OPEN p_cursor FOR v_sql using v_winId,v_orgid,v_deviceNo;
   end if;

end proc_counterbuzbywinid_select;
/

