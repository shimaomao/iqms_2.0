create procedure          proc_counterid_select
(
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor
)
as
 v_sql varchar2(4000);
 v_orgid varchar2(50) := orgId;
 v_deviceNo varchar2(50) := deviceNo;

begin

 v_sql := 'select distinct(b.counterid) from bsc_counterbuz b
           where  b.org_id =:v_orgid and b.device_no =:v_deviceNo';

 OPEN p_cursor FOR v_sql using v_orgid,v_deviceNo;


end proc_counterid_select;
/

