create procedure          proc_orderconfig_page (
orgId varchar2, --机构ID

orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(4000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);
   v_orgCode varchar2(50);

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
  select s.org_code into v_orgCode from sys_org s where s.org_id = orgId;
  v_sql_condition := ' select o.id,o.rowId rid,o.org_code,o.device_no,o.begin_time,o.end_time,
  o.ordercount,s.org_name,d.host_name from order_range o,sys_org s,bsc_device d where
  o.org_code=s.org_code and o.device_no = d.device_no  ';


  if v_orgCode is not null then
     v_sql_condition := v_sql_condition || ' and o.org_code like ''%''||:v_orgCode||''%''';
   else
     v_orgCode := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( o.org_code  is null or o.org_code <>:v_orgCode)';

  end if;


  -------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'org_code';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||',rid) rnum,tt.id,
  tt.org_code,
  tt.device_no,
  tt.begin_time,
  tt.end_time,
  tt.ordercount,
  tt.org_name,
  tt.host_name
  from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';


------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_orgCode;
     OPEN p_cursor FOR v_sql_page using  v_orgCode,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_orgCode;
  end if;

end proc_orderconfig_page;
/

