create PROCEDURE          proc_bcmenu_add
(
 menuName varchar2,
 menuEnName varchar2 ,
 expend1 varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
eCount INTEGER;
BEGIN

 --查询要增加的记录是否存在
 select count(1) into iRecCount from bc_menu t where t.menu_name = menuName;
 select count(1) into eCount from bc_menu t where t.menu_enname = menuEnName;

 if iRecCount > 0 then
   ReturnCode:='2'; --该客户类型已经存在
 elsif eCount>0 then
 ReturnCode:='3';
 else
   --插入
   insert into bc_menu t (
      MENU_ID,
      MENU_NAME,
      MENU_ENNAME,
      EXTEND1
   ) values (
     SEQ_BCMENU.NEXTVAL,
     menuName,
     menuEnName,
     expend1
   );
   --update bsc_device b set b.extend1 = '1';
   proc_deviceupdateflag('','1');
   ReturnCode:='0';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcmenu_add;
/

