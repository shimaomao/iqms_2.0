create procedure          proc_report_cusanalysegrph (
orgId in varchar2,
custLevel in varchar2,
startDate in varchar2,--不能对输入参数重新赋值
endDate in varchar2,
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(20000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);

   v_orgid varchar2(50) := orgId;
   v_custLevel varchar2(50) := custLevel;
   v_startDate varchar2(50) := startDate;
   v_endDate varchar2(50) := endDate;

begin

  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := 'select c.cust_level,c.cust_name,
                             count(1) deal_count,
                             to_char(trunc(avg(h.call_time-h.print_time)*24*60,1),''fm9999990.0999'') avg_wait,
                             to_char(trunc(max(h.call_time-h.print_time)*24*60,1),''fm9999990.0999'') max_wait,
                             to_char(trunc(min(h.call_time-h.print_time)*24*60,1),''fm9999990.0999'') min_wait,
                             to_char(trunc(avg(h.end_time-h.begin_time)*24*60,1),''fm9999990.0999'') avg_deal,
                             to_char(trunc(max(h.end_time-h.begin_time)*24*60,1),''fm9999990.0999'') max_deal,
                             to_char(trunc(min(h.end_time-h.begin_time)*24*60,1),''fm9999990.0999'') min_deal
                       from TRX_HISTORY h
                       inner join (select * from sys_org o where o.deleted=0  start with o.org_id = :v_orgid
                       connect by prior o.org_id = o.parent_id) og on (h.org_id=og.org_id)
                       inner join bc_custtype c on (h.cust_type=c.cust_level)
                       where h.trx_status=''3'' and h.end_time is not null and h.begin_time is not null ';

  --其他查询条件
  if custLevel is not null then
     v_sql_condition := v_sql_condition || ' and h.cust_type = :v_custLevel';
   else
     v_custLevel := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.cust_type  is null or h.cust_type <> :v_custLevel)';

  end if;

  if startDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') >= to_date(:startDate,''yyyy-MM-dd'') ';
   else
     v_startDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <> :startDate )';

  end if;

  if endDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') <= to_date(:endDate,''yyyy-MM-dd'') ';
   else
     v_endDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <>:endDate)';

  end if;

  v_sql_condition := v_sql_condition ||' group by c.cust_level,c.cust_name order by c.cust_level ';


    OPEN p_cursor FOR v_sql_condition using  v_orgid,v_custLevel,v_startDate,v_endDate;

end proc_report_cusanalysegrph;
/

