create procedure          proc_bccusttype_page (
custName varchar2, --类型名称

orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(4000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);
   v_custName varchar2(50) := custName;

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := ' select CUST_LEVEL,h.rowId rid,CUST_NAME,VIP_FLAG,SMS_FLAG,WAIT_TIMEOUT,
                     PRESENT_FLAG,IS_USE,EXTEND1,EXTEND2,EXTEND3 from bc_custtype h where 1=1  ';


  if v_custName is not null then
     v_sql_condition := v_sql_condition || ' and h.cust_name like ''%''||:custName||''%''';
   else
     v_custName := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.cust_name  is null or h.cust_name <>:custName)';

  end if;


  -------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'cust_level ';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||',rid) rnum,tt.CUST_LEVEL,
  tt.CUST_NAME,
  tt.VIP_FLAG,
  tt.SMS_FLAG,
  tt.WAIT_TIMEOUT,
  tt.PRESENT_FLAG,
  tt.IS_USE,
  tt.EXTEND1,
  tt.EXTEND2,
  tt.EXTEND3
   from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';


------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_custName;
     OPEN p_cursor FOR v_sql_page using  v_custName,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_custName;
  end if;

end proc_bccusttype_page;
/

