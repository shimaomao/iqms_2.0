create procedure          proc_order_business (
deviceNo varchar2,
--dateType varchar2,--是否假日
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin



 v_sql := 'select b.org_id,b.device_no,
 b.bus_id,
 b.business_code,
 bm.business_name,
 bm.order_flag
 from bsc_branch_business b
 inner join BC_BUSINESSMANAGE bm
 on (b.bus_id = bm.business_id)

 where  b.device_no =:deviceNo
 and b.business_type=''1''
 and bm.order_flag =''1'' ';
 OPEN p_cursor FOR v_sql using deviceNo ;




end proc_order_business;
/

