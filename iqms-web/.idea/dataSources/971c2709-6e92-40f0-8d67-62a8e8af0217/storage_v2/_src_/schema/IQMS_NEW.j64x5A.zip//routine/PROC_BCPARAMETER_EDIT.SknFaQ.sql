create PROCEDURE          proc_bcparameter_edit
(
 hbInterval varchar2,
 authenticationType varchar2,
 flowPort varchar2,
 httpPort varchar2,
 identPort varchar2,
 appRoot varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN
--查询表中是否存在数据
select count(1) into iRecCount from bc_parameter t;
if iRecCount > 0 then
   update bc_parameter t set
      t.HB_INTERVAL = hbInterval,
      t.AUTHENTICATION_TYPE =authenticationType,
      t.flow_port = flowPort,
      t.http_port = httpPort,
      t.ident_port = identPort,
      t.app_root = appRoot;

   ReturnCode:='0';
else
  INSERT INTO bc_parameter t (
      HB_INTERVAL,
      AUTHENTICATION_TYPE,
      flow_port,
      http_port,
      ident_port,
      app_root
  ) VALUES (
      hbInterval,
      authenticationType,
      flowPort,
      httpPort,
      identPort,
      appRoot
  );
  ReturnCode:='0';
  end if;
  --修改客户识别中的识别模式
update bsc_cust_recognition c
set c.recognition_type = authenticationType;
  --update bsc_device t set
      --t.extend1 = '1';
 proc_deviceupdateflag('','1');
 --异常处理
 --exception
    -- when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bcparameter_edit;
/

