create procedure          proc_takeconfig_delete
(
 v_styleId in  varchar2,
 ReturnCode  out varchar2
)
is

  ideviceNo varchar2(100);

begin

    --
  select t.device_no into ideviceNo from bc_takemodel t where t.styleid = v_styleId;

  -- 1、删除这些样式模板的界面元素
  delete from bc_modelstyle_element me where me.model_style_id in (select ms.id from bc_modelStyle ms where ms.style_id = v_styleId);


  -- 2. 删除样式表
  delete from bc_modelstyle ms where ms.style_id = v_styleId;


  --3、删除模板
  delete from bc_takemodel t where t.styleid = v_styleId;




   -- 更新设备更新标记
   proc_deviceupdateflag(ideviceNo,0);

  ReturnCode:='0';

   --异常处理
   -- exception
    --   when others then
     --  ReturnCode:='1'; --数据库异常
end proc_takeconfig_delete;
/

