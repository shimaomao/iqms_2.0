create PROCEDURE          proc_configConfirm
(
 deviceId varchar2,
 ReturnCode OUT varchar2  -- 1-失败，记录不存在     0-成功
)
AS
iRecCount INTEGER;
BEGIN

 --查询柜员是否存在versionSeq
 select count(1) into iRecCount from bsc_device t where t.device_no = deviceId;

 if iRecCount > 0 then -- 更新下载日期
    update bsc_device t set t.extend1 = '0' where t.device_no = deviceId;
     ReturnCode:='0';
 else
   ReturnCode:='1';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_configConfirm;
/

