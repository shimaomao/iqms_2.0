create procedure          proc_report_businessstatistics (
orgId in varchar2,
busType in varchar2,
startDate in varchar2,--不能对输入参数重新赋值
endDate in varchar2,
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(20000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);

   v_orgid varchar2(50) := orgId;
   v_busType varchar2(50) := busType;
   v_startDate varchar2(50) := startDate;
   v_endDate varchar2(50) := endDate;

begin

  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := ' select temps.org_id,temps.org_code,temps.org_name,temps.bus_id,temps.business_name,temps.cust_level,temps.cust_name,
                             count(1) deal_count,
                             sum(case when temps.is_WaitOut=1 then 1 else 0 end) wait_count,
                             sum(case when temps.is_WaitOut=0 then 1 else 0 end) notwait_count,
                             sum(case when temps.deal_TimeOut=1 then 1 else 0 end) dealwait_count,
                             sum(case when temps.deal_TimeOut=0 then 1 else 0 end) notdealwait_count
                       from
                          (select temp.org_id,temp.org_code, temp.org_name,temp.bus_id,temp.business_name,temp.cust_level,temp.cust_name,
                             (case when temp.cus_wait >temp.c_wait then ''1'' else ''0'' end) is_WaitOut,
                             (case when temp.bus_wait >temp.b_wait then ''1'' else ''0'' end) deal_TimeOut
                          from
                               (select h.org_id, og.org_code,og.org_name,h.bus_id,b.business_name,c.cust_level,c.cust_name,
                                  b.average_time b_wait,
                                  c.wait_timeout c_wait,
                                  trunc(((case when h.call_time is null then sysdate else h.call_time end)-h.print_time)*24*60,0) cus_wait,
                                  trunc(((case when h.end_time is null then sysdate else h.end_time end)-h.begin_time)*24*60,0) bus_wait
                               from trx_history h
                               inner join (select * from sys_org o where o.deleted=0  start with o.org_id =:v_orgid
                               connect by prior o.org_id = o.parent_id) og on (h.org_id=og.org_id)
                               left join bc_businessmanage b on (h.bus_id=b.business_id)
                               left join bc_custtype c on (h.cust_type = c.cust_level)
                               where h.trx_status=''3'' ';

  --其他查询条件
  if busType is not null then
     v_sql_condition := v_sql_condition || ' and h.bus_id = :v_busType';
   else
     v_busType := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.bus_id  is null or h.bus_id <> :v_busType)';

  end if;

  if startDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') >= to_date(:startDate,''yyyy-MM-dd'') ';
   else
     v_startDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <> :startDate )';

  end if;

  if endDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') <= to_date(:endDate,''yyyy-MM-dd'') ';
   else
     v_endDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <>:endDate)';

  end if;

  v_sql_condition := v_sql_condition ||' ) temp ) temps group by temps.org_id,temps.org_code,temps.org_name,temps.bus_id,temps.business_name,temps.cust_level,temps.cust_name';


-------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'ORG_ID ';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||') rnum,
    tt.ORG_ID,
    tt.ORG_CODE,
    tt.ORG_NAME,
    tt.bus_id,
    tt.business_name,
    tt.cust_level,
    tt.cust_name,
    tt.deal_count,
    tt.wait_count,
    tt.notwait_count,
    tt.dealwait_count,
    tt.notdealwait_count
   from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';

------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_orgid,v_busType,v_startDate,v_endDate;
     OPEN p_cursor FOR v_sql_page using  v_orgid,v_busType,v_startDate,v_endDate,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_orgid,v_busType,v_startDate,v_endDate;
  end if;

end proc_report_businessstatistics;
/

