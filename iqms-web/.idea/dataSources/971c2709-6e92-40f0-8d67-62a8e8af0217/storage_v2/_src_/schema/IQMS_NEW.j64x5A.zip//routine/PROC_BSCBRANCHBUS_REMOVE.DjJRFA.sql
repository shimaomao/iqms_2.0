create PROCEDURE          proc_bscbranchbus_remove
(
 orgId varchar2,
 deviceNo varchar2,
 treeId varchar2,
 ReturnCode OUT varchar2
)
AS

busType varchar2(10);
busId varchar2(20);
BEGIN

 select t.business_type into busType from BSC_BRANCH_BUSINESS t
 where t.org_id = orgId and t.device_no = deviceNo and t.tree_id = treeId;
 select t.bus_id into busId from BSC_BRANCH_BUSINESS t
 where t.org_id = orgId and t.device_no = deviceNo and t.tree_id = treeId;

--删除网点业务同时 删除业务显示数据
 delete from Bsc_Show_Time s
 where s.device_no = deviceNo and s.org_id = orgId
 and s.business_id = busId;
--级联删除 叫号策略中关联业务
 delete from  bsc_counterbuz t
 where t.org_id = orgId and t.device_no = deviceNo and t.buztypeid = busId;
--设置 客户等级 中绑定业务 为不绑定
update bsc_cust_level c set c.business_id=0
where c.device_no = deviceNo and c.business_id = busId;
--级联删除 【取号界面】
delete from bc_modelstyle_element m
where m.buztype_id =  busId and m.element_type = 'buzType'
 and m.device_no = deviceNo;
--更新设备状态
--update bsc_device b set b.extend1 = '1' where b.org_id = orgId
--and b.device_no = deviceNo;

 delete from  BSC_BRANCH_BUSINESS t
 where t.org_id = orgId and t.device_no = deviceNo and t.tree_id = treeId;

 proc_deviceupdateflag(deviceNo,'0');
 ReturnCode:='0';

END proc_bscbranchbus_remove;
/

