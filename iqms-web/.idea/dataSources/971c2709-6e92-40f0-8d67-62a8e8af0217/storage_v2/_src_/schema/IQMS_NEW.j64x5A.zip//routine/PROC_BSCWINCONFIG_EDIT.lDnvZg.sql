create PROCEDURE          proc_bscwinconfig_edit
(
 orgId varchar2,
 deviceNo varchar2,
 winNo varchar2,
 isCall varchar2,
 isJudge varchar2,
 winScreen varchar2,
 multipleScreen varchar2,
 isStart varchar2,
 extend1 varchar2,
 extend2 varchar2,
 extend3 varchar2,
 ReturnCode OUT varchar2
)
AS

BEGIN

   update BSC_WIN_CONFIG t set
      t.ORG_ID = orgId,
      t.DEVICE_NO =deviceNo,
      t.WIN_NO =winNo,
      t.IS_CALL =isCall,
      t.IS_JUDGE =isJudge,
      t.WIN_SCREEN =winScreen,
      t.MULTIPLE_SCREEN =multipleScreen,
      t.IS_START =isStart,
      t.EXTEND1 =extend1,
      t.EXTEND2 =extend2,
      t.EXTEND3 =extend3
      where t.org_id = orgId
      and t.device_no = deviceNo
      and t.win_no = winNo;
       proc_deviceupdateflag(deviceNo,'0');

   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bscwinconfig_edit;
/

