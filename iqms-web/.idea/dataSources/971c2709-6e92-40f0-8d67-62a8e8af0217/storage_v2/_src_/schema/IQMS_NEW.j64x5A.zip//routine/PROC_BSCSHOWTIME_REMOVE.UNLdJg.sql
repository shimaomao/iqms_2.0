create PROCEDURE          proc_bscshowtime_remove
(
 orgId varchar2,
 deviceNo varchar2,
 businessId varchar2,
 ReturnCode OUT varchar2
)
AS

BEGIN
 delete from  BSC_SHOW_TIME t  where t.org_id = orgId and t.device_no = deviceNo and t.business_id = businessId;
 --更新设备状态
--update bsc_device b set b.extend1 = '1' where b.org_id = orgId
--and b.device_no = deviceNo;
proc_deviceupdateflag(deviceNo,'0');
 ReturnCode:='0';
END proc_bscshowtime_remove;
/

