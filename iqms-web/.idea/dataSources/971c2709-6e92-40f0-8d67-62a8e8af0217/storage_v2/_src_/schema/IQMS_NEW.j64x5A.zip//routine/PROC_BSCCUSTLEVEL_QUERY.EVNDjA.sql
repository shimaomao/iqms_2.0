create procedure          PROC_BSCCUSTLEVEL_QUERY (
orgId varchar2,
deviceNo varchar2,
--flag varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --select result
 --if flag ='1' then
 v_sql := 'select h.*
   from bsc_cust_level h where

      h.org_id =:orgId and h.device_no =:deviceNo  order by h.cust_level';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;
 --else
  -- v_sql := 'select h.*,dic.dic_value
   --from bsc_cust_level h,sys_dic dic where
    --  h.cust_level = dic.dic_key and dic.dic_type=''levelName''
    -- and h.org_id =:orgId and h.device_no =:deviceNo';
 --OPEN p_cursor FOR v_sql using orgId,deviceNo;
--end if;


end PROC_BSCCUSTLEVEL_QUERY;
/

