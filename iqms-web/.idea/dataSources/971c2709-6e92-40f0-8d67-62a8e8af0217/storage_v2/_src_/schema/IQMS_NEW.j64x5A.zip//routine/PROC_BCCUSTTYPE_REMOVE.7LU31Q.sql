create PROCEDURE          proc_bccusttype_remove
(
 custLevel varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

   delete from  bc_custtype t where t.cust_level = custLevel;

   ReturnCode:='0';
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bccusttype_remove;
/

