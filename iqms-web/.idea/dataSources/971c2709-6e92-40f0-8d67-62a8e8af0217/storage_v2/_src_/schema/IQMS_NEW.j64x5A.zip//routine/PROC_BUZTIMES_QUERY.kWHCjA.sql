create procedure          proc_buztimes_query (
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --查询bsc_branch_business 生成buzType.json
 v_sql := 'select b.org_id,b.device_no,b.business_id,
 (case when b.date_type = ''N'' then 1 else 2 end) date_type,
b.begin_time,b.end_time,b.max_num
 from bsc_show_time b
 where  b.org_id =:orgId and b.device_no =:deviceNo';
 OPEN p_cursor FOR v_sql using orgId,deviceNo;




end proc_buztimes_query;
/

