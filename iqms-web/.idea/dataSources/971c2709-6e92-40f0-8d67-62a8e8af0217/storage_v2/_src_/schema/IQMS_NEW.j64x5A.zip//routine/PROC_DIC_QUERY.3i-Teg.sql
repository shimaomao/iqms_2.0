create procedure          proc_dic_query (
dicType varchar2, --类型名称
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_dicType varchar2(50) := dicType;

begin
---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
 v_sql := 'select dic_key,dic_value from SYS_DIC dic where 1=1 ';
 v_sql := v_sql || ' and dic.dic_type =:dicType';
 OPEN p_cursor FOR v_sql using  v_dicType;

end proc_dic_query;
/

