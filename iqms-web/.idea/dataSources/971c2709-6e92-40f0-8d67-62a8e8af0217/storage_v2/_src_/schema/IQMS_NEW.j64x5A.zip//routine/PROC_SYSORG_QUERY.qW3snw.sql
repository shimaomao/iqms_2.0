create procedure          proc_sysorg_query (
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --select result
 v_sql := 'select org_name,org_id from SYS_ORG ';
 OPEN p_cursor FOR v_sql ;


end proc_sysorg_query;
/

