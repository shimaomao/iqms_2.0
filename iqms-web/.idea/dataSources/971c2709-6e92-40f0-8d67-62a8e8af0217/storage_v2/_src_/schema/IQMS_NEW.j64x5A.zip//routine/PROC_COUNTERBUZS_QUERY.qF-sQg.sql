create procedure          proc_counterBuzs_query (
orgId varchar2,
deviceNo varchar2,
counterId varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --查询bsc_win_config 生成counters.json
 v_sql := 'select b.buzprioritytime,b.custprioritytime,b.maxwaiting,
b.levelid,bus.business_name cnName,c.cust_name levelName,
bsc.business_code buzCode,b.buztypeid,''T'' saveDjStatus,b.counterid,
b.datetypeid
from bsc_counterbuz b,bsc_branch_business bsc,bc_custtype c,
bc_businessmanage bus
 where b.buztypeid = bsc.bus_id and bsc.business_type=''BUS''
 and c.cust_level = b.levelid and bus.business_id = b.buztypeid
 and  b.org_id =:orgId and b.device_no =:deviceNo and b.counterid =:counterId ';
 OPEN p_cursor FOR v_sql using orgId,deviceNo,counterId;




end proc_counterBuzs_query;
/

