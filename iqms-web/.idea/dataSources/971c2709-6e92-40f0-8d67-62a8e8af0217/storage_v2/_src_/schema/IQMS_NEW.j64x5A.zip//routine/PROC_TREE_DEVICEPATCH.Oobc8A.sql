create procedure          proc_tree_devicepatch (
orgId in varchar2,  -- 机构id
patchId in number, --版本编号
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_orgId varchar2(20) :=orgId;
   v_patchId number:=patchId;

begin


  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql := 'select * from ( select to_char(o.org_id) id,'''' device_No,to_char(o.parent_id) p_id,o.org_name dev_Name ,'''' is_Dev,
                               -1 currt_Ver, -1 last_Ver, '''' currt_Name, '''' last_Name from sys_org o
                         union all
                        select ''D''||d.device_no id,
                           d.device_no device_No,
                           to_char(d.org_id) p_id,
                           case when d.producer is not null then ''【''||d.producer || ''】'' || d.host_name else ''【null】''||d.host_name end dev_Name,
                           ''1'' is_Dev,
                           d.currt_ver currt_Ver,
                           d.last_ver last_Ver,
                           d.currt_vername currt_Name,
                           d.last_vername last_Name
                      from bsc_device d where  (d.last_ver is null or d.last_ver < '||v_patchId||' )) tmp start with  tmp.id = '''||v_orgId||''' connect by prior tmp.id = tmp.p_id';


    OPEN p_cursor FOR v_sql;

end proc_tree_devicepatch;
/

