create PROCEDURE          proc_BSCDEVUPGRADEPROCESS_add
(
 deviceNo varchar2,
 patchId varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
patchName varchar2(100);
dbFlag varchar2(2);
BEGIN


 --查询要增加的记录是否存在
 select count(1) into iRecCount from BSC_DEVUPGRADE_PROCESS t where t.device_no = deviceNo and t.patch_id = patchId and t.status = 0;

 if iRecCount > 0 then
   ReturnCode:='2'; -- 该设备已经使用过了该升级包
 else

 -- 查询版本的名称和是否包含数据(dbFlag  1-有数据库   0-没有数据)
 select v.patch_name,v.db_flag into patchName,dbFlag from bc_patchversion v where v.id = patchId;

   --插入
   insert into BSC_DEVUPGRADE_PROCESS (
      id,
      device_no,
      patch_id,
      optDate,
      status
   ) values (
     SEQ_UPGRADEPROCESS.NEXTVAL,
     deviceNo,
     patchId,
     sysdate,
      '0' --是否已经下发成功
   );

   -- 将信息更新到设备表中
   update bsc_device d set d.last_ver=patchId,d.last_vername=patchName,d.extend1 = dbFlag where d.device_no = deviceNo;

   ReturnCode:='0';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_BSCDEVUPGRADEPROCESS_add;
/

