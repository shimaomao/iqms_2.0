create PROCEDURE          proc_bscwinconfig_copy--应用到下级机构
(
 orgId varchar2,
 deviceNo varchar2,
 targetId varchar2,--目标orgId
 targetNo varchar2, --目标deviceNo
 ReturnCode OUT varchar2
)
AS
BEGIN
 if orgId != targetId or deviceNo != targetNo then
 --删除目标数据再插入
 delete from BSC_WIN_CONFIG b where b.org_id = targetId and b.device_no = targetNo;

   --插入
   insert into BSC_WIN_CONFIG (
      ORG_ID,
      DEVICE_NO,
      WIN_NO,
      win_id,
      IS_CALL,
      IS_JUDGE,
      WIN_SCREEN,
      MULTIPLE_SCREEN,
      IS_START,
      row_id,
      EXTEND1,
      EXTEND2,
      EXTEND3
   ) select
     targetId,
     targetNo,
      WIN_NO,
      WIN_ID,
      IS_CALL,
      IS_JUDGE,
      WIN_SCREEN,
      MULTIPLE_SCREEN,
      IS_START,
      row_id,
      EXTEND1,
      EXTEND2,
      EXTEND3
    from BSC_WIN_CONFIG w where w.org_id = orgId and w.device_no=deviceNo;
    proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0';
end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bscwinconfig_copy;
/

