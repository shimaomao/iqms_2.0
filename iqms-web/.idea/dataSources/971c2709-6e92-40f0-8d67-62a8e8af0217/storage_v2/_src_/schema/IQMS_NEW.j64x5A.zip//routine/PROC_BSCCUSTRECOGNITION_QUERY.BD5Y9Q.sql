create procedure          proc_bsccustrecognition_query (
orgId varchar2,
deviceNo varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --select result
 v_sql := 'select b.*,d.dic_value levelName

 from bsc_cust_recognition b, sys_dic d
 where  b.org_id =:orgId and b.device_no =:deviceNo and  b.cust_level = d.dic_key
 and d.dic_type=''levelName'' order by b.row_id' ;
 OPEN p_cursor FOR v_sql using orgId,deviceNo;



end proc_bsccustrecognition_query;
/

