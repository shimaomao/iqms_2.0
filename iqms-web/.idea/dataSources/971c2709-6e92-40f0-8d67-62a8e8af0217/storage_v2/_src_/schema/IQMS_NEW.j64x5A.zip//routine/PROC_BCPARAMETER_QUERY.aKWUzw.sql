create procedure          proc_bcparameter_query (
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --select result
 v_sql := 'select * from BC_PARAMETER ';
 OPEN p_cursor FOR v_sql ;


end proc_bcparameter_query;
/

