create PROCEDURE          proc_bsccustrecognition_remove
(
 orgId varchar2,
 deviceNo varchar2,

 ReturnCode OUT varchar2
)
AS

BEGIN
 delete from  BSC_CUST_RECOGNITION t  where t.org_id = orgId and t.device_no = deviceNo ;
--更新设备状态
--update bsc_device b set b.extend1 = '1' where b.org_id = orgId
--and b.device_no = deviceNo;
proc_deviceupdateflag(deviceNo,'0');
 ReturnCode:='0';
END proc_bsccustrecognition_remove;
/

