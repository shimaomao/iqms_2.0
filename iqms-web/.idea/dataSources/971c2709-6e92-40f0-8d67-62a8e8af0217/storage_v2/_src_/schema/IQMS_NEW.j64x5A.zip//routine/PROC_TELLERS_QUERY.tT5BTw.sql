create procedure          proc_tellers_query (
orgId varchar2,

p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


 --bc_teller 生成tellers.json
 v_sql := 'select b.work_id, b.caller_pwd,
b.name_,case b.sex when ''0'' then ''1''
else ''0'' end sex,
''inserted'' saveStatus
from
bc_teller b
where b.org_id =:orgId  ';
 OPEN p_cursor FOR v_sql using orgId;




end proc_tellers_query;
/

