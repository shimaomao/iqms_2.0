create procedure          proc_tree_menu_business (--网点业务 以菜单和业务为根节点的 组织树

p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin


  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------
  v_sql := 'select * from ( select m.menu_id tree_id,''p1'' tree_pid,m.menu_name branch_name,m.menu_enname branchEname  from bc_menu m
                         union all
                        select b.business_id tree_id,

                           ''p2'' tree_pid,

                           b.business_name branch_name,
                           b.business_ename branchEname
                      from bc_businessmanage b ) tmp order by tmp.tree_id';



    OPEN p_cursor FOR v_sql ;

end proc_tree_menu_business;
/

