create PROCEDURE          proc_bccusttype_edit
(
 custLevel varchar2,
 custName varchar2,
 vipFlag varchar2 ,
 smsFlag varchar2 ,
 waitTimeout varchar2,
 presentFlag varchar2,
 isUse varchar2,
 v_expend1 varchar2,
 v_expend2 varchar2,
 v_expend3 varchar2,
 ReturnCode OUT varchar2
)
AS
v_count INTEGER;
BEGIN
    --查询要增加的记录是否存在
select count(1) into v_count from bc_custtype t where t.cust_name= custName;
if v_count > 0 then
     ReturnCode:='2'; --该类型名称已经存在
else
   update bc_custtype t set
      t.CUST_LEVEL = custLevel,
      t.CUST_NAME =custName,
      t.VIP_FLAG = vipFlag,
      t.SMS_FLAG = smsFlag,
      t.WAIT_TIMEOUT = waitTimeout,
      t.PRESENT_FLAG = presentFlag,
      t.IS_USE = isUse,
      t.EXTEND1 = v_expend1,
      t.EXTEND2 = v_expend2,
      t.EXTEND3 = v_expend3
   where t.cust_level = custLevel;
   ReturnCode:='0';

end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bccusttype_edit;
/

