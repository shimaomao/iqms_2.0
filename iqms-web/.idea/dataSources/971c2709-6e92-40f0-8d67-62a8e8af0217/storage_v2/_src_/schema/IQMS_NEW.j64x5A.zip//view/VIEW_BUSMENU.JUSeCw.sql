create view VIEW_BUSMENU as
select "BUSINESS_ID","BUSINESS_NAME","BUS_TYPE",business_en_name from (
select m.menu_id business_id, m.menu_name business_name, '0' bus_type,m.menu_enname business_en_name from bc_menu m
union all
select bm.business_id,bm.business_name,'1' bus_type, bm.business_ename business_en_name from bc_businessmanage bm)
/

