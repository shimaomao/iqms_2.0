create procedure          proc_findShowTime_query (
--orgId varchar2,
deviceNo varchar2,
businessId varchar2,
dateType varchar2,
p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);


begin

 v_sql := 'select b.* from bsc_show_time b
 where b.device_no =:deviceNo and b.business_id=:businessId
 and b.date_type=:dateType order by b.begin_time ' ;

  OPEN p_cursor FOR v_sql using deviceNo,businessId,dateType;




end proc_findShowTime_query;
/

