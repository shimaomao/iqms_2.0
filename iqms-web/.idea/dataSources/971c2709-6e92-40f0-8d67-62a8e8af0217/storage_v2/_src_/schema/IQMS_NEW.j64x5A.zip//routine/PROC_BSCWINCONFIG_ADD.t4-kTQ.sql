create PROCEDURE          proc_bscwinconfig_add
(
 orgId varchar2,
 deviceNo varchar2,
 winNo varchar2,
 isCall varchar2,
 isJudge varchar2,
 winScreen varchar2,
 multipleScreen varchar2,
 isStart varchar2,
 rowId_ varchar2,
 extend1 varchar2,
 extend2 varchar2,
 extend3 varchar2,
 ReturnCode OUT varchar2
)
AS
iRecCount INTEGER;
BEGIN

 --查询要增加的记录是否存在
 --select count(1) into iRecCount from DEVICE_INFO t where t.org_code = orgCode and t.device_no = deviceNo;
 select count(1) into iRecCount from BSC_WIN_CONFIG t where t.row_id=rowId_ and t.device_no = deviceNo and t.org_id = orgId;

 if iRecCount > 0 then
   update BSC_WIN_CONFIG t set
      t.ORG_ID = orgId,
      t.DEVICE_NO =deviceNo,
      t.WIN_NO =winNo,
      t.IS_CALL =isCall,
      t.IS_JUDGE =isJudge,
      t.WIN_SCREEN =winScreen,
      t.MULTIPLE_SCREEN =multipleScreen,
      t.IS_START =isStart,
      t.ROW_ID = rowId_,
      t.win_id = winNo,
      t.EXTEND1 =extend1,
      t.EXTEND2 =extend2,
      t.EXTEND3 =extend3
      where t.org_id = orgId
      and t.device_no = deviceNo
      and t.row_id = rowId_;
      --更新设备状态
  proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0'; --该窗口已经存在
 else
   --插入
   insert into BSC_WIN_CONFIG (
      ORG_ID,
      DEVICE_NO,
      WIN_NO,
      IS_CALL,
      IS_JUDGE,
      WIN_SCREEN,
      MULTIPLE_SCREEN,
      IS_START,
      row_id,
      win_id,
      EXTEND1,
      EXTEND2,
      EXTEND3
   ) values (
     orgId,
     deviceNo,
     winNo,
     isCall,
     isJudge,
     winScreen,
     multipleScreen,
     isStart,
     rowId_,
     winNo,
     extend1,
     extend2,
     extend3
   );
   --更新设备状态
  --update bsc_device b set b.extend1 = '1'
  --where b.org_id = orgId and b.device_no = deviceNo;
  proc_deviceupdateflag(deviceNo,'0');
   ReturnCode:='0';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_bscwinconfig_add;
/

