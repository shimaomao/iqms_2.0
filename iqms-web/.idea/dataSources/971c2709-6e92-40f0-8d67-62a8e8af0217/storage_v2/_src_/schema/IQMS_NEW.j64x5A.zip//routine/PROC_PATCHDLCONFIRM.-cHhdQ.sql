create PROCEDURE          proc_patchDlConfirm
(
 deviceId varchar2,
 versionSeq varchar2,
 ReturnCode OUT varchar2  -- 1-失败，记录不存在     0-成功
)
AS
iRecCount INTEGER;
BEGIN

 --查询柜员是否存在versionSeq
 select count(1) into iRecCount from bsc_devupgrade_process t where t.device_no = deviceId and t.patch_id = versionSeq;

 if iRecCount > 0 then -- 更新下载日期
    update bsc_devupgrade_process t set t.dldate = sysdate where t.device_no = deviceId and t.patch_id = versionSeq;
     ReturnCode:='0';
 else
   ReturnCode:='1';
 end if;
 --异常处理
 -- exception
   --   when others then
     --  ReturnCode:='1'; --数据库异常
END proc_patchDlConfirm;
/

