create procedure          proc_report_businessflow (
orgId in varchar2,
--busType in varchar2,
custLevel in varchar2,
appValue in varchar2,
startDate in varchar2,--不能对输入参数重新赋值
endDate in varchar2,
orderfield in varchar2,
ordertype in varchar2,
pagesize in number, pageno in number,totalrows out number,p_cursor out sys_refcursor)
as
   v_sql varchar2(4000);
   v_sql_page varchar2(4000);
   v_sql_condition varchar2(20000);
   v_sql_count varchar2(4000);
   v_begin number := (pageno-1)*pagesize+1;
   v_end number := pageno*pagesize;
   v_sort varchar2(50);

   v_orgid varchar2(50) := orgId;
   --v_busType varchar2(50) := busType;
   v_custLevel varchar2(50) := custLevel;
   v_appValue varchar2(50) := appValue;
   v_startDate varchar2(50) := startDate;
   v_endDate varchar2(50) := endDate;

begin

  ---------------------------------------------------------1.按条件查询数据 start------------------------------------------------------------------

  v_sql_condition := 'select h.org_id,og.org_code,og.org_name,h.device_no,h.trx_date,h.flow_no,h.bus_id,
                             b.BUSINESS_NAME,h.ticket_no,h.cust_type,c.cust_name,h.teller_no,h.win_no,h.print_time,
                             h.call_time,h.begin_time,h.end_time,h.app_value,h.trx_status,h.pdj_level,h.ticket_type,h.cust_id,
                             h.card_type,h.card_no,h.manager_no,h.extend1,h.extend2,h.extend3
                       from TRX_HISTORY h
                       inner join (select * from sys_org o where o.deleted=0  start with o.org_id =:v_orgid
                       connect by prior o.org_id = o.parent_id) og on (h.org_id=og.org_id)
                       inner join bc_businessmanage b on (h.bus_id=b.BUSINESS_ID)
                       left join bc_custtype c on (h.cust_type = c.cust_level) where 1=1  ';

  --其他查询条件
  /*if busType is not null then
     v_sql_condition := v_sql_condition || ' and h.bus_id = :v_busType';
   else
     v_busType := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.bus_id  is null or h.bus_id <> :v_busType)';

  end if;*/

  if custLevel is not null then
     v_sql_condition := v_sql_condition || ' and h.cust_type = :v_custLevel';
   else
     v_custLevel := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.cust_type  is null or h.cust_type <> :v_custLevel)';

  end if;

  if appValue is not null then
     v_sql_condition := v_sql_condition || ' and h.app_value = :v_appValue';
   else
     v_appValue := 5201314;
     v_sql_condition := v_sql_condition || ' and ( h.app_value  is null or h.app_value <> :v_appValue)';

  end if;

  if startDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') >= to_date(:startDate,''yyyy-MM-dd'') ';
   else
     v_startDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <> :startDate )';

  end if;

  if endDate is not null then
     v_sql_condition := v_sql_condition || ' and to_date(to_char(h.TRX_DATE,''yyyy-MM-dd''),''yyyy-MM-dd'') <= to_date(:endDate,''yyyy-MM-dd'') ';
   else
     v_endDate := '@#$&^%$#@!';
     v_sql_condition := v_sql_condition || ' and ( h.TRX_DATE  is null or to_char(h.TRX_DATE,''yyyy-MM-dd'') <>:endDate)';

  end if;



-------------------------------------------------2.包裹按条件查询的语句，进行分页 开始------------------------------------------------------------
  if (orderfield is null) then
      v_sort := 'ORG_ID ';
  else
      v_sort := orderfield||' '||ordertype;
  end if;

 --select result
 v_sql := 'select row_number() over ( order by '||v_sort||') rnum,
    tt.ORG_ID,
    tt.ORG_CODE,
    tt.ORG_NAME,
    tt.device_no,
    tt.trx_date,
    tt.flow_no,
    tt.bus_id,
    tt.BUSINESS_NAME,
    tt.ticket_no,
    tt.cust_type,
    tt.cust_name,
    tt.teller_no,
    tt.win_no,
    tt.print_time,
    tt.call_time,
    tt.begin_time,
    tt.end_time,
    tt.app_value,
    tt.trx_status,
    tt.pdj_level,
    tt.ticket_type,
    tt.cust_id,
    tt.card_type,
    tt.card_no,
    tt.manager_no,
    tt.extend1,
    tt.extend2,
    tt.extend3
   from ('||v_sql_condition||') tt ';

   --select count
  v_sql_count := 'select count(1) from ('||v_sql||')';

------------------------------------------------------------3.判断是分页还是查询列表

   if pageno > 0  then
    v_sql_page := 'select * from ('||v_sql||') temp where temp.rnum >= :v_begin and temp.rnum <= :v_end';
     execute immediate v_sql_count into totalrows using v_orgid,v_custLevel,v_appValue,v_startDate,v_endDate;
     OPEN p_cursor FOR v_sql_page using  v_orgid,v_custLevel,v_appValue,v_startDate,v_endDate,v_begin,v_end;
  else
    totalrows:=0; --set default value
    v_sql_page := 'select * from ('||v_sql||') temp ';
    OPEN p_cursor FOR v_sql_page using  v_orgid,v_custLevel,v_appValue,v_startDate,v_endDate;
  end if;

end proc_report_businessflow;
/

